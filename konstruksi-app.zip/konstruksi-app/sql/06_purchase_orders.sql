-- Tahap 6: Supplier, Purchase Order, Surat Jalan, Tagihan. Jalankan setelah 05_payroll.sql.

insert into app_settings values ('po_owner_min', '10000000') on conflict do nothing; -- PO >= ini butuh owner
insert into app_settings values ('po_vat_pct', '0')           on conflict do nothing; -- toleransi PPN tagihan (%)

create table if not exists suppliers (
  id uuid primary key default gen_random_uuid(),
  name text not null, phone text, address text, is_active boolean not null default true
);
create sequence if not exists po_seq;

create table if not exists purchase_orders (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid unique not null,
  project_id  uuid not null references projects(id) on delete cascade,
  supplier_id uuid not null references suppliers(id),
  po_number   text unique,
  po_date     date not null default current_date,
  status      text not null default 'submitted'
              check (status in ('submitted','approved','rejected','partial','received')),
  total       numeric(16,2) not null default 0,
  items       jsonb not null,    -- [{description, unit, qty, unit_price}] dikirim dari HP (aman offline)
  notes       text,
  created_by  uuid not null references profiles(id),
  created_at  timestamptz not null default now()
);
create table if not exists po_items (
  id uuid primary key default gen_random_uuid(),
  po_id uuid not null references purchase_orders(id) on delete cascade,
  line_no int not null, description text not null, unit text not null,
  qty numeric(14,3) not null check (qty > 0),
  unit_price numeric(16,2) not null check (unit_price >= 0)
);
create table if not exists delivery_notes (          -- surat jalan / penerimaan barang
  id uuid primary key default gen_random_uuid(),
  client_id uuid unique not null,
  po_id uuid not null references purchase_orders(id) on delete cascade,
  sj_number text not null,
  received_date date not null default current_date,
  items jsonb not null,          -- [{po_item_id, qty}]
  notes text,
  created_by uuid not null references profiles(id),
  created_at timestamptz not null default now()
);
create table if not exists delivery_items (
  delivery_id uuid not null references delivery_notes(id) on delete cascade,
  po_item_id uuid not null references po_items(id),
  qty numeric(14,3) not null check (qty > 0),
  primary key (delivery_id, po_item_id)
);
create table if not exists supplier_invoices (
  id uuid primary key default gen_random_uuid(),
  client_id uuid unique not null,
  po_id uuid not null references purchase_orders(id) on delete cascade,
  invoice_no text not null,
  amount numeric(16,2) not null check (amount > 0),
  invoice_date date not null default current_date,
  due_date date,
  status text not null default 'unpaid' check (status in ('unpaid','paid')),
  paid_at timestamptz,
  created_by uuid not null references profiles(id)
);
create index if not exists idx_po_project on purchase_orders (project_id, created_at desc);
create index if not exists idx_poi_po on po_items (po_id);
create index if not exists idx_inv_po on supplier_invoices (po_id);

-- ---------- PO: validasi + nomor + total (sebelum insert) ----------
create or replace function fn_po_before() returns trigger language plpgsql as $$
declare t numeric; bad int;
begin
  if jsonb_typeof(new.items) <> 'array' or jsonb_array_length(new.items) = 0 then
    raise exception 'PO harus memiliki minimal satu item'; end if;
  select count(*) into bad from jsonb_array_elements(new.items) i
   where coalesce((i->>'qty')::numeric, 0) <= 0 or coalesce(i->>'description', '') = '';
  if bad > 0 then raise exception 'Item PO tidak valid (nama atau jumlah kosong)'; end if;
  select coalesce(sum((i->>'qty')::numeric * coalesce((i->>'unit_price')::numeric, 0)), 0)
    into t from jsonb_array_elements(new.items) i;
  new.total := t;
  new.status := 'submitted';
  new.po_number := 'PO-' || to_char(coalesce(new.po_date, current_date), 'YYMM') || '-' || lpad(nextval('po_seq')::text, 4, '0');
  return new;
end $$;
drop trigger if exists trg_po_before on purchase_orders;
create trigger trg_po_before before insert on purchase_orders for each row execute function fn_po_before();

-- ---------- PO: pecah item + buat approval + notifikasi (setelah insert) ----------
create or replace function fn_po_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare min_owner numeric;
begin
  insert into po_items(po_id, line_no, description, unit, qty, unit_price)
  select new.id, ord, e->>'description', coalesce(e->>'unit', 'unit'),
         (e->>'qty')::numeric, coalesce((e->>'unit_price')::numeric, 0)
  from jsonb_array_elements(new.items) with ordinality as t(e, ord);

  select value::numeric into min_owner from app_settings where key = 'po_owner_min';
  insert into approvals(project_id, ref_table, ref_id, level, requested_by)
  values (new.project_id, 'purchase_orders', new.id, 1, new.created_by) on conflict do nothing;
  if new.total >= coalesce(min_owner, 10000000) then
    insert into approvals(project_id, ref_table, ref_id, level, requested_by)
    values (new.project_id, 'purchase_orders', new.id, 2, new.created_by) on conflict do nothing;
  end if;
  perform notify_project_role(new.project_id, 'pm', new.po_number || ' senilai Rp ' || to_char(new.total, 'FM999G999G999G999') ||
                      ' menunggu persetujuan Anda.', 'po-new-' || new.id);
  return new;
end $$;
drop trigger if exists trg_po_after on purchase_orders;
create trigger trg_po_after after insert on purchase_orders for each row execute function fn_po_after();

-- ---------- Keputusan PO (PM level 1, owner level 2) ----------
create or replace function decide_po(p_po uuid, p_level smallint, p_approve boolean, p_note text default null)
returns text language plpgsql security definer set search_path = public as $$
declare po purchase_orders; a approvals; v_pending int;
begin
  select * into po from purchase_orders where id = p_po;
  if not found or not is_member(po.project_id) then raise exception 'PO tidak ditemukan'; end if;
  select * into a from approvals where ref_table = 'purchase_orders' and ref_id = p_po and level = p_level for update;
  if not found then raise exception 'Level % tidak diperlukan untuk PO ini', p_level; end if;
  if a.status <> 'submitted' then raise exception 'Sudah diputuskan'; end if;
  if (p_level = 1 and my_role() <> 'pm') or (p_level = 2 and my_role() <> 'owner') then
    raise exception 'Peran Anda tidak boleh memutuskan level %', p_level; end if;
  if p_level = 2 and exists (select 1 from approvals where ref_table = 'purchase_orders'
        and ref_id = p_po and level = 1 and status <> 'approved') then
    raise exception 'Level 1 (PM) harus disetujui lebih dulu'; end if;

  update approvals set status = case when p_approve then 'approved'::approval_status else 'rejected' end,
         decided_by = auth.uid(), decided_at = now(), note = p_note where id = a.id;

  if not p_approve then
    update purchase_orders set status = 'rejected' where id = p_po;
    perform notify_project_role(po.project_id, 'admin_proyek', po.po_number || ' ditolak' || coalesce(': ' || p_note, '') || '.', 'po-no-' || p_po);
    return 'rejected';
  end if;
  select count(*) into v_pending from approvals
   where ref_table = 'purchase_orders' and ref_id = p_po and status <> 'approved';
  if v_pending = 0 then
    update purchase_orders set status = 'approved' where id = p_po;
    perform notify_project_role(po.project_id, 'admin_proyek', po.po_number || ' disetujui. Silakan pesan ke supplier.', 'po-ok-' || p_po);
  elsif p_level = 1 then
    perform notify_role('owner', po.po_number || ' (Rp ' || to_char(po.total, 'FM999G999G999G999') ||
                        ') sudah disetujui PM, menunggu persetujuan Anda.', 'po-l2-' || p_po);
  end if;
  return 'approved';
end $$;

-- ---------- Surat jalan: cek PO, batasi penerimaan, update status ----------
create or replace function fn_delivery_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare po purchase_orders; e jsonb; it po_items; got numeric; q numeric; v_open int;
begin
  select * into po from purchase_orders where id = new.po_id;
  if po.status not in ('approved', 'partial') then
    raise exception '% belum disetujui atau sudah selesai diterima', po.po_number; end if;
  for e in select value from jsonb_array_elements(new.items) loop
    q := coalesce((e->>'qty')::numeric, 0);
    continue when q <= 0;
    select * into it from po_items where id = (e->>'po_item_id')::uuid and po_id = new.po_id;
    if not found then raise exception 'Item tidak ada di PO ini'; end if;
    select coalesce(sum(qty), 0) into got from delivery_items where po_item_id = it.id;
    if got + q > it.qty then
      raise exception 'Penerimaan "%" melebihi pesanan (% %)', it.description, it.qty, it.unit; end if;
    insert into delivery_items values (new.id, it.id, q);
  end loop;
  select count(*) into v_open from po_items pi where pi.po_id = new.po_id
     and pi.qty > (select coalesce(sum(d.qty), 0) from delivery_items d where d.po_item_id = pi.id);
  update purchase_orders set status = case when v_open = 0 then 'received' else 'partial' end where id = new.po_id;
  return new;
end $$;
drop trigger if exists trg_delivery_after on delivery_notes;
create trigger trg_delivery_after after insert on delivery_notes for each row execute function fn_delivery_after();

-- ---------- Pencocokan PO vs barang diterima vs tagihan ----------
create or replace view po_match with (security_invoker = true) as
select p.id as po_id, p.project_id, p.po_number, p.status, p.total as ordered,
       coalesce(r.v, 0) as received_value, coalesce(i.a, 0) as invoiced, coalesce(i.paid, 0) as paid
from purchase_orders p
left join lateral (select sum(d.qty * pi.unit_price) v from delivery_items d
                   join po_items pi on pi.id = d.po_item_id where pi.po_id = p.id) r on true
left join lateral (select sum(amount) a, sum(amount) filter (where status = 'paid') paid
                   from supplier_invoices where po_id = p.id) i on true;

-- ---------- Bayar tagihan (Finance): ditolak bila melebihi nilai barang diterima ----------
create or replace function pay_invoice(p_invoice uuid) returns void
language plpgsql security definer set search_path = public as $$
declare inv supplier_invoices; m record; vat numeric;
begin
  if my_role() <> 'finance' then raise exception 'Hanya Finance yang dapat membayar'; end if;
  select * into inv from supplier_invoices where id = p_invoice for update;
  if not found then raise exception 'Tagihan tidak ditemukan'; end if;
  if inv.status = 'paid' then raise exception 'Tagihan sudah dibayar'; end if;
  select received_value, invoiced into m from po_match where po_id = inv.po_id;
  select coalesce(value::numeric, 0) into vat from app_settings where key = 'po_vat_pct';
  if m.invoiced > m.received_value * (1 + coalesce(vat, 0) / 100) + 1 then
    raise exception 'Total tagihan melebihi nilai barang yang sudah diterima. Cocokkan surat jalan dulu.'; end if;
  update supplier_invoices set status = 'paid', paid_at = now() where id = p_invoice;
end $$;

-- ---------- RLS ----------
alter table suppliers          enable row level security;
alter table purchase_orders    enable row level security;
alter table po_items           enable row level security;
alter table delivery_notes     enable row level security;
alter table delivery_items     enable row level security;
alter table supplier_invoices  enable row level security;

create policy "supplier baca" on suppliers for select using (auth.uid() is not null and my_role() <> 'mandor');
create policy "supplier kelola" on suppliers for all
  using (my_role() in ('admin_proyek','pm','finance')) with check (my_role() in ('admin_proyek','pm','finance'));

create policy "PO baca" on purchase_orders for select using (is_member(project_id) and my_role() <> 'mandor');
create policy "PO buat" on purchase_orders for insert
  with check (my_role() in ('admin_proyek','pm') and is_member(project_id) and created_by = auth.uid());
-- Sengaja tanpa policy update/delete: PO tidak bisa diubah setelah diajukan.

create policy "item PO baca" on po_items for select
  using (exists (select 1 from purchase_orders p where p.id = po_id and is_member(p.project_id)) and my_role() <> 'mandor');

create policy "SJ baca" on delivery_notes for select
  using (exists (select 1 from purchase_orders p where p.id = po_id and is_member(p.project_id)));
create policy "SJ buat" on delivery_notes for insert
  with check (my_role() in ('admin_proyek','pm') and created_by = auth.uid()
    and exists (select 1 from purchase_orders p where p.id = po_id and is_member(p.project_id)));
create policy "item SJ baca" on delivery_items for select
  using (exists (select 1 from delivery_notes d join purchase_orders p on p.id = d.po_id
                 where d.id = delivery_id and is_member(p.project_id)));

create policy "tagihan baca" on supplier_invoices for select
  using (exists (select 1 from purchase_orders p where p.id = po_id and is_member(p.project_id))
         and my_role() in ('admin_proyek','pm','finance','owner'));
create policy "tagihan buat" on supplier_invoices for insert
  with check (my_role() in ('admin_proyek','finance') and created_by = auth.uid()
    and exists (select 1 from purchase_orders p where p.id = po_id and is_member(p.project_id)));

-- Jejak audit
do $$ declare t text; begin
  foreach t in array array['purchase_orders','delivery_notes','supplier_invoices'] loop
    execute format('drop trigger if exists trg_audit on %I', t);
    execute format('create trigger trg_audit after insert or update or delete on %I for each row execute function fn_audit()', t);
  end loop; end $$;
