-- ============================================================================
-- PASANG SEMUA (01 sampai 14) dalam SATU transaksi.
-- Bila ada satu error, SEMUANYA dibatalkan (tidak ada yang setengah terpasang),
-- sehingga Anda bisa memperbaiki lalu menjalankan ulang dari awal.
-- Jalankan HANYA di proyek Supabase percobaan yang masih kosong.
-- Sebelum menjalankan: aktifkan extension pg_cron dan pg_net (Database > Extensions).
-- ============================================================================
begin;

-- ########## 01_schema.sql ##########
-- =====================================================================
-- Aplikasi Manajemen Proyek Konstruksi - Skema Supabase (Tahap 1)
-- Jalankan di Supabase SQL Editor. Aman dijalankan ulang (IF NOT EXISTS).
-- Tahap berikutnya: PO, SPK subcon, adendum, retensi, alat berat, pajak, dst.
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------- ENUM ----------
do $$ begin
  create type app_role as enum ('mandor','admin_proyek','pm','estimator','finance','owner');
  create type approval_status as enum ('draft','submitted','approved','rejected');
  create type project_status as enum ('planning','active','handover','retention','closed');
exception when duplicate_object then null; end $$;

-- ---------- PROFIL & PERAN ----------
create table if not exists profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text not null,
  role        app_role not null default 'mandor',
  phone_wa    text,                       -- untuk notifikasi WhatsApp (Fonnte/Wablas)
  is_active   boolean not null default true,
  created_at  timestamptz not null default now()
);

-- Penugasan user ke proyek (satu user bisa banyak proyek)
create table if not exists project_members (
  project_id  uuid not null,
  user_id     uuid not null references profiles(id) on delete cascade,
  primary key (project_id, user_id)
);

-- ---------- PROYEK ----------
create table if not exists projects (
  id              uuid primary key default gen_random_uuid(),
  code            text unique not null,
  name            text not null,
  client_name     text not null,
  contract_value  numeric(18,2) not null default 0,
  start_date      date,
  end_date        date,
  retention_pct   numeric(5,2) not null default 5.00,   -- retensi 5%
  status          project_status not null default 'planning',
  created_at      timestamptz not null default now()
);
alter table project_members
  drop constraint if exists project_members_project_id_fkey,
  add constraint project_members_project_id_fkey
  foreign key (project_id) references projects(id) on delete cascade;

-- ---------- RAB (rincian volume & harga satuan) ----------
create table if not exists rab_items (
  id           uuid primary key default gen_random_uuid(),
  project_id   uuid not null references projects(id) on delete cascade,
  code         text not null,
  description  text not null,
  unit         text not null,
  volume       numeric(18,3) not null default 0,
  unit_price   numeric(18,2) not null default 0,
  total        numeric(18,2) generated always as (volume * unit_price) stored,
  unique (project_id, code)
);

-- ---------- LAPORAN HARIAN ----------
-- client_id dibuat di HP (uuid) -> kunci idempoten agar sync ulang tidak menggandakan data
create table if not exists daily_reports (
  id            uuid primary key default gen_random_uuid(),
  client_id     uuid unique not null,
  project_id    uuid not null references projects(id) on delete cascade,
  report_date   date not null,
  weather       text,
  physical_pct  numeric(5,2) check (physical_pct between 0 and 100),
  notes         text,
  status        approval_status not null default 'draft',
  created_by    uuid not null references profiles(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (project_id, report_date, created_by)
);
create index if not exists idx_dr_project_date on daily_reports (project_id, report_date desc);

-- ---------- ABSENSI TUKANG (HOK) ----------
create table if not exists workers (
  id          uuid primary key default gen_random_uuid(),
  project_id  uuid not null references projects(id) on delete cascade,
  name        text not null,
  skill       text,
  daily_wage  numeric(14,2) not null default 0,
  is_active   boolean not null default true
);

create table if not exists attendance (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid unique not null,
  worker_id   uuid not null references workers(id) on delete cascade,
  work_date   date not null,
  hok         numeric(3,2) not null default 1 check (hok between 0 and 2),  -- 0.5 = setengah hari
  created_by  uuid not null references profiles(id),
  unique (worker_id, work_date)
);
create index if not exists idx_att_date on attendance (work_date);

-- ---------- KASBON TUKANG ----------
create table if not exists worker_advances (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid unique not null,
  worker_id   uuid not null references workers(id) on delete cascade,
  amount      numeric(14,2) not null check (amount > 0),
  given_on    date not null default current_date,
  settled     boolean not null default false,
  created_by  uuid not null references profiles(id)
);

-- ---------- KAS KECIL ----------
create table if not exists petty_cash (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid unique not null,
  project_id  uuid not null references projects(id) on delete cascade,
  tx_date     date not null default current_date,
  direction   text not null check (direction in ('in','out')),
  amount      numeric(14,2) not null check (amount > 0),
  description text not null,
  status      approval_status not null default 'submitted',
  created_by  uuid not null references profiles(id),
  created_at  timestamptz not null default now()
);
create index if not exists idx_pc_project_date on petty_cash (project_id, tx_date desc);

-- ---------- LAMPIRAN FOTO (path saja, file di Storage) ----------
-- Simpan hanya path + ukuran; JANGAN simpan base64 di tabel (hemat egress)
create table if not exists attachments (
  id            uuid primary key default gen_random_uuid(),
  client_id     uuid unique not null,
  project_id    uuid not null references projects(id) on delete cascade,
  ref_table     text not null,           -- 'daily_reports' | 'petty_cash' | dst
  ref_id        uuid not null,
  storage_path  text not null,
  mime_type     text not null,
  size_bytes    integer not null,
  width         integer,
  height        integer,
  created_by    uuid not null references profiles(id),
  created_at    timestamptz not null default now()
);
create index if not exists idx_att_ref on attachments (ref_table, ref_id);

-- ---------- APPROVAL BERJENJANG ----------
create table if not exists approvals (
  id            uuid primary key default gen_random_uuid(),
  project_id    uuid not null references projects(id) on delete cascade,
  ref_table     text not null,
  ref_id        uuid not null,
  level         smallint not null check (level in (1,2)),   -- 1 = PM, 2 = Owner
  status        approval_status not null default 'submitted',
  requested_by  uuid not null references profiles(id),
  decided_by    uuid references profiles(id),
  decided_at    timestamptz,
  note          text,
  created_at    timestamptz not null default now(),
  unique (ref_table, ref_id, level)
);
create index if not exists idx_appr_pending on approvals (level, status) where status = 'submitted';

-- ---------- ANTREAN WHATSAPP ----------
create table if not exists wa_outbox (
  id          uuid primary key default gen_random_uuid(),
  to_phone    text not null,
  message     text not null,
  sent_at     timestamptz,
  attempts    smallint not null default 0,
  last_error  text,
  created_at  timestamptz not null default now()
);

-- ---------- JEJAK AUDIT ----------
create table if not exists audit_log (
  id          bigserial primary key,
  table_name  text not null,
  row_id      uuid,
  action      text not null,             -- INSERT / UPDATE / DELETE
  actor       uuid,
  old_data    jsonb,
  new_data    jsonb,
  at          timestamptz not null default now()
);

create or replace function fn_audit() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into audit_log(table_name,row_id,action,actor,old_data,new_data)
  values (tg_table_name,
          coalesce((to_jsonb(new)->>'id')::uuid,(to_jsonb(old)->>'id')::uuid),
          tg_op, auth.uid(),
          case when tg_op <> 'INSERT' then to_jsonb(old) end,
          case when tg_op <> 'DELETE' then to_jsonb(new) end);
  return coalesce(new, old);
end $$;

do $$
declare t text;
begin
  foreach t in array array['daily_reports','petty_cash','approvals','projects','rab_items','worker_advances']
  loop
    execute format('drop trigger if exists trg_audit on %I', t);
    execute format('create trigger trg_audit after insert or update or delete on %I
                    for each row execute function fn_audit()', t);
  end loop;
end $$;

-- updated_at otomatis
create or replace function fn_touch() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;
drop trigger if exists trg_touch on daily_reports;
create trigger trg_touch before update on daily_reports
  for each row execute function fn_touch();

-- ---------- HELPER RLS ----------
create or replace function my_role() returns app_role
language sql stable security definer set search_path = public as
$$ select role from profiles where id = auth.uid() $$;

create or replace function is_member(pid uuid) returns boolean
language sql stable security definer set search_path = public as
$$ select exists(select 1 from project_members where project_id = pid and user_id = auth.uid())
       or my_role() in ('owner','finance') $$;

-- ---------- ROW LEVEL SECURITY ----------
alter table profiles        enable row level security;
alter table project_members enable row level security;
alter table projects        enable row level security;
alter table rab_items       enable row level security;
alter table daily_reports   enable row level security;
alter table workers         enable row level security;
alter table attendance      enable row level security;
alter table worker_advances enable row level security;
alter table petty_cash      enable row level security;
alter table attachments     enable row level security;
alter table approvals       enable row level security;
alter table audit_log       enable row level security;

create policy "profil sendiri/anggota" on profiles for select
  using (id = auth.uid() or my_role() in ('pm','owner','finance'));

create policy "proyek terlihat anggota" on projects for select using (is_member(id));
create policy "proyek diubah PM/owner" on projects for all
  using (my_role() in ('pm','owner')) with check (my_role() in ('pm','owner'));

create policy "RAB baca anggota" on rab_items for select using (is_member(project_id));
create policy "RAB tulis estimator/PM" on rab_items for all
  using (my_role() in ('estimator','pm')) with check (my_role() in ('estimator','pm'));

create policy "laporan baca anggota" on daily_reports for select using (is_member(project_id));
create policy "laporan tulis mandor" on daily_reports for insert
  with check (is_member(project_id) and my_role() in ('mandor','pm') and created_by = auth.uid());
create policy "laporan ubah (draft sendiri / PM)" on daily_reports for update
  using ((created_by = auth.uid() and status in ('draft','rejected')) or my_role() = 'pm');

create policy "kas kecil baca" on petty_cash for select using (is_member(project_id));
create policy "kas kecil tulis admin" on petty_cash for insert
  with check (is_member(project_id) and my_role() in ('admin_proyek','pm') and created_by = auth.uid());

create policy "lampiran baca" on attachments for select using (is_member(project_id));
create policy "lampiran tulis" on attachments for insert
  with check (is_member(project_id) and created_by = auth.uid());

create policy "approval baca" on approvals for select using (is_member(project_id));
create policy "approval L1 oleh PM, L2 oleh owner" on approvals for update
  using ((level = 1 and my_role() = 'pm') or (level = 2 and my_role() = 'owner'));

create policy "audit hanya owner" on audit_log for select using (my_role() = 'owner');

-- ---------- STORAGE ----------
-- Buat bucket privat 'site-photos' via Dashboard > Storage (public = false).
-- Gunakan signed URL berumur pendek saat menampilkan foto, dan thumbnail
-- (lihat imageCompress.js -> makeThumbnail) di daftar agar egress minimal.

-- CATATAN: policy untuk workers, attendance, worker_advances dibuat dengan pola
-- yang sama (join ke projects lewat worker_id) pada tahap payroll.

-- ########## 02_auth.sql ##########
-- Tahap 2: Auth + peran. Jalankan setelah 01_schema.sql.

-- 1) Profil otomatis saat user dibuat (Dashboard > Authentication > Add user)
create or replace function fn_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)), 'mandor')
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists trg_new_user on auth.users;
create trigger trg_new_user after insert on auth.users
  for each row execute function fn_new_user();

-- 2) Hanya owner yang boleh mengubah peran / menugaskan proyek
create or replace function set_user_role(target uuid, new_role app_role)
returns void language plpgsql security definer set search_path = public as $$
begin
  if my_role() <> 'owner' then raise exception 'Hanya owner yang boleh mengubah peran'; end if;
  update profiles set role = new_role where id = target;
end $$;

create or replace function assign_project(target uuid, pid uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if my_role() not in ('owner','pm') then raise exception 'Tidak diizinkan'; end if;
  insert into project_members(project_id, user_id) values (pid, target) on conflict do nothing;
end $$;

-- 3) Pengguna tidak bisa mengubah perannya sendiri lewat update langsung
create policy "update profil: nama/telepon saja" on profiles for update
  using (id = auth.uid())
  with check (id = auth.uid() and role = (select role from profiles where id = auth.uid()));

-- Cara pakai pertama kali:
--  a. Buat akun Anda di Dashboard, lalu jalankan sekali di SQL Editor:
--     update profiles set role = 'owner' where id = '<UUID-akun-anda>';
--  b. Setelah itu atur peran lainnya: select set_user_role('<uuid>', 'pm');

-- ########## 03_petty_cash.sql ##########
-- Tahap 3: Kas kecil + approval berjenjang. Jalankan setelah 02_auth.sql.

-- 1) Pengaturan: batas nominal yang butuh persetujuan owner (level 2)
create table if not exists app_settings (key text primary key, value text not null);
insert into app_settings values ('owner_approval_min', '5000000') on conflict do nothing;
alter table app_settings enable row level security;
create policy "settings baca" on app_settings for select using (auth.uid() is not null);
create policy "settings ubah owner" on app_settings for all
  using (my_role() = 'owner') with check (my_role() = 'owner');

-- 2) Saldo kas kecil per proyek (hanya transaksi yang sudah disetujui)
create or replace view petty_cash_balance with (security_invoker = true) as
select project_id,
       coalesce(sum(case direction when 'in' then amount else -amount end), 0) as balance
from petty_cash where status = 'approved' group by project_id;

-- 3) Setiap kas kecil baru otomatis membuat approval level 1 (+ level 2 jika nominal besar)
create or replace function fn_petty_cash_approvals() returns trigger
language plpgsql security definer set search_path = public as $$
declare min_owner numeric;
begin
  select value::numeric into min_owner from app_settings where key = 'owner_approval_min';
  insert into approvals(project_id, ref_table, ref_id, level, requested_by)
  values (new.project_id, 'petty_cash', new.id, 1, new.created_by)
  on conflict do nothing;
  if new.direction = 'out' and new.amount >= coalesce(min_owner, 5000000) then
    insert into approvals(project_id, ref_table, ref_id, level, requested_by)
    values (new.project_id, 'petty_cash', new.id, 2, new.created_by)
    on conflict do nothing;
  end if;
  return new;
end $$;
drop trigger if exists trg_pc_approvals on petty_cash;
create trigger trg_pc_approvals after insert on petty_cash
  for each row execute function fn_petty_cash_approvals();

-- 4) Keputusan approval (satu pintu, divalidasi di server)
create or replace function decide_approval(p_ref_table text, p_ref_id uuid, p_level smallint,
                                           p_approve boolean, p_note text default null)
returns approval_status language plpgsql security definer set search_path = public as $$
declare a approvals; pending_left int; pc petty_cash;
begin
  select * into a from approvals
   where ref_table = p_ref_table and ref_id = p_ref_id and level = p_level for update;
  if not found then raise exception 'Approval tidak ditemukan'; end if;
  if a.status <> 'submitted' then raise exception 'Sudah diputuskan'; end if;
  if (p_level = 1 and my_role() <> 'pm') or (p_level = 2 and my_role() <> 'owner') then
    raise exception 'Peran Anda tidak boleh memutuskan level %', p_level;
  end if;
  if p_level = 2 and exists (select 1 from approvals where ref_table = p_ref_table
        and ref_id = p_ref_id and level = 1 and status <> 'approved') then
    raise exception 'Level 1 (PM) harus disetujui lebih dulu';
  end if;

  update approvals set status = case when p_approve then 'approved'::approval_status else 'rejected' end,
         decided_by = auth.uid(), decided_at = now(), note = p_note where id = a.id;

  if p_ref_table = 'petty_cash' then
    if not p_approve then
      update petty_cash set status = 'rejected' where id = p_ref_id;
      return 'rejected';
    end if;
    select count(*) into pending_left from approvals
     where ref_table = p_ref_table and ref_id = p_ref_id and status <> 'approved';
    if pending_left = 0 then
      update petty_cash set status = 'approved' where id = p_ref_id;
    elsif p_level = 1 then  -- teruskan ke owner via WhatsApp
      select * into pc from petty_cash where id = p_ref_id;
      perform notify_role('owner', 'Persetujuan diperlukan: kas keluar Rp ' || to_char(pc.amount, 'FM999G999G999G999') ||
              ' (' || pc.description || '). Buka aplikasi > Persetujuan.', 'pc-l2-' || pc.id);
    end if;
  end if;
  return case when p_approve then 'approved'::approval_status else 'rejected' end;
end $$;

-- 5) Policy Storage untuk foto nota (bucket privat 'site-photos')
-- Folder pertama path = project_id. Anggota proyek boleh unggah dan baca.
create policy "foto: anggota unggah" on storage.objects for insert to authenticated
  with check (bucket_id = 'site-photos' and is_member(((storage.foldername(name))[1])::uuid));
create policy "foto: anggota baca" on storage.objects for select to authenticated
  using (bucket_id = 'site-photos' and is_member(((storage.foldername(name))[1])::uuid));
create policy "foto: anggota timpa (retry upload)" on storage.objects for update to authenticated
  using (bucket_id = 'site-photos' and is_member(((storage.foldername(name))[1])::uuid));

-- 6) Pengiriman wa_outbox: jalankan lewat Edge Function terjadwal (tahap WhatsApp),
--    yang membaca baris sent_at is null lalu memanggil API Fonnte/Wablas.

-- ########## 04_whatsapp.sql ##########
-- Tahap 4: Notifikasi WhatsApp. Jalankan setelah 03_petty_cash.sql.

-- 1) Kolom pendukung antrean
alter table wa_outbox
  add column if not exists locked_at timestamptz,
  add column if not exists dedupe_key text;
create unique index if not exists uq_wa_dedupe on wa_outbox (dedupe_key) where dedupe_key is not null;
create index if not exists idx_wa_pending on wa_outbox (created_at) where sent_at is null;
alter table wa_outbox enable row level security;   -- tanpa policy: hanya service_role yang bisa akses

-- 2) Helper: kirim pesan ke semua user berperan tertentu (dan opsional anggota proyek saja)
create or replace function notify_role(p_role app_role, p_message text, p_key text default null)
returns void language plpgsql security definer set search_path = public as $$
declare r record;
begin
  for r in select id, phone_wa from profiles
            where role = p_role and is_active and phone_wa is not null loop
    insert into wa_outbox(to_phone, message, dedupe_key)
    values (r.phone_wa, p_message, case when p_key is null then null else p_key || ':' || r.id end)
    on conflict do nothing;
  end loop;
end $$;
revoke all on function notify_role(app_role, text, text) from public, anon, authenticated;

-- 2b) Versi per proyek: hanya anggota proyek itu (pakai untuk peran pm/admin_proyek/mandor/estimator;
--     owner dan finance memang lintas proyek, cukup notify_role)
create or replace function notify_project_role(p_project uuid, p_role app_role, p_message text, p_key text default null)
returns void language plpgsql security definer set search_path = public as $$
declare r record;
begin
  for r in select p.id, p.phone_wa from profiles p
            join project_members m on m.user_id = p.id and m.project_id = p_project
           where p.role = p_role and p.is_active and p.phone_wa is not null loop
    insert into wa_outbox(to_phone, message, dedupe_key)
    values (r.phone_wa, p_message, case when p_key is null then null else p_key || ':' || r.id end)
    on conflict do nothing;
  end loop;
end $$;
revoke all on function notify_project_role(uuid, app_role, text, text) from public, anon, authenticated;

-- 3) Klaim batch (aman dari kirim ganda walau fungsi berjalan paralel)
create or replace function claim_wa_batch(p_limit int default 10)
returns setof wa_outbox language plpgsql security definer set search_path = public as $$
begin
  return query
  update wa_outbox w set attempts = attempts + 1, locked_at = now()
   where w.id in (
     select id from wa_outbox
      where sent_at is null and attempts < 5
        and (locked_at is null or locked_at < now() - interval '2 minutes')
      order by created_at limit p_limit for update skip locked)
  returning w.*;
end $$;
revoke all on function claim_wa_batch(int) from public, anon, authenticated;
grant execute on function claim_wa_batch(int) to service_role;

-- 4) (Sudah diterapkan di 03_petty_cash.sql: decide_approval memakai notify_role dengan kunci dedupe.)

-- 5) Jadwal: panggil Edge Function tiap menit (pg_cron + pg_net, aktifkan di Database > Extensions)
create extension if not exists pg_cron;
create extension if not exists pg_net;

-- Simpan rahasia di Vault, jangan di kode:
--   select vault.create_secret('https://<PROJECT-REF>.supabase.co/functions/v1/send-wa', 'wa_fn_url');
--   select vault.create_secret('<ISI-CRON_SECRET-ANDA>', 'wa_cron_secret');
select cron.schedule('kirim-wa', '* * * * *', $$
  select net.http_post(
    url     := (select decrypted_secret from vault.decrypted_secrets where name = 'wa_fn_url'),
    headers := jsonb_build_object('x-cron-secret',
               (select decrypted_secret from vault.decrypted_secrets where name = 'wa_cron_secret')),
    body    := '{}'::jsonb);
$$);

-- ########## 05_payroll.sql ##########
-- Tahap 5: Payroll (absensi HOK, kasbon, rekap upah mingguan). Jalankan setelah 04_whatsapp.sql.

-- 1) Pelengkap tabel
alter table worker_advances add column if not exists repaid numeric(14,2) not null default 0;
insert into app_settings values ('advance_max_pct', '50') on conflict do nothing;  -- potongan kasbon maks % dari upah kotor

create table if not exists payroll_runs (
  id          uuid primary key default gen_random_uuid(),
  project_id  uuid not null references projects(id) on delete cascade,
  week_start  date not null,                      -- hari pertama pekan (Senin)
  status      approval_status not null default 'submitted',
  total_gross numeric(16,2) not null default 0,
  total_deduct numeric(16,2) not null default 0,
  total_net   numeric(16,2) not null default 0,
  created_by  uuid not null references profiles(id),
  decided_by  uuid references profiles(id),
  decided_at  timestamptz,
  unique (project_id, week_start)
);
create table if not exists payroll_lines (
  run_id          uuid not null references payroll_runs(id) on delete cascade,
  worker_id       uuid not null references workers(id),
  hok_total       numeric(6,2) not null,
  daily_wage      numeric(14,2) not null,         -- upah dibekukan saat dihitung
  gross           numeric(16,2) not null,
  advance_deduct  numeric(14,2) not null default 0,
  net             numeric(16,2) not null,
  primary key (run_id, worker_id)
);

-- 2) RLS
alter table payroll_runs  enable row level security;
alter table payroll_lines enable row level security;

create policy "pekerja baca" on workers for select using (is_member(project_id));
create policy "pekerja kelola" on workers for all
  using (my_role() in ('pm','admin_proyek') and is_member(project_id))
  with check (my_role() in ('pm','admin_proyek') and is_member(project_id));

create policy "absensi baca" on attendance for select
  using (exists (select 1 from workers w where w.id = worker_id and is_member(w.project_id)));
create policy "absensi tulis" on attendance for insert
  with check (my_role() in ('mandor','admin_proyek','pm') and created_by = auth.uid()
    and exists (select 1 from workers w where w.id = worker_id and is_member(w.project_id)));
create policy "absensi ubah" on attendance for update
  using (my_role() in ('mandor','admin_proyek','pm')
    and exists (select 1 from workers w where w.id = worker_id and is_member(w.project_id)));

create policy "kasbon baca" on worker_advances for select
  using (exists (select 1 from workers w where w.id = worker_id and is_member(w.project_id))
         and my_role() in ('admin_proyek','pm','finance','owner'));
create policy "kasbon tulis" on worker_advances for insert
  with check (my_role() in ('admin_proyek','pm') and created_by = auth.uid()
    and exists (select 1 from workers w where w.id = worker_id and is_member(w.project_id)));

create policy "rekap baca" on payroll_runs for select using (is_member(project_id));
create policy "baris rekap baca" on payroll_lines for select
  using (exists (select 1 from payroll_runs r where r.id = run_id and is_member(r.project_id)));
-- Tulis hanya lewat fungsi di bawah (security definer)

-- 3) Absensi pekan yang sudah disetujui tidak boleh diubah
create or replace function fn_lock_attendance() returns trigger
language plpgsql security definer set search_path = public as $$
declare d date := coalesce(new.work_date, old.work_date); pid uuid;
begin
  select project_id into pid from workers where id = coalesce(new.worker_id, old.worker_id);
  if exists (select 1 from payroll_runs where project_id = pid and status = 'approved'
             and d between week_start and week_start + 6) then
    raise exception 'Upah pekan ini sudah disetujui, absensi terkunci';
  end if;
  return coalesce(new, old);
end $$;
drop trigger if exists trg_lock_att on attendance;
create trigger trg_lock_att before insert or update or delete on attendance
  for each row execute function fn_lock_attendance();

-- 4) Hitung rekap upah satu pekan (boleh dihitung ulang selama belum disetujui)
create or replace function generate_payroll(p_project uuid, p_week_start date)
returns uuid language plpgsql security definer set search_path = public as $$
declare rid uuid; w record; v_hok numeric; gross numeric; owed numeric; cap numeric; ded numeric;
        pct numeric; tg numeric := 0; td numeric := 0;
begin
  if my_role() not in ('pm','admin_proyek') or not is_member(p_project) then
    raise exception 'Tidak diizinkan'; end if;
  select value::numeric into pct from app_settings where key = 'advance_max_pct';
  pct := coalesce(pct, 50);

  select id into rid from payroll_runs where project_id = p_project and week_start = p_week_start;
  if rid is not null then
    if (select status from payroll_runs where id = rid) = 'approved' then
      raise exception 'Rekap pekan ini sudah disetujui'; end if;
    delete from payroll_lines where run_id = rid;
    update payroll_runs set status = 'submitted', decided_by = null, decided_at = null where id = rid;
  else
    insert into payroll_runs(project_id, week_start, created_by)
    values (p_project, p_week_start, auth.uid()) returning id into rid;
  end if;

  for w in select id, daily_wage from workers where project_id = p_project and is_active loop
    select coalesce(sum(a.hok), 0) into v_hok from attendance a
     where a.worker_id = w.id and a.work_date between p_week_start and p_week_start + 6;
    continue when v_hok = 0;
    gross := v_hok * w.daily_wage;
    select coalesce(sum(amount - repaid), 0) into owed from worker_advances where worker_id = w.id and not settled;
    cap := floor(gross * pct / 100);
    ded := least(owed, cap);
    insert into payroll_lines values (rid, w.id, v_hok, w.daily_wage, gross, ded, gross - ded);
    tg := tg + gross; td := td + ded;
  end loop;

  update payroll_runs set total_gross = tg, total_deduct = td, total_net = tg - td where id = rid;
  perform notify_project_role(p_project, 'pm', 'Rekap upah pekan ' || to_char(p_week_start, 'DD/MM') ||
    ' menunggu persetujuan (total bersih Rp ' || to_char(tg - td, 'FM999G999G999G999') || ').',
    'payroll-' || rid || '-' || extract(epoch from now())::bigint);
  return rid;
end $$;

-- 5) Keputusan PM. Potongan kasbon baru dicatat saat disetujui (FIFO dari kasbon terlama).
create or replace function decide_payroll(p_run uuid, p_approve boolean)
returns approval_status language plpgsql security definer set search_path = public as $$
declare r payroll_runs; l record; a record; left_amt numeric; take numeric;
begin
  if my_role() <> 'pm' then raise exception 'Hanya PM yang dapat memutuskan'; end if;
  select * into r from payroll_runs where id = p_run for update;
  if not found or not is_member(r.project_id) then raise exception 'Rekap tidak ditemukan'; end if;
  if r.status = 'approved' then raise exception 'Sudah disetujui'; end if;

  if not p_approve then
    update payroll_runs set status = 'rejected', decided_by = auth.uid(), decided_at = now() where id = p_run;
    return 'rejected';
  end if;

  for l in select worker_id, advance_deduct from payroll_lines where run_id = p_run and advance_deduct > 0 loop
    left_amt := l.advance_deduct;
    for a in select id, amount, repaid from worker_advances
              where worker_id = l.worker_id and not settled order by given_on, id for update loop
      exit when left_amt <= 0;
      take := least(left_amt, a.amount - a.repaid);
      update worker_advances set repaid = repaid + take, settled = (repaid + take >= amount) where id = a.id;
      left_amt := left_amt - take;
    end loop;
  end loop;

  update payroll_runs set status = 'approved', decided_by = auth.uid(), decided_at = now() where id = p_run;
  perform notify_role('finance', 'Upah pekan ' || to_char(r.week_start, 'DD/MM') ||
    ' disetujui, total bersih Rp ' || to_char(r.total_net, 'FM999G999G999G999') || '. Siap dibayarkan.', 'payroll-ok-' || p_run);
  return 'approved';
end $$;

-- ########## 06_purchase_orders.sql ##########
-- Tahap 6: Supplier, Purchase Order, Surat Jalan, Tagihan. Jalankan setelah 05_payroll.sql.

insert into app_settings values ('po_owner_min', '10000000') on conflict do nothing; -- PO >= ini butuh owner
insert into app_settings values ('po_vat_pct', '0')           on conflict do nothing; -- toleransi PPN tagihan (%)

create table if not exists suppliers (
  id uuid primary key default gen_random_uuid(),
  name text not null, phone text, address text, is_active boolean not null default true
);
create sequence if not exists po_seq;

create table if not exists purchase_orders (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid unique not null,
  project_id  uuid not null references projects(id) on delete cascade,
  supplier_id uuid not null references suppliers(id),
  po_number   text unique,
  po_date     date not null default current_date,
  status      text not null default 'submitted'
              check (status in ('submitted','approved','rejected','partial','received')),
  total       numeric(16,2) not null default 0,
  items       jsonb not null,    -- [{description, unit, qty, unit_price}] dikirim dari HP (aman offline)
  notes       text,
  created_by  uuid not null references profiles(id),
  created_at  timestamptz not null default now()
);
create table if not exists po_items (
  id uuid primary key default gen_random_uuid(),
  po_id uuid not null references purchase_orders(id) on delete cascade,
  line_no int not null, description text not null, unit text not null,
  qty numeric(14,3) not null check (qty > 0),
  unit_price numeric(16,2) not null check (unit_price >= 0)
);
create table if not exists delivery_notes (          -- surat jalan / penerimaan barang
  id uuid primary key default gen_random_uuid(),
  client_id uuid unique not null,
  po_id uuid not null references purchase_orders(id) on delete cascade,
  sj_number text not null,
  received_date date not null default current_date,
  items jsonb not null,          -- [{po_item_id, qty}]
  notes text,
  created_by uuid not null references profiles(id),
  created_at timestamptz not null default now()
);
create table if not exists delivery_items (
  delivery_id uuid not null references delivery_notes(id) on delete cascade,
  po_item_id uuid not null references po_items(id),
  qty numeric(14,3) not null check (qty > 0),
  primary key (delivery_id, po_item_id)
);
create table if not exists supplier_invoices (
  id uuid primary key default gen_random_uuid(),
  client_id uuid unique not null,
  po_id uuid not null references purchase_orders(id) on delete cascade,
  invoice_no text not null,
  amount numeric(16,2) not null check (amount > 0),
  invoice_date date not null default current_date,
  due_date date,
  status text not null default 'unpaid' check (status in ('unpaid','paid')),
  paid_at timestamptz,
  created_by uuid not null references profiles(id)
);
create index if not exists idx_po_project on purchase_orders (project_id, created_at desc);
create index if not exists idx_poi_po on po_items (po_id);
create index if not exists idx_inv_po on supplier_invoices (po_id);

-- ---------- PO: validasi + nomor + total (sebelum insert) ----------
create or replace function fn_po_before() returns trigger language plpgsql as $$
declare t numeric; bad int;
begin
  if jsonb_typeof(new.items) <> 'array' or jsonb_array_length(new.items) = 0 then
    raise exception 'PO harus memiliki minimal satu item'; end if;
  select count(*) into bad from jsonb_array_elements(new.items) i
   where coalesce((i->>'qty')::numeric, 0) <= 0 or coalesce(i->>'description', '') = '';
  if bad > 0 then raise exception 'Item PO tidak valid (nama atau jumlah kosong)'; end if;
  select coalesce(sum((i->>'qty')::numeric * coalesce((i->>'unit_price')::numeric, 0)), 0)
    into t from jsonb_array_elements(new.items) i;
  new.total := t;
  new.status := 'submitted';
  new.po_number := 'PO-' || to_char(coalesce(new.po_date, current_date), 'YYMM') || '-' || lpad(nextval('po_seq')::text, 4, '0');
  return new;
end $$;
drop trigger if exists trg_po_before on purchase_orders;
create trigger trg_po_before before insert on purchase_orders for each row execute function fn_po_before();

-- ---------- PO: pecah item + buat approval + notifikasi (setelah insert) ----------
create or replace function fn_po_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare min_owner numeric;
begin
  insert into po_items(po_id, line_no, description, unit, qty, unit_price)
  select new.id, ord, e->>'description', coalesce(e->>'unit', 'unit'),
         (e->>'qty')::numeric, coalesce((e->>'unit_price')::numeric, 0)
  from jsonb_array_elements(new.items) with ordinality as t(e, ord);

  select value::numeric into min_owner from app_settings where key = 'po_owner_min';
  insert into approvals(project_id, ref_table, ref_id, level, requested_by)
  values (new.project_id, 'purchase_orders', new.id, 1, new.created_by) on conflict do nothing;
  if new.total >= coalesce(min_owner, 10000000) then
    insert into approvals(project_id, ref_table, ref_id, level, requested_by)
    values (new.project_id, 'purchase_orders', new.id, 2, new.created_by) on conflict do nothing;
  end if;
  perform notify_project_role(new.project_id, 'pm', new.po_number || ' senilai Rp ' || to_char(new.total, 'FM999G999G999G999') ||
                      ' menunggu persetujuan Anda.', 'po-new-' || new.id);
  return new;
end $$;
drop trigger if exists trg_po_after on purchase_orders;
create trigger trg_po_after after insert on purchase_orders for each row execute function fn_po_after();

-- ---------- Keputusan PO (PM level 1, owner level 2) ----------
create or replace function decide_po(p_po uuid, p_level smallint, p_approve boolean, p_note text default null)
returns text language plpgsql security definer set search_path = public as $$
declare po purchase_orders; a approvals; v_pending int;
begin
  select * into po from purchase_orders where id = p_po;
  if not found or not is_member(po.project_id) then raise exception 'PO tidak ditemukan'; end if;
  select * into a from approvals where ref_table = 'purchase_orders' and ref_id = p_po and level = p_level for update;
  if not found then raise exception 'Level % tidak diperlukan untuk PO ini', p_level; end if;
  if a.status <> 'submitted' then raise exception 'Sudah diputuskan'; end if;
  if (p_level = 1 and my_role() <> 'pm') or (p_level = 2 and my_role() <> 'owner') then
    raise exception 'Peran Anda tidak boleh memutuskan level %', p_level; end if;
  if p_level = 2 and exists (select 1 from approvals where ref_table = 'purchase_orders'
        and ref_id = p_po and level = 1 and status <> 'approved') then
    raise exception 'Level 1 (PM) harus disetujui lebih dulu'; end if;

  update approvals set status = case when p_approve then 'approved'::approval_status else 'rejected' end,
         decided_by = auth.uid(), decided_at = now(), note = p_note where id = a.id;

  if not p_approve then
    update purchase_orders set status = 'rejected' where id = p_po;
    perform notify_project_role(po.project_id, 'admin_proyek', po.po_number || ' ditolak' || coalesce(': ' || p_note, '') || '.', 'po-no-' || p_po);
    return 'rejected';
  end if;
  select count(*) into v_pending from approvals
   where ref_table = 'purchase_orders' and ref_id = p_po and status <> 'approved';
  if v_pending = 0 then
    update purchase_orders set status = 'approved' where id = p_po;
    perform notify_project_role(po.project_id, 'admin_proyek', po.po_number || ' disetujui. Silakan pesan ke supplier.', 'po-ok-' || p_po);
  elsif p_level = 1 then
    perform notify_role('owner', po.po_number || ' (Rp ' || to_char(po.total, 'FM999G999G999G999') ||
                        ') sudah disetujui PM, menunggu persetujuan Anda.', 'po-l2-' || p_po);
  end if;
  return 'approved';
end $$;

-- ---------- Surat jalan: cek PO, batasi penerimaan, update status ----------
create or replace function fn_delivery_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare po purchase_orders; e jsonb; it po_items; got numeric; q numeric; v_open int;
begin
  select * into po from purchase_orders where id = new.po_id;
  if po.status not in ('approved', 'partial') then
    raise exception '% belum disetujui atau sudah selesai diterima', po.po_number; end if;
  for e in select value from jsonb_array_elements(new.items) loop
    q := coalesce((e->>'qty')::numeric, 0);
    continue when q <= 0;
    select * into it from po_items where id = (e->>'po_item_id')::uuid and po_id = new.po_id;
    if not found then raise exception 'Item tidak ada di PO ini'; end if;
    select coalesce(sum(qty), 0) into got from delivery_items where po_item_id = it.id;
    if got + q > it.qty then
      raise exception 'Penerimaan "%" melebihi pesanan (% %)', it.description, it.qty, it.unit; end if;
    insert into delivery_items values (new.id, it.id, q);
  end loop;
  select count(*) into v_open from po_items pi where pi.po_id = new.po_id
     and pi.qty > (select coalesce(sum(d.qty), 0) from delivery_items d where d.po_item_id = pi.id);
  update purchase_orders set status = case when v_open = 0 then 'received' else 'partial' end where id = new.po_id;
  return new;
end $$;
drop trigger if exists trg_delivery_after on delivery_notes;
create trigger trg_delivery_after after insert on delivery_notes for each row execute function fn_delivery_after();

-- ---------- Pencocokan PO vs barang diterima vs tagihan ----------
create or replace view po_match with (security_invoker = true) as
select p.id as po_id, p.project_id, p.po_number, p.status, p.total as ordered,
       coalesce(r.v, 0) as received_value, coalesce(i.a, 0) as invoiced, coalesce(i.paid, 0) as paid
from purchase_orders p
left join lateral (select sum(d.qty * pi.unit_price) v from delivery_items d
                   join po_items pi on pi.id = d.po_item_id where pi.po_id = p.id) r on true
left join lateral (select sum(amount) a, sum(amount) filter (where status = 'paid') paid
                   from supplier_invoices where po_id = p.id) i on true;

-- ---------- Bayar tagihan (Finance): ditolak bila melebihi nilai barang diterima ----------
create or replace function pay_invoice(p_invoice uuid) returns void
language plpgsql security definer set search_path = public as $$
declare inv supplier_invoices; m record; vat numeric;
begin
  if my_role() <> 'finance' then raise exception 'Hanya Finance yang dapat membayar'; end if;
  select * into inv from supplier_invoices where id = p_invoice for update;
  if not found then raise exception 'Tagihan tidak ditemukan'; end if;
  if inv.status = 'paid' then raise exception 'Tagihan sudah dibayar'; end if;
  select received_value, invoiced into m from po_match where po_id = inv.po_id;
  select coalesce(value::numeric, 0) into vat from app_settings where key = 'po_vat_pct';
  if m.invoiced > m.received_value * (1 + coalesce(vat, 0) / 100) + 1 then
    raise exception 'Total tagihan melebihi nilai barang yang sudah diterima. Cocokkan surat jalan dulu.'; end if;
  update supplier_invoices set status = 'paid', paid_at = now() where id = p_invoice;
end $$;

-- ---------- RLS ----------
alter table suppliers          enable row level security;
alter table purchase_orders    enable row level security;
alter table po_items           enable row level security;
alter table delivery_notes     enable row level security;
alter table delivery_items     enable row level security;
alter table supplier_invoices  enable row level security;

create policy "supplier baca" on suppliers for select using (auth.uid() is not null and my_role() <> 'mandor');
create policy "supplier kelola" on suppliers for all
  using (my_role() in ('admin_proyek','pm','finance')) with check (my_role() in ('admin_proyek','pm','finance'));

create policy "PO baca" on purchase_orders for select using (is_member(project_id) and my_role() <> 'mandor');
create policy "PO buat" on purchase_orders for insert
  with check (my_role() in ('admin_proyek','pm') and is_member(project_id) and created_by = auth.uid());
-- Sengaja tanpa policy update/delete: PO tidak bisa diubah setelah diajukan.

create policy "item PO baca" on po_items for select
  using (exists (select 1 from purchase_orders p where p.id = po_id and is_member(p.project_id)) and my_role() <> 'mandor');

create policy "SJ baca" on delivery_notes for select
  using (exists (select 1 from purchase_orders p where p.id = po_id and is_member(p.project_id)));
create policy "SJ buat" on delivery_notes for insert
  with check (my_role() in ('admin_proyek','pm') and created_by = auth.uid()
    and exists (select 1 from purchase_orders p where p.id = po_id and is_member(p.project_id)));
create policy "item SJ baca" on delivery_items for select
  using (exists (select 1 from delivery_notes d join purchase_orders p on p.id = d.po_id
                 where d.id = delivery_id and is_member(p.project_id)));

create policy "tagihan baca" on supplier_invoices for select
  using (exists (select 1 from purchase_orders p where p.id = po_id and is_member(p.project_id))
         and my_role() in ('admin_proyek','pm','finance','owner'));
create policy "tagihan buat" on supplier_invoices for insert
  with check (my_role() in ('admin_proyek','finance') and created_by = auth.uid()
    and exists (select 1 from purchase_orders p where p.id = po_id and is_member(p.project_id)));

-- Jejak audit
do $$ declare t text; begin
  foreach t in array array['purchase_orders','delivery_notes','supplier_invoices'] loop
    execute format('drop trigger if exists trg_audit on %I', t);
    execute format('create trigger trg_audit after insert or update or delete on %I for each row execute function fn_audit()', t);
  end loop; end $$;

-- ########## 07_dashboard.sql ##########
-- Tahap 7: Dasbor eksekutif. Jalankan setelah 06_purchase_orders.sql.

-- 1) Jadwal rencana mingguan (kurva S rencana), diisi PM/Estimator
create table if not exists project_schedule (
  project_id      uuid not null references projects(id) on delete cascade,
  week_start      date not null,
  planned_cum_pct numeric(5,2) not null check (planned_cum_pct between 0 and 100),
  primary key (project_id, week_start)
);
alter table project_schedule enable row level security;
create policy "jadwal baca" on project_schedule for select using (is_member(project_id));
create policy "jadwal tulis" on project_schedule for all
  using (my_role() in ('pm','estimator') and is_member(project_id))
  with check (my_role() in ('pm','estimator') and is_member(project_id));

-- 2) Persetujuan laporan harian oleh PM (dibutuhkan agar progres masuk kurva S)
create or replace function decide_report(p_report uuid, p_approve boolean, p_note text default null)
returns approval_status language plpgsql security definer set search_path = public as $$
declare r daily_reports;
begin
  if my_role() <> 'pm' then raise exception 'Hanya PM yang dapat memutuskan'; end if;
  select * into r from daily_reports where id = p_report for update;
  if not found or not is_member(r.project_id) then raise exception 'Laporan tidak ditemukan'; end if;
  if r.status <> 'submitted' then raise exception 'Laporan sudah diputuskan'; end if;
  update daily_reports set status = case when p_approve then 'approved'::approval_status else 'rejected' end,
         notes = case when p_approve or p_note is null then notes else coalesce(notes, '') || E'\n[PM] ' || p_note end
   where id = p_report;
  return case when p_approve then 'approved'::approval_status else 'rejected' end;
end $$;

-- 3) Ringkasan dasbor dalam SATU panggilan (hemat egress). Berjalan dengan hak pengguna, jadi RLS tetap berlaku.
create or replace function dashboard_summary(p_project uuid) returns jsonb
language sql stable set search_path = public as $$
select jsonb_build_object(
  'contract_value', (select contract_value from projects where id = p_project),
  'actual_pct',  (select coalesce(max(physical_pct), 0) from daily_reports where project_id = p_project and status = 'approved'),
  'planned_pct', coalesce((select planned_cum_pct from project_schedule
                            where project_id = p_project and week_start <= current_date
                            order by week_start desc limit 1), 0),
  'cash_balance', coalesce((select balance from petty_cash_balance where project_id = p_project), 0),
  'po', (select jsonb_build_object('ordered', coalesce(sum(ordered), 0), 'received', coalesce(sum(received_value), 0),
                                   'invoiced', coalesce(sum(invoiced), 0), 'paid', coalesce(sum(paid), 0))
           from po_match where project_id = p_project and status in ('approved', 'partial', 'received')),
  'pending', (select count(*) from approvals where project_id = p_project and status = 'submitted')
           + (select count(*) from payroll_runs where project_id = p_project and status = 'submitted')
           + (select count(*) from daily_reports where project_id = p_project and status = 'submitted'),
  'curve', coalesce((select jsonb_agg(jsonb_build_object(
              'w', s.week_start, 'plan', s.planned_cum_pct,
              'act', (select case when s.week_start <= current_date then coalesce(max(r.physical_pct), 0) end
                        from daily_reports r where r.project_id = p_project and r.status = 'approved'
                         and r.report_date <= s.week_start + 6)) order by s.week_start)
            from project_schedule s where s.project_id = p_project), '[]'::jsonb)
);
$$;
grant execute on function dashboard_summary(uuid) to authenticated;
revoke execute on function dashboard_summary(uuid) from anon;

-- Contoh isi jadwal (ganti UUID proyek):
-- insert into project_schedule values
--  ('<UUID>', '2026-10-05', 5), ('<UUID>', '2026-10-12', 12), ('<UUID>', '2026-10-19', 22), ('<UUID>', '2026-10-26', 34);

-- ########## 08_finance.sql ##########
-- Tahap 8: Keuangan. Jalankan setelah 07_dashboard.sql.

-- Pengaturan pajak & batas. PERIKSA dengan akuntan/konsultan pajak Anda sebelum dipakai untuk faktur resmi.
--  ppn_pct        : tarif EFEKTIF PPN (12% x DPP nilai lain 11/12 = 11%)
--  pph_final_pct  : PPh Final jasa konstruksi (1,75 kualifikasi kecil | 2,65 menengah/besar | 4 tanpa sertifikat)
--  pay_owner_min  : pembayaran tagihan supplier >= nilai ini butuh persetujuan owner
insert into app_settings values ('ppn_pct', '11'), ('pph_final_pct', '2.65'), ('pay_owner_min', '25000000')
on conflict do nothing;

-- ---------- Termin klien ----------
create table if not exists client_terms (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid unique not null,
  project_id  uuid not null references projects(id) on delete cascade,
  term_no     int not null,
  description text not null,
  pct         numeric(5,2) not null check (pct > 0 and pct <= 100),
  amount      numeric(16,2) not null check (amount > 0),      -- DPP (di luar PPN)
  due_date    date,
  status      text not null default 'planned' check (status in ('planned','invoiced','paid')),
  created_by  uuid not null references profiles(id),
  unique (project_id, term_no)
);

-- ---------- Invoice resmi ke klien ----------
create sequence if not exists inv_seq;
create table if not exists client_invoices (
  id               uuid primary key default gen_random_uuid(),
  project_id       uuid not null references projects(id) on delete cascade,
  term_id          uuid unique not null references client_terms(id),
  invoice_no       text unique not null,
  invoice_date     date not null default current_date,
  dpp              numeric(16,2) not null,
  ppn_amount       numeric(16,2) not null,
  pph_amount       numeric(16,2) not null,      -- PPh Final dipotong pemberi kerja
  retention_amount numeric(16,2) not null,      -- retensi tertahan (default 5%)
  net_receivable   numeric(16,2) not null,      -- DPP + PPN - PPh Final - retensi
  status           text not null default 'issued' check (status in ('issued','paid')),
  paid_at          timestamptz,
  created_by       uuid references profiles(id)
);

alter table client_terms    enable row level security;
alter table client_invoices enable row level security;
create policy "termin baca" on client_terms for select
  using (is_member(project_id) and my_role() in ('pm','finance','owner','estimator'));
create policy "termin kelola" on client_terms for all
  using (my_role() in ('pm','finance') and is_member(project_id) and status = 'planned')
  with check (my_role() in ('pm','finance') and is_member(project_id) and created_by = auth.uid() and status = 'planned');
create policy "invoice baca" on client_invoices for select
  using (is_member(project_id) and my_role() in ('pm','finance','owner'));
-- Invoice dibuat/dilunasi hanya lewat fungsi di bawah.

create or replace function issue_client_invoice(p_term uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare t client_terms; ppn numeric; pph numeric; ret numeric; ret_pct numeric; rid uuid; vat numeric; ph numeric;
begin
  if my_role() <> 'finance' then raise exception 'Hanya Finance yang dapat menerbitkan invoice'; end if;
  select * into t from client_terms where id = p_term for update;
  if not found or not is_member(t.project_id) then raise exception 'Termin tidak ditemukan'; end if;
  if t.status <> 'planned' then raise exception 'Termin sudah ditagihkan'; end if;
  select coalesce(value::numeric, 11) into vat from app_settings where key = 'ppn_pct';
  select coalesce(value::numeric, 2.65) into ph from app_settings where key = 'pph_final_pct';
  select retention_pct into ret_pct from projects where id = t.project_id;
  ppn := round(t.amount * vat / 100, 0);
  pph := round(t.amount * ph / 100, 0);
  ret := round(t.amount * coalesce(ret_pct, 5) / 100, 0);
  insert into client_invoices(project_id, term_id, invoice_no, dpp, ppn_amount, pph_amount, retention_amount, net_receivable, created_by)
  values (t.project_id, t.id, 'INV-' || to_char(current_date, 'YYMM') || '-' || lpad(nextval('inv_seq')::text, 4, '0'),
          t.amount, ppn, pph, ret, t.amount + ppn - pph - ret, auth.uid())
  returning id into rid;
  update client_terms set status = 'invoiced' where id = t.id;
  return rid;
end $$;

create or replace function mark_client_invoice_paid(p_invoice uuid) returns void
language plpgsql security definer set search_path = public as $$
declare i client_invoices;
begin
  if my_role() <> 'finance' then raise exception 'Hanya Finance'; end if;
  select * into i from client_invoices where id = p_invoice for update;
  if not found or not is_member(i.project_id) then raise exception 'Invoice tidak ditemukan'; end if;
  if i.status = 'paid' then raise exception 'Sudah lunas'; end if;
  update client_invoices set status = 'paid', paid_at = now() where id = p_invoice;
  update client_terms set status = 'paid' where id = i.term_id;
end $$;

-- ---------- Pembayaran besar butuh owner (level 2) ----------
alter table supplier_invoices add column if not exists owner_approved boolean not null default false;

create or replace function approve_invoice_payment(p_invoice uuid) returns void
language plpgsql security definer set search_path = public as $$
declare i supplier_invoices; pid uuid;
begin
  if my_role() <> 'owner' then raise exception 'Hanya owner'; end if;
  select * into i from supplier_invoices where id = p_invoice for update;
  if not found then raise exception 'Tagihan tidak ditemukan'; end if;
  update supplier_invoices set owner_approved = true where id = p_invoice;
  perform notify_role('finance', 'Pembayaran tagihan ' || i.invoice_no || ' (Rp ' ||
          to_char(i.amount, 'FM999G999G999G999') || ') disetujui owner.', 'pay-ok-' || p_invoice);
end $$;

-- Cegah klien menyetel status/persetujuan sendiri saat insert tagihan
create or replace function fn_invoice_guard() returns trigger language plpgsql as $$
begin new.status := 'unpaid'; new.paid_at := null; new.owner_approved := false; return new; end $$;
drop trigger if exists trg_invoice_guard on supplier_invoices;
create trigger trg_invoice_guard before insert on supplier_invoices for each row execute function fn_invoice_guard();

create or replace function fn_invoice_notify() returns trigger
language plpgsql security definer set search_path = public as $$
declare lim numeric;
begin
  select coalesce(value::numeric, 25000000) into lim from app_settings where key = 'pay_owner_min';
  if new.amount >= lim then
    perform notify_role('owner', 'Tagihan ' || new.invoice_no || ' senilai Rp ' ||
            to_char(new.amount, 'FM999G999G999G999') || ' menunggu persetujuan pembayaran Anda.', 'pay-req-' || new.id);
  end if;
  return new;
end $$;
drop trigger if exists trg_invoice_notify on supplier_invoices;
create trigger trg_invoice_notify after insert on supplier_invoices for each row execute function fn_invoice_notify();

-- pay_invoice dari tahap 6, ditambah syarat persetujuan owner
create or replace function pay_invoice(p_invoice uuid) returns void
language plpgsql security definer set search_path = public as $$
declare inv supplier_invoices; m record; vat numeric; lim numeric;
begin
  if my_role() <> 'finance' then raise exception 'Hanya Finance yang dapat membayar'; end if;
  select * into inv from supplier_invoices where id = p_invoice for update;
  if not found then raise exception 'Tagihan tidak ditemukan'; end if;
  if inv.status = 'paid' then raise exception 'Tagihan sudah dibayar'; end if;
  select coalesce(value::numeric, 25000000) into lim from app_settings where key = 'pay_owner_min';
  if inv.amount >= lim and not inv.owner_approved then
    raise exception 'Pembayaran sebesar ini harus disetujui owner lebih dulu'; end if;
  select received_value, invoiced into m from po_match where po_id = inv.po_id;
  select coalesce(value::numeric, 0) into vat from app_settings where key = 'po_vat_pct';
  if m.invoiced > m.received_value * (1 + coalesce(vat, 0) / 100) + 1 then
    raise exception 'Total tagihan melebihi nilai barang yang sudah diterima. Cocokkan surat jalan dulu.'; end if;
  update supplier_invoices set status = 'paid', paid_at = now() where id = p_invoice;
end $$;

-- ---------- Ringkasan keuangan proyek (satu panggilan) ----------
create or replace function finance_summary(p_project uuid) returns jsonb
language sql stable set search_path = public as $$
select jsonb_build_object(
  'receivable', coalesce((select sum(net_receivable) from client_invoices where project_id = p_project and status = 'issued'), 0),
  'retention_held', coalesce((select sum(retention_amount) from client_invoices where project_id = p_project), 0),
  'ppn_out', coalesce((select sum(ppn_amount) from client_invoices where project_id = p_project), 0),
  'pph_final', coalesce((select sum(pph_amount) from client_invoices where project_id = p_project), 0),
  'payable', coalesce((select sum(s.amount) from supplier_invoices s join purchase_orders p on p.id = s.po_id
                        where p.project_id = p_project and s.status = 'unpaid'), 0),
  'terms_planned', coalesce((select sum(amount) from client_terms where project_id = p_project and status = 'planned'), 0)
);
$$;
grant execute on function finance_summary(uuid) to authenticated;
revoke execute on function finance_summary(uuid) from anon;

do $$ declare t text; begin
  foreach t in array array['client_terms','client_invoices'] loop
    execute format('drop trigger if exists trg_audit on %I', t);
    execute format('create trigger trg_audit after insert or update or delete on %I for each row execute function fn_audit()', t);
  end loop; end $$;

-- ---------- PENGETATAN (menutup celah dari tahap 1 dan 3) ----------
-- Tanpa ini, pengguna yang membuat data bisa menyetel status 'approved' sendiri lewat API.
create or replace function fn_force_submitted() returns trigger language plpgsql as $$
begin new.status := 'submitted'; return new; end $$;
drop trigger if exists trg_pc_force on petty_cash;
create trigger trg_pc_force before insert on petty_cash for each row execute function fn_force_submitted();

create or replace function fn_report_status_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status in ('approved', 'rejected')
     and (tg_op = 'INSERT' or new.status is distinct from old.status)
     and my_role() <> 'pm' then
    raise exception 'Hanya PM yang dapat menyetujui atau menolak laporan';
  end if;
  return new;
end $$;
drop trigger if exists trg_report_guard on daily_reports;
create trigger trg_report_guard before insert or update on daily_reports
  for each row execute function fn_report_status_guard();

-- ########## 09_handover.sql ##########
-- Tahap 9: Punch list, Serah terima, Retensi. Jalankan setelah 08_finance.sql.

insert into app_settings values ('maintenance_months', '6') on conflict do nothing;  -- masa pemeliharaan (bulan)

-- ---------- Punch list ----------
create table if not exists punch_items (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid unique not null,
  project_id  uuid not null references projects(id) on delete cascade,
  title       text not null,
  location    text,
  status      text not null default 'open' check (status in ('open','fixed','verified')),
  verify_note text,
  created_by  uuid not null references profiles(id),
  created_at  timestamptz not null default now(),
  fixed_at    timestamptz,
  verified_at timestamptz
);
create index if not exists idx_punch_project on punch_items (project_id, status);

-- Perbaikan dicatat sebagai baris tersendiri agar bisa dikirim lewat antrean offline beserta foto
create table if not exists punch_fixes (
  id         uuid primary key default gen_random_uuid(),
  client_id  uuid unique not null,
  punch_id   uuid not null references punch_items(id) on delete cascade,
  note       text,
  created_by uuid not null references profiles(id),
  created_at timestamptz not null default now()
);

create or replace function fn_punch_force_open() returns trigger language plpgsql as $$
begin new.status := 'open'; new.verify_note := null; new.fixed_at := null; new.verified_at := null; return new; end $$;
drop trigger if exists trg_punch_force on punch_items;
create trigger trg_punch_force before insert on punch_items for each row execute function fn_punch_force_open();

create or replace function fn_punch_fix_after() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update punch_items set status = 'fixed', fixed_at = now() where id = new.punch_id and status = 'open';
  return new;
end $$;
drop trigger if exists trg_punch_fix on punch_fixes;
create trigger trg_punch_fix after insert on punch_fixes for each row execute function fn_punch_fix_after();

create or replace function verify_punch(p_id uuid, p_ok boolean, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare p punch_items;
begin
  if my_role() <> 'pm' then raise exception 'Hanya PM yang dapat memvalidasi'; end if;
  select * into p from punch_items where id = p_id for update;
  if not found or not is_member(p.project_id) then raise exception 'Punch list tidak ditemukan'; end if;
  if p.status <> 'fixed' then raise exception 'Item belum ditandai selesai'; end if;
  if p_ok then
    update punch_items set status = 'verified', verified_at = now(), verify_note = p_note where id = p_id;
  else
    update punch_items set status = 'open', fixed_at = null, verify_note = p_note where id = p_id;
  end if;
end $$;

-- ---------- Serah terima & retensi ----------
create table if not exists handovers (
  project_id    uuid primary key references projects(id) on delete cascade,
  handover_date date not null,
  completed_by  uuid references profiles(id),
  created_at    timestamptz not null default now()
);
create table if not exists retention_claims (
  id          uuid primary key default gen_random_uuid(),
  project_id  uuid unique not null references projects(id) on delete cascade,
  amount      numeric(16,2) not null,
  due_date    date not null,
  status      text not null default 'held' check (status in ('held','released')),
  released_at timestamptz
);

create or replace function complete_handover(p_project uuid, p_date date default current_date) returns date
language plpgsql security definer set search_path = public as $$
declare v_open int; v_amt numeric; v_months int; v_due date; v_name text;
begin
  if my_role() <> 'pm' or not is_member(p_project) then raise exception 'Hanya PM proyek ini'; end if;
  if exists (select 1 from handovers where project_id = p_project) then raise exception 'Proyek sudah diserahterimakan'; end if;
  select count(*) into v_open from punch_items where project_id = p_project and status <> 'verified';
  if v_open > 0 then raise exception 'Masih ada % punch list yang belum diverifikasi', v_open; end if;
  select coalesce(sum(retention_amount), 0) into v_amt from client_invoices where project_id = p_project;
  select coalesce(value::int, 6) into v_months from app_settings where key = 'maintenance_months';
  v_due := (p_date + make_interval(months => v_months))::date;
  select name into v_name from projects where id = p_project;

  insert into handovers(project_id, handover_date, completed_by) values (p_project, p_date, auth.uid());
  insert into retention_claims(project_id, amount, due_date) values (p_project, v_amt, v_due);
  update projects set status = 'retention' where id = p_project;

  perform notify_role('finance', 'Serah terima ' || v_name || ' selesai. Retensi Rp ' || to_char(v_amt, 'FM999G999G999G999') ||
                      ' jatuh tempo ' || to_char(v_due, 'DD/MM/YYYY') || '.', 'ho-f-' || p_project);
  perform notify_role('owner', 'Serah terima ' || v_name || ' selesai. Masa pemeliharaan sampai ' || to_char(v_due, 'DD/MM/YYYY') || '.', 'ho-o-' || p_project);
  return v_due;
end $$;

create or replace function release_retention(p_project uuid) returns void
language plpgsql security definer set search_path = public as $$
declare c retention_claims;
begin
  if my_role() <> 'finance' then raise exception 'Hanya Finance'; end if;
  select * into c from retention_claims where project_id = p_project for update;
  if not found then raise exception 'Belum ada retensi (serah terima belum selesai)'; end if;
  if c.status = 'released' then raise exception 'Retensi sudah dicairkan'; end if;
  if current_date < c.due_date then raise exception 'Belum jatuh tempo (%)', to_char(c.due_date, 'DD/MM/YYYY'); end if;
  update retention_claims set status = 'released', released_at = now() where id = c.id;
  update projects set status = 'closed' where id = p_project;
end $$;

-- Pengingat harian: H-14, H-7, dan hari jatuh tempo (dedupe mencegah pesan ganda)
create or replace function retention_reminders() returns void
language plpgsql security definer set search_path = public as $$
declare c record; d int;
begin
  for c in select rc.id, rc.amount, rc.due_date, p.name from retention_claims rc
             join projects p on p.id = rc.project_id where rc.status = 'held'
              and (rc.due_date - current_date) in (14, 7, 0) loop
    d := c.due_date - current_date;
    perform notify_role('finance', 'Retensi ' || c.name || ' Rp ' || to_char(c.amount, 'FM999G999G999G999') ||
            case when d = 0 then ' jatuh tempo HARI INI.' else ' jatuh tempo ' || d || ' hari lagi.' end, 'ret-f-' || c.id || '-' || d);
    perform notify_role('owner', 'Retensi ' || c.name || case when d = 0 then ' jatuh tempo hari ini.' else ' jatuh tempo ' || d || ' hari lagi.' end,
            'ret-o-' || c.id || '-' || d);
  end loop;
end $$;
revoke all on function retention_reminders() from public, anon, authenticated;
select cron.schedule('retensi-harian', '0 1 * * *', 'select retention_reminders()');  -- 08.00 WIB

-- ---------- RLS ----------
alter table punch_items      enable row level security;
alter table punch_fixes      enable row level security;
alter table handovers        enable row level security;
alter table retention_claims enable row level security;

create policy "punch baca" on punch_items for select using (is_member(project_id));
create policy "punch buat" on punch_items for insert
  with check (my_role() in ('mandor','admin_proyek','pm') and is_member(project_id) and created_by = auth.uid());
create policy "perbaikan baca" on punch_fixes for select
  using (exists (select 1 from punch_items p where p.id = punch_id and is_member(p.project_id)));
create policy "perbaikan buat" on punch_fixes for insert
  with check (my_role() in ('mandor','admin_proyek','pm') and created_by = auth.uid()
    and exists (select 1 from punch_items p where p.id = punch_id and is_member(p.project_id)));
create policy "serah terima baca" on handovers for select using (is_member(project_id));
create policy "retensi baca" on retention_claims for select
  using (is_member(project_id) and my_role() in ('pm','finance','owner'));

do $$ declare t text; begin
  foreach t in array array['punch_items','handovers','retention_claims'] loop
    execute format('drop trigger if exists trg_audit on %I', t);
    execute format('create trigger trg_audit after insert or update or delete on %I for each row execute function fn_audit()', t);
  end loop; end $$;

-- ########## 10_subcon_addendum.sql ##########
-- Tahap 10: SPK Subkontraktor + Adendum (tambah/kurang). Jalankan setelah 09_handover.sql.

insert into app_settings values ('spk_owner_min', '50000000') on conflict do nothing;  -- SPK >= ini butuh owner

-- ---------- Master subkontraktor ----------
create table if not exists subcontractors (
  id uuid primary key default gen_random_uuid(),
  name text not null, phone text, is_active boolean not null default true
);

-- ---------- SPK (kontrak borongan) ----------
create sequence if not exists spk_seq;
create table if not exists spk (
  id             uuid primary key default gen_random_uuid(),
  client_id      uuid unique not null,
  project_id     uuid not null references projects(id) on delete cascade,
  subcon_id      uuid not null references subcontractors(id),
  spk_number     text unique,
  title          text not null,
  contract_value numeric(16,2) not null check (contract_value > 0),
  status         text not null default 'submitted' check (status in ('submitted','approved','rejected')),
  created_by     uuid not null references profiles(id),
  created_at     timestamptz not null default now()
);
create table if not exists spk_progress (          -- riwayat progres kumulatif, dicatat PM
  id uuid primary key default gen_random_uuid(),
  spk_id uuid not null references spk(id) on delete cascade,
  pct numeric(5,2) not null check (pct between 0 and 100),
  note text, created_by uuid not null references profiles(id), created_at timestamptz not null default now()
);
create table if not exists spk_payments (
  id uuid primary key default gen_random_uuid(),
  spk_id uuid not null references spk(id) on delete cascade,
  amount numeric(16,2) not null check (amount > 0),
  paid_by uuid not null references profiles(id), paid_at timestamptz not null default now()
);

-- ---------- Adendum (pekerjaan tambah/kurang) ----------
create sequence if not exists add_seq;
create table if not exists addenda (
  id         uuid primary key default gen_random_uuid(),
  client_id  uuid unique not null,
  project_id uuid not null references projects(id) on delete cascade,
  number     text unique,
  title      text not null,
  reason     text,
  items      jsonb not null,       -- [{type:'tambah'|'kurang', description, unit, qty, unit_price}]
  delta      numeric(16,2) not null default 0,   -- tambah dikurangi kurang
  status     text not null default 'submitted' check (status in ('submitted','approved','rejected')),
  created_by uuid not null references profiles(id),
  created_at timestamptz not null default now()
);
alter table projects add column if not exists contract_original numeric(18,2);

-- ---------- Trigger: nomor, total, approval, notifikasi ----------
create or replace function fn_spk_before() returns trigger language plpgsql as $$
begin
  new.status := 'submitted';
  new.spk_number := 'SPK-' || to_char(current_date, 'YYMM') || '-' || lpad(nextval('spk_seq')::text, 4, '0');
  return new;
end $$;
drop trigger if exists trg_spk_before on spk;
create trigger trg_spk_before before insert on spk for each row execute function fn_spk_before();

create or replace function fn_add_before() returns trigger language plpgsql as $$
declare bad int; d numeric;
begin
  if jsonb_typeof(new.items) <> 'array' or jsonb_array_length(new.items) = 0 then
    raise exception 'Adendum harus memiliki minimal satu item'; end if;
  select count(*) into bad from jsonb_array_elements(new.items) i
   where (i->>'type') not in ('tambah','kurang') or coalesce((i->>'qty')::numeric, 0) <= 0 or coalesce(i->>'description', '') = '';
  if bad > 0 then raise exception 'Item adendum tidak valid'; end if;
  select coalesce(sum(case when i->>'type' = 'tambah' then 1 else -1 end
                      * (i->>'qty')::numeric * coalesce((i->>'unit_price')::numeric, 0)), 0)
    into d from jsonb_array_elements(new.items) i;
  new.delta := d; new.status := 'submitted';
  new.number := 'ADD-' || to_char(current_date, 'YYMM') || '-' || lpad(nextval('add_seq')::text, 3, '0');
  return new;
end $$;
drop trigger if exists trg_add_before on addenda;
create trigger trg_add_before before insert on addenda for each row execute function fn_add_before();

create or replace function fn_doc_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare lim numeric; v_val numeric; v_label text;
begin
  insert into approvals(project_id, ref_table, ref_id, level, requested_by)
  values (new.project_id, tg_table_name, new.id, 1, new.created_by) on conflict do nothing;
  if tg_table_name = 'addenda' then
    insert into approvals(project_id, ref_table, ref_id, level, requested_by)
    values (new.project_id, 'addenda', new.id, 2, new.created_by) on conflict do nothing;  -- adendum selalu sampai owner
    v_label := new.number;
  else
    select coalesce(value::numeric, 50000000) into lim from app_settings where key = 'spk_owner_min';
    if new.contract_value >= lim then
      insert into approvals(project_id, ref_table, ref_id, level, requested_by)
      values (new.project_id, 'spk', new.id, 2, new.created_by) on conflict do nothing;
    end if;
    v_label := new.spk_number;
  end if;
  perform notify_project_role(new.project_id, 'pm', v_label || ' menunggu persetujuan Anda.', 'doc-new-' || new.id);
  return new;
end $$;
drop trigger if exists trg_spk_after on spk;
create trigger trg_spk_after after insert on spk for each row execute function fn_doc_after();
drop trigger if exists trg_add_after on addenda;
create trigger trg_add_after after insert on addenda for each row execute function fn_doc_after();

-- ---------- Keputusan umum: SPK dan Adendum (PM level 1, owner level 2) ----------
create or replace function decide_doc(p_table text, p_id uuid, p_level smallint, p_approve boolean, p_note text default null)
returns text language plpgsql security definer set search_path = public as $$
declare v_pid uuid; v_label text; v_delta numeric := 0; a approvals; v_pending int; v_new numeric;
begin
  if p_table = 'spk' then select project_id, spk_number into v_pid, v_label from spk where id = p_id;
  elsif p_table = 'addenda' then select project_id, number, delta into v_pid, v_label, v_delta from addenda where id = p_id;
  else raise exception 'Jenis dokumen tidak dikenal'; end if;
  if v_pid is null or not is_member(v_pid) then raise exception 'Dokumen tidak ditemukan'; end if;

  select * into a from approvals where ref_table = p_table and ref_id = p_id and level = p_level for update;
  if not found then raise exception 'Level % tidak diperlukan', p_level; end if;
  if a.status <> 'submitted' then raise exception 'Sudah diputuskan'; end if;
  if (p_level = 1 and my_role() <> 'pm') or (p_level = 2 and my_role() <> 'owner') then
    raise exception 'Peran Anda tidak boleh memutuskan level %', p_level; end if;
  if p_level = 2 and exists (select 1 from approvals where ref_table = p_table and ref_id = p_id and level = 1 and status <> 'approved') then
    raise exception 'Level 1 (PM) harus disetujui lebih dulu'; end if;

  update approvals set status = case when p_approve then 'approved'::approval_status else 'rejected' end,
         decided_by = auth.uid(), decided_at = now(), note = p_note where id = a.id;

  if not p_approve then
    execute format('update %I set status = ''rejected'' where id = $1', p_table) using p_id;
    return 'rejected';
  end if;
  select count(*) into v_pending from approvals where ref_table = p_table and ref_id = p_id and status <> 'approved';
  if v_pending = 0 then
    execute format('update %I set status = ''approved'' where id = $1', p_table) using p_id;
    if p_table = 'addenda' then
      select contract_value + v_delta into v_new from projects where id = v_pid for update;
      if v_new < 0 then raise exception 'Nilai kontrak tidak boleh negatif'; end if;
      update projects set contract_original = coalesce(contract_original, contract_value), contract_value = v_new where id = v_pid;
      perform notify_role('finance', v_label || ' disetujui. Nilai kontrak menjadi Rp ' || to_char(v_new, 'FM999G999G999G999') || '.', 'doc-ok-' || p_id);
    else
      perform notify_project_role(v_pid, 'pm', v_label || ' disetujui.', 'doc-ok-' || p_id);
    end if;
  elsif p_level = 1 then
    perform notify_role('owner', v_label || ' sudah disetujui PM, menunggu persetujuan Anda.', 'doc-l2-' || p_id);
  end if;
  return 'approved';
end $$;

-- ---------- Progres dan pembayaran SPK ----------
create or replace function set_spk_progress(p_spk uuid, p_pct numeric, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare s spk; cur numeric;
begin
  if my_role() <> 'pm' then raise exception 'Hanya PM yang mencatat progres subkon'; end if;
  select * into s from spk where id = p_spk for update;
  if not found or not is_member(s.project_id) then raise exception 'SPK tidak ditemukan'; end if;
  if s.status <> 'approved' then raise exception 'SPK belum disetujui'; end if;
  select coalesce(max(pct), 0) into cur from spk_progress where spk_id = p_spk;
  if p_pct < cur then raise exception 'Progres tidak boleh turun (saat ini %)', cur; end if;
  if p_pct > 100 then raise exception 'Progres maksimal 100'; end if;
  insert into spk_progress(spk_id, pct, note, created_by) values (p_spk, p_pct, p_note, auth.uid());
end $$;

create or replace function pay_spk(p_spk uuid, p_amount numeric) returns void
language plpgsql security definer set search_path = public as $$
declare s spk; prog numeric; paid numeric; allowed numeric;
begin
  if my_role() <> 'finance' then raise exception 'Hanya Finance yang dapat membayar'; end if;
  select * into s from spk where id = p_spk for update;
  if not found or not is_member(s.project_id) then raise exception 'SPK tidak ditemukan'; end if;
  if s.status <> 'approved' then raise exception 'SPK belum disetujui'; end if;
  select coalesce(max(pct), 0) into prog from spk_progress where spk_id = p_spk;
  select coalesce(sum(amount), 0) into paid from spk_payments where spk_id = p_spk;
  allowed := round(s.contract_value * prog / 100 - paid, 0);
  if p_amount <= 0 or p_amount > allowed then
    raise exception 'Pembayaran melebihi progres yang disetujui. Maksimal saat ini Rp %', to_char(greatest(allowed, 0), 'FM999G999G999G999'); end if;
  insert into spk_payments(spk_id, amount, paid_by) values (p_spk, p_amount, auth.uid());
end $$;

create or replace view spk_summary with (security_invoker = true) as
select s.id, s.project_id, s.spk_number, s.title, s.contract_value, s.status, sc.name as subcon,
       coalesce((select max(pct) from spk_progress where spk_id = s.id), 0) as progress_pct,
       coalesce((select sum(amount) from spk_payments where spk_id = s.id), 0) as paid
from spk s join subcontractors sc on sc.id = s.subcon_id;

-- ---------- RLS ----------
alter table subcontractors enable row level security;
alter table spk            enable row level security;
alter table spk_progress   enable row level security;
alter table spk_payments   enable row level security;
alter table addenda        enable row level security;

create policy "subkon baca" on subcontractors for select using (my_role() in ('pm','finance','owner','estimator'));
create policy "subkon kelola" on subcontractors for all using (my_role() in ('pm','finance')) with check (my_role() in ('pm','finance'));
create policy "spk baca" on spk for select using (is_member(project_id) and my_role() in ('pm','finance','owner','estimator'));
create policy "spk buat" on spk for insert with check (my_role() = 'pm' and is_member(project_id) and created_by = auth.uid());
create policy "progres baca" on spk_progress for select
  using (exists (select 1 from spk s where s.id = spk_id and is_member(s.project_id)) and my_role() in ('pm','finance','owner'));
create policy "bayar baca" on spk_payments for select
  using (exists (select 1 from spk s where s.id = spk_id and is_member(s.project_id)) and my_role() in ('pm','finance','owner'));
create policy "adendum baca" on addenda for select using (is_member(project_id) and my_role() in ('pm','finance','owner','estimator'));
create policy "adendum buat" on addenda for insert
  with check (my_role() in ('estimator','pm') and is_member(project_id) and created_by = auth.uid());
-- Tanpa policy update/delete: dokumen tidak bisa diubah setelah diajukan.

do $$ declare t text; begin
  foreach t in array array['spk','spk_payments','addenda'] loop
    execute format('drop trigger if exists trg_audit on %I', t);
    execute format('create trigger trg_audit after insert or update or delete on %I for each row execute function fn_audit()', t);
  end loop; end $$;

-- ########## 11_equipment.sql ##########
-- Tahap 11: Alat Berat & BBM. Jalankan setelah 10_subcon_addendum.sql.

create table if not exists equipment (
  id           uuid primary key default gen_random_uuid(),
  client_id    uuid unique not null,
  project_id   uuid not null references projects(id) on delete cascade,
  code         text not null,
  name         text not null,
  meter_unit   text not null default 'HM' check (meter_unit in ('HM','KM')),
  ownership    text not null default 'milik' check (ownership in ('milik','sewa')),
  rental_rate  numeric(14,2) not null default 0,                       -- tarif sewa
  rental_basis text not null default 'jam' check (rental_basis in ('jam','hari')),
  fuel_norm    numeric(8,3) not null default 0,                        -- norma liter per HM (atau per KM)
  status       text not null default 'approved' check (status in ('pending','approved','rejected')),
  is_active    boolean not null default true,
  created_by   uuid not null references profiles(id),
  created_at   timestamptz not null default now(),
  unique (project_id, code)
);

create table if not exists equipment_logs (
  id           uuid primary key default gen_random_uuid(),
  client_id    uuid unique not null,
  equipment_id uuid not null references equipment(id) on delete cascade,
  log_date     date not null default current_date,
  meter_start  numeric(10,1) not null,
  meter_end    numeric(10,1) not null,
  fuel_liters  numeric(8,2) not null default 0 check (fuel_liters >= 0),
  fuel_price   numeric(10,2),                                          -- harga per liter (opsional)
  note         text,
  created_by   uuid not null references profiles(id),
  created_at   timestamptz not null default now(),
  check (meter_end >= meter_start),
  unique (equipment_id, log_date)
);
create index if not exists idx_eqlog_date on equipment_logs (equipment_id, log_date desc);

-- Sewa butuh persetujuan owner; milik langsung aktif
create or replace function fn_equipment_before() returns trigger language plpgsql as $$
begin new.status := case when new.ownership = 'sewa' then 'pending' else 'approved' end; return new; end $$;
drop trigger if exists trg_eq_before on equipment;
create trigger trg_eq_before before insert on equipment for each row execute function fn_equipment_before();

create or replace function fn_equipment_after() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'pending' then
    perform notify_role('owner', 'Sewa alat ' || new.name || ' (' || new.code || ') Rp ' ||
            to_char(new.rental_rate, 'FM999G999G999') || '/' || new.rental_basis || ' menunggu persetujuan Anda.', 'eq-req-' || new.id);
  end if;
  return new;
end $$;
drop trigger if exists trg_eq_after on equipment;
create trigger trg_eq_after after insert on equipment for each row execute function fn_equipment_after();

create or replace function approve_equipment(p_id uuid, p_ok boolean) returns void
language plpgsql security definer set search_path = public as $$
declare e equipment;
begin
  if my_role() <> 'owner' then raise exception 'Hanya owner yang menyetujui sewa alat'; end if;
  select * into e from equipment where id = p_id for update;
  if not found then raise exception 'Alat tidak ditemukan'; end if;
  if e.status <> 'pending' then raise exception 'Sudah diputuskan'; end if;
  update equipment set status = case when p_ok then 'approved' else 'rejected' end where id = p_id;
  perform notify_project_role(e.project_id, 'admin_proyek', 'Sewa alat ' || e.name || (case when p_ok then ' disetujui.' else ' ditolak.' end), 'eq-dec-' || p_id);
end $$;

-- Log hanya untuk alat yang sudah disetujui
create or replace function fn_eqlog_before() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from equipment where id = new.equipment_id and status = 'approved' and is_active) then
    raise exception 'Alat belum disetujui atau tidak aktif'; end if;
  return new;
end $$;
drop trigger if exists trg_eqlog_before on equipment_logs;
create trigger trg_eqlog_before before insert on equipment_logs for each row execute function fn_eqlog_before();

-- Rekap bulanan: pemakaian, BBM, konsumsi per HM/KM, biaya sewa dan BBM
create or replace view equipment_usage with (security_invoker = true) as
select e.id as equipment_id, e.project_id, e.code, e.name, e.meter_unit, e.ownership, e.fuel_norm,
       date_trunc('month', l.log_date)::date as month,
       count(*) as days,
       sum(l.meter_end - l.meter_start) as usage,
       sum(l.fuel_liters) as fuel_liters,
       case when sum(l.meter_end - l.meter_start) > 0 then round(sum(l.fuel_liters) / sum(l.meter_end - l.meter_start), 3) end as per_unit,
       case when e.ownership = 'sewa' then
         case e.rental_basis when 'jam' then sum(l.meter_end - l.meter_start) * e.rental_rate else count(*) * e.rental_rate end
       else 0 end as rental_cost,
       coalesce(sum(l.fuel_liters * l.fuel_price), 0) as fuel_cost
from equipment e join equipment_logs l on l.equipment_id = e.id
group by e.id, date_trunc('month', l.log_date);

-- Pemeriksaan log: loncatan meter (gap) dan konsumsi di atas norma
create or replace view equipment_log_check with (security_invoker = true) as
select l.id, l.equipment_id, l.log_date, l.meter_start, l.meter_end, l.fuel_liters,
       l.meter_end - l.meter_start as usage,
       case when l.meter_end > l.meter_start then round(l.fuel_liters / (l.meter_end - l.meter_start), 3) end as per_unit,
       l.meter_start - lag(l.meter_end) over (partition by l.equipment_id order by l.log_date) as gap_prev,
       e.fuel_norm
from equipment_logs l join equipment e on e.id = l.equipment_id;

-- RLS
alter table equipment      enable row level security;
alter table equipment_logs enable row level security;
create policy "alat baca" on equipment for select using (is_member(project_id) and my_role() <> 'mandor');
create policy "alat buat" on equipment for insert
  with check (my_role() in ('admin_proyek','pm') and is_member(project_id) and created_by = auth.uid());
create policy "log alat baca" on equipment_logs for select
  using (exists (select 1 from equipment e where e.id = equipment_id and is_member(e.project_id)) and my_role() <> 'mandor');
create policy "log alat buat" on equipment_logs for insert
  with check (my_role() in ('admin_proyek','pm') and created_by = auth.uid()
    and exists (select 1 from equipment e where e.id = equipment_id and is_member(e.project_id)));

do $$ declare t text; begin
  foreach t in array array['equipment','equipment_logs'] loop
    execute format('drop trigger if exists trg_audit on %I', t);
    execute format('create trigger trg_audit after insert or update or delete on %I for each row execute function fn_audit()', t);
  end loop; end $$;

-- ########## 12_drawings_archive.sql ##########
-- Tahap 12: Gambar kerja (berversi) + Arsip & rekap tahunan. Jalankan setelah 11_equipment.sql.
-- Buat bucket privat 'drawings' di Dashboard > Storage (public = false) sebelum memakai fitur ini.

-- ---------- Gambar kerja ----------
create table if not exists drawings (
  id         uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  code       text not null,
  title      text not null,
  category   text not null default 'shop' check (category in ('shop','as_built','struktur','arsitektur','mep')),
  created_by uuid not null references profiles(id),
  created_at timestamptz not null default now(),
  unique (project_id, code)
);
create table if not exists drawing_versions (
  id           uuid primary key default gen_random_uuid(),
  drawing_id   uuid not null references drawings(id) on delete cascade,
  version      int not null,
  storage_path text not null unique,
  mime_type    text not null,
  size_bytes   integer not null,
  note         text,
  is_current   boolean not null default true,
  created_by   uuid not null references profiles(id),
  created_at   timestamptz not null default now(),
  unique (drawing_id, version)
);
create index if not exists idx_dv_drawing on drawing_versions (drawing_id, version desc);

create or replace function create_drawing(p_project uuid, p_code text, p_title text, p_category text default 'shop')
returns uuid language plpgsql security definer set search_path = public as $$
declare rid uuid;
begin
  if my_role() not in ('pm','estimator') or not is_member(p_project) then raise exception 'Tidak diizinkan'; end if;
  if coalesce(trim(p_code), '') = '' or coalesce(trim(p_title), '') = '' then raise exception 'Kode dan judul wajib diisi'; end if;
  insert into drawings(project_id, code, title, category, created_by)
  values (p_project, trim(p_code), trim(p_title), p_category, auth.uid()) returning id into rid;
  return rid;
exception when unique_violation then raise exception 'Kode gambar % sudah ada', p_code;
end $$;

create or replace function register_drawing_version(p_drawing uuid, p_path text, p_mime text, p_size int, p_note text default null)
returns int language plpgsql security definer set search_path = public as $$
declare d drawings; v int;
begin
  select * into d from drawings where id = p_drawing for update;
  if not found or my_role() not in ('pm','estimator') or not is_member(d.project_id) then raise exception 'Tidak diizinkan'; end if;
  if split_part(p_path, '/', 1) <> d.project_id::text then raise exception 'Lokasi file tidak sesuai proyek'; end if;
  select coalesce(max(version), 0) + 1 into v from drawing_versions where drawing_id = p_drawing;
  update drawing_versions set is_current = false where drawing_id = p_drawing;
  insert into drawing_versions(drawing_id, version, storage_path, mime_type, size_bytes, note, created_by)
  values (p_drawing, v, p_path, p_mime, p_size, p_note, auth.uid());
  if v > 1 then
    perform notify_project_role(d.project_id, 'mandor', 'Gambar ' || d.code || ' (' || d.title || ') direvisi ke versi ' || v ||
            '. Gunakan versi terbaru.', 'dwg-' || p_drawing || '-' || v);
  end if;
  return v;
end $$;

alter table drawings         enable row level security;
alter table drawing_versions enable row level security;
create policy "gambar baca" on drawings for select using (is_member(project_id));
create policy "versi baca" on drawing_versions for select
  using (exists (select 1 from drawings d where d.id = drawing_id and is_member(d.project_id)));
-- Tulis hanya lewat fungsi di atas.

-- Storage: folder pertama = project_id
create policy "gambar: anggota baca" on storage.objects for select to authenticated
  using (bucket_id = 'drawings' and is_member(((storage.foldername(name))[1])::uuid));
create policy "gambar: PM/estimator unggah" on storage.objects for insert to authenticated
  with check (bucket_id = 'drawings' and my_role() in ('pm','estimator') and is_member(((storage.foldername(name))[1])::uuid));
create policy "gambar: PM/estimator hapus (batal unggah)" on storage.objects for delete to authenticated
  using (bucket_id = 'drawings' and my_role() in ('pm','estimator') and is_member(((storage.foldername(name))[1])::uuid)
         and not exists (select 1 from drawing_versions v where v.storage_path = name));

do $$ declare t text; begin
  foreach t in array array['drawings','drawing_versions'] loop
    execute format('drop trigger if exists trg_audit on %I', t);
    execute format('create trigger trg_audit after insert or update or delete on %I for each row execute function fn_audit()', t);
  end loop; end $$;

-- ---------- Rekap tahunan lintas proyek (dasar KAS, berjalan dengan hak pengguna sehingga RLS berlaku) ----------
-- Pendapatan = DPP invoice klien pada tahun itu. Biaya = tagihan supplier dibayar + upah disetujui + pembayaran SPK
--            + kas keluar disetujui + sewa alat dan BBM. Ini perkiraan manajemen, bukan laporan akuntansi.
create or replace function yearly_summary(p_year int) returns jsonb
language sql stable set search_path = public as $$
with rev as (select project_id, sum(dpp) v from client_invoices where extract(year from invoice_date) = p_year group by 1),
sup as (select p.project_id, sum(s.amount) v from supplier_invoices s join purchase_orders p on p.id = s.po_id
         where s.status = 'paid' and extract(year from s.paid_at) = p_year group by 1),
pay as (select project_id, sum(total_net) v from payroll_runs where status = 'approved' and extract(year from week_start) = p_year group by 1),
spkp as (select s.project_id, sum(x.amount) v from spk_payments x join spk s on s.id = x.spk_id where extract(year from x.paid_at) = p_year group by 1),
pet as (select project_id, sum(amount) v from petty_cash where status = 'approved' and direction = 'out' and extract(year from tx_date) = p_year group by 1),
eqp as (select project_id, sum(rental_cost + fuel_cost) v from equipment_usage where extract(year from month) = p_year group by 1),
calc as (
  select pr.id, pr.name, pr.status, pr.contract_value,
         coalesce(rev.v, 0) as revenue,
         coalesce(sup.v, 0) + coalesce(pay.v, 0) + coalesce(spkp.v, 0) + coalesce(pet.v, 0) + coalesce(eqp.v, 0) as cost
  from projects pr
  left join rev on rev.project_id = pr.id left join sup on sup.project_id = pr.id left join pay on pay.project_id = pr.id
  left join spkp on spkp.project_id = pr.id left join pet on pet.project_id = pr.id left join eqp on eqp.project_id = pr.id)
select jsonb_build_object('year', p_year,
  'projects', coalesce(jsonb_agg(jsonb_build_object('id', id, 'name', name, 'status', status, 'contract', contract_value,
                'revenue', revenue, 'cost', cost) order by name) filter (where revenue > 0 or cost > 0), '[]'::jsonb))
from calc;
$$;
grant execute on function yearly_summary(int) to authenticated;
revoke execute on function yearly_summary(int) from anon;

-- ########## 13_errors.sql ##########
-- Tahap 13: Log error dari aplikasi (agar bug saat update fitur mudah dilacak). Jalankan setelah 12.
create table if not exists client_errors (
  id         bigserial primary key,
  user_id    uuid default auth.uid(),
  source     text not null,                 -- modul atau jenis (mis. 'ErrorBoundary:kas-kecil', 'window.error')
  message    text not null,
  stack      text,
  url        text,
  user_agent text,
  app_version text,
  at         timestamptz not null default now()
);
create index if not exists idx_client_errors_at on client_errors (at desc);
alter table client_errors enable row level security;

-- Setiap pengguna login boleh menulis, hanya owner yang boleh membaca
create policy "error tulis" on client_errors for insert to authenticated
  with check (user_id = auth.uid() and length(message) < 2000 and length(coalesce(stack, '')) < 6000);
create policy "error baca owner" on client_errors for select using (my_role() = 'owner');

-- Bersihkan log lama (90 hari) tiap Minggu dini hari
select cron.schedule('bersih-error', '0 20 * * 0', $$delete from client_errors where at < now() - interval '90 days'$$);

-- ########## 14_masterdata.sql ##########
-- Tahap 14: Master data (proyek, anggota, RAB). Jalankan setelah 13_errors.sql.

-- Daftar anggota proyek bisa dibaca sendiri, serta oleh owner dan PM
create policy "anggota baca" on project_members for select
  using (user_id = auth.uid() or my_role() in ('owner', 'pm'));

-- Buat proyek (pembuatnya otomatis menjadi anggota agar proyek langsung terlihat)
create or replace function create_project(p_code text, p_name text, p_client text, p_contract numeric,
                                          p_start date default null, p_end date default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare rid uuid;
begin
  if my_role() not in ('pm', 'owner') then raise exception 'Hanya PM atau owner yang dapat membuat proyek'; end if;
  if coalesce(trim(p_code), '') = '' or coalesce(trim(p_name), '') = '' or coalesce(trim(p_client), '') = '' then
    raise exception 'Kode, nama, dan klien wajib diisi'; end if;
  if p_contract is null or p_contract < 0 then raise exception 'Nilai kontrak tidak valid'; end if;
  if p_start is not null and p_end is not null and p_end < p_start then raise exception 'Tanggal selesai sebelum tanggal mulai'; end if;
  insert into projects(code, name, client_name, contract_value, start_date, end_date, status)
  values (trim(p_code), trim(p_name), trim(p_client), p_contract, p_start, p_end, 'active') returning id into rid;
  insert into project_members(project_id, user_id) values (rid, auth.uid()) on conflict do nothing;
  return rid;
exception when unique_violation then raise exception 'Kode proyek % sudah dipakai', p_code;
end $$;

-- Tambah atau keluarkan anggota proyek
create or replace function set_project_member(p_project uuid, p_user uuid, p_on boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if my_role() not in ('pm', 'owner') or not is_member(p_project) then raise exception 'Tidak diizinkan'; end if;
  if not exists (select 1 from profiles where id = p_user and is_active) then raise exception 'Pengguna tidak ditemukan atau tidak aktif'; end if;
  if p_on then insert into project_members(project_id, user_id) values (p_project, p_user) on conflict do nothing;
  else delete from project_members where project_id = p_project and user_id = p_user; end if;
end $$;

-- Impor RAB massal (atomik: gagal satu baris = tidak ada yang masuk). Kode yang sudah ada diperbarui.
create or replace function import_rab(p_project uuid, p_rows jsonb) returns int
language plpgsql security definer set search_path = public as $$
declare n int; dup text;
begin
  if my_role() not in ('estimator', 'pm') or not is_member(p_project) then raise exception 'Tidak diizinkan'; end if;
  if jsonb_typeof(p_rows) <> 'array' or jsonb_array_length(p_rows) = 0 then raise exception 'Tidak ada baris untuk diimpor'; end if;
  if jsonb_array_length(p_rows) > 2000 then raise exception 'Maksimal 2000 baris per impor'; end if;
  if exists (select 1 from jsonb_array_elements(p_rows) r
              where coalesce(trim(r->>'code'), '') = '' or coalesce(trim(r->>'description'), '') = ''
                 or coalesce((r->>'volume')::numeric, -1) < 0 or coalesce((r->>'unit_price')::numeric, -1) < 0) then
    raise exception 'Ada baris tidak valid (kode, uraian, volume, atau harga kosong atau negatif)'; end if;
  select trim(r->>'code') into dup from jsonb_array_elements(p_rows) r group by trim(r->>'code') having count(*) > 1 limit 1;
  if dup is not null then raise exception 'Kode ganda dalam file: %', dup; end if;

  insert into rab_items(project_id, code, description, unit, volume, unit_price)
  select p_project, trim(r->>'code'), trim(r->>'description'), coalesce(nullif(trim(r->>'unit'), ''), 'ls'),
         (r->>'volume')::numeric, (r->>'unit_price')::numeric
    from jsonb_array_elements(p_rows) r
  on conflict (project_id, code) do update
     set description = excluded.description, unit = excluded.unit, volume = excluded.volume, unit_price = excluded.unit_price;
  get diagnostics n = row_count;
  return n;
end $$;

commit;
