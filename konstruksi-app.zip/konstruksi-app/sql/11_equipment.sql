-- Tahap 11: Alat Berat & BBM. Jalankan setelah 10_subcon_addendum.sql.

create table if not exists equipment (
  id           uuid primary key default gen_random_uuid(),
  client_id    uuid unique not null,
  project_id   uuid not null references projects(id) on delete cascade,
  code         text not null,
  name         text not null,
  meter_unit   text not null default 'HM' check (meter_unit in ('HM','KM')),
  ownership    text not null default 'milik' check (ownership in ('milik','sewa')),
  rental_rate  numeric(14,2) not null default 0,                       -- tarif sewa
  rental_basis text not null default 'jam' check (rental_basis in ('jam','hari')),
  fuel_norm    numeric(8,3) not null default 0,                        -- norma liter per HM (atau per KM)
  status       text not null default 'approved' check (status in ('pending','approved','rejected')),
  is_active    boolean not null default true,
  created_by   uuid not null references profiles(id),
  created_at   timestamptz not null default now(),
  unique (project_id, code)
);

create table if not exists equipment_logs (
  id           uuid primary key default gen_random_uuid(),
  client_id    uuid unique not null,
  equipment_id uuid not null references equipment(id) on delete cascade,
  log_date     date not null default current_date,
  meter_start  numeric(10,1) not null,
  meter_end    numeric(10,1) not null,
  fuel_liters  numeric(8,2) not null default 0 check (fuel_liters >= 0),
  fuel_price   numeric(10,2),                                          -- harga per liter (opsional)
  note         text,
  created_by   uuid not null references profiles(id),
  created_at   timestamptz not null default now(),
  check (meter_end >= meter_start),
  unique (equipment_id, log_date)
);
create index if not exists idx_eqlog_date on equipment_logs (equipment_id, log_date desc);

-- Sewa butuh persetujuan owner; milik langsung aktif
create or replace function fn_equipment_before() returns trigger language plpgsql as $$
begin new.status := case when new.ownership = 'sewa' then 'pending' else 'approved' end; return new; end $$;
drop trigger if exists trg_eq_before on equipment;
create trigger trg_eq_before before insert on equipment for each row execute function fn_equipment_before();

create or replace function fn_equipment_after() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status = 'pending' then
    perform notify_role('owner', 'Sewa alat ' || new.name || ' (' || new.code || ') Rp ' ||
            to_char(new.rental_rate, 'FM999G999G999') || '/' || new.rental_basis || ' menunggu persetujuan Anda.', 'eq-req-' || new.id);
  end if;
  return new;
end $$;
drop trigger if exists trg_eq_after on equipment;
create trigger trg_eq_after after insert on equipment for each row execute function fn_equipment_after();

create or replace function approve_equipment(p_id uuid, p_ok boolean) returns void
language plpgsql security definer set search_path = public as $$
declare e equipment;
begin
  if my_role() <> 'owner' then raise exception 'Hanya owner yang menyetujui sewa alat'; end if;
  select * into e from equipment where id = p_id for update;
  if not found then raise exception 'Alat tidak ditemukan'; end if;
  if e.status <> 'pending' then raise exception 'Sudah diputuskan'; end if;
  update equipment set status = case when p_ok then 'approved' else 'rejected' end where id = p_id;
  perform notify_project_role(e.project_id, 'admin_proyek', 'Sewa alat ' || e.name || (case when p_ok then ' disetujui.' else ' ditolak.' end), 'eq-dec-' || p_id);
end $$;

-- Log hanya untuk alat yang sudah disetujui
create or replace function fn_eqlog_before() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from equipment where id = new.equipment_id and status = 'approved' and is_active) then
    raise exception 'Alat belum disetujui atau tidak aktif'; end if;
  return new;
end $$;
drop trigger if exists trg_eqlog_before on equipment_logs;
create trigger trg_eqlog_before before insert on equipment_logs for each row execute function fn_eqlog_before();

-- Rekap bulanan: pemakaian, BBM, konsumsi per HM/KM, biaya sewa dan BBM
create or replace view equipment_usage with (security_invoker = true) as
select e.id as equipment_id, e.project_id, e.code, e.name, e.meter_unit, e.ownership, e.fuel_norm,
       date_trunc('month', l.log_date)::date as month,
       count(*) as days,
       sum(l.meter_end - l.meter_start) as usage,
       sum(l.fuel_liters) as fuel_liters,
       case when sum(l.meter_end - l.meter_start) > 0 then round(sum(l.fuel_liters) / sum(l.meter_end - l.meter_start), 3) end as per_unit,
       case when e.ownership = 'sewa' then
         case e.rental_basis when 'jam' then sum(l.meter_end - l.meter_start) * e.rental_rate else count(*) * e.rental_rate end
       else 0 end as rental_cost,
       coalesce(sum(l.fuel_liters * l.fuel_price), 0) as fuel_cost
from equipment e join equipment_logs l on l.equipment_id = e.id
group by e.id, date_trunc('month', l.log_date);

-- Pemeriksaan log: loncatan meter (gap) dan konsumsi di atas norma
create or replace view equipment_log_check with (security_invoker = true) as
select l.id, l.equipment_id, l.log_date, l.meter_start, l.meter_end, l.fuel_liters,
       l.meter_end - l.meter_start as usage,
       case when l.meter_end > l.meter_start then round(l.fuel_liters / (l.meter_end - l.meter_start), 3) end as per_unit,
       l.meter_start - lag(l.meter_end) over (partition by l.equipment_id order by l.log_date) as gap_prev,
       e.fuel_norm
from equipment_logs l join equipment e on e.id = l.equipment_id;

-- RLS
alter table equipment      enable row level security;
alter table equipment_logs enable row level security;
create policy "alat baca" on equipment for select using (is_member(project_id) and my_role() <> 'mandor');
create policy "alat buat" on equipment for insert
  with check (my_role() in ('admin_proyek','pm') and is_member(project_id) and created_by = auth.uid());
create policy "log alat baca" on equipment_logs for select
  using (exists (select 1 from equipment e where e.id = equipment_id and is_member(e.project_id)) and my_role() <> 'mandor');
create policy "log alat buat" on equipment_logs for insert
  with check (my_role() in ('admin_proyek','pm') and created_by = auth.uid()
    and exists (select 1 from equipment e where e.id = equipment_id and is_member(e.project_id)));

do $$ declare t text; begin
  foreach t in array array['equipment','equipment_logs'] loop
    execute format('drop trigger if exists trg_audit on %I', t);
    execute format('create trigger trg_audit after insert or update or delete on %I for each row execute function fn_audit()', t);
  end loop; end $$;
