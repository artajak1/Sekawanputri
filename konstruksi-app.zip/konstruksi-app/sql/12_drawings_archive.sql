-- Tahap 12: Gambar kerja (berversi) + Arsip & rekap tahunan. Jalankan setelah 11_equipment.sql.
-- Buat bucket privat 'drawings' di Dashboard > Storage (public = false) sebelum memakai fitur ini.

-- ---------- Gambar kerja ----------
create table if not exists drawings (
  id         uuid primary key default gen_random_uuid(),
  project_id uuid not null references projects(id) on delete cascade,
  code       text not null,
  title      text not null,
  category   text not null default 'shop' check (category in ('shop','as_built','struktur','arsitektur','mep')),
  created_by uuid not null references profiles(id),
  created_at timestamptz not null default now(),
  unique (project_id, code)
);
create table if not exists drawing_versions (
  id           uuid primary key default gen_random_uuid(),
  drawing_id   uuid not null references drawings(id) on delete cascade,
  version      int not null,
  storage_path text not null unique,
  mime_type    text not null,
  size_bytes   integer not null,
  note         text,
  is_current   boolean not null default true,
  created_by   uuid not null references profiles(id),
  created_at   timestamptz not null default now(),
  unique (drawing_id, version)
);
create index if not exists idx_dv_drawing on drawing_versions (drawing_id, version desc);

create or replace function create_drawing(p_project uuid, p_code text, p_title text, p_category text default 'shop')
returns uuid language plpgsql security definer set search_path = public as $$
declare rid uuid;
begin
  if my_role() not in ('pm','estimator') or not is_member(p_project) then raise exception 'Tidak diizinkan'; end if;
  if coalesce(trim(p_code), '') = '' or coalesce(trim(p_title), '') = '' then raise exception 'Kode dan judul wajib diisi'; end if;
  insert into drawings(project_id, code, title, category, created_by)
  values (p_project, trim(p_code), trim(p_title), p_category, auth.uid()) returning id into rid;
  return rid;
exception when unique_violation then raise exception 'Kode gambar % sudah ada', p_code;
end $$;

create or replace function register_drawing_version(p_drawing uuid, p_path text, p_mime text, p_size int, p_note text default null)
returns int language plpgsql security definer set search_path = public as $$
declare d drawings; v int;
begin
  select * into d from drawings where id = p_drawing for update;
  if not found or my_role() not in ('pm','estimator') or not is_member(d.project_id) then raise exception 'Tidak diizinkan'; end if;
  if split_part(p_path, '/', 1) <> d.project_id::text then raise exception 'Lokasi file tidak sesuai proyek'; end if;
  select coalesce(max(version), 0) + 1 into v from drawing_versions where drawing_id = p_drawing;
  update drawing_versions set is_current = false where drawing_id = p_drawing;
  insert into drawing_versions(drawing_id, version, storage_path, mime_type, size_bytes, note, created_by)
  values (p_drawing, v, p_path, p_mime, p_size, p_note, auth.uid());
  if v > 1 then
    perform notify_project_role(d.project_id, 'mandor', 'Gambar ' || d.code || ' (' || d.title || ') direvisi ke versi ' || v ||
            '. Gunakan versi terbaru.', 'dwg-' || p_drawing || '-' || v);
  end if;
  return v;
end $$;

alter table drawings         enable row level security;
alter table drawing_versions enable row level security;
create policy "gambar baca" on drawings for select using (is_member(project_id));
create policy "versi baca" on drawing_versions for select
  using (exists (select 1 from drawings d where d.id = drawing_id and is_member(d.project_id)));
-- Tulis hanya lewat fungsi di atas.

-- Storage: folder pertama = project_id
create policy "gambar: anggota baca" on storage.objects for select to authenticated
  using (bucket_id = 'drawings' and is_member(((storage.foldername(name))[1])::uuid));
create policy "gambar: PM/estimator unggah" on storage.objects for insert to authenticated
  with check (bucket_id = 'drawings' and my_role() in ('pm','estimator') and is_member(((storage.foldername(name))[1])::uuid));
create policy "gambar: PM/estimator hapus (batal unggah)" on storage.objects for delete to authenticated
  using (bucket_id = 'drawings' and my_role() in ('pm','estimator') and is_member(((storage.foldername(name))[1])::uuid)
         and not exists (select 1 from drawing_versions v where v.storage_path = name));

do $$ declare t text; begin
  foreach t in array array['drawings','drawing_versions'] loop
    execute format('drop trigger if exists trg_audit on %I', t);
    execute format('create trigger trg_audit after insert or update or delete on %I for each row execute function fn_audit()', t);
  end loop; end $$;

-- ---------- Rekap tahunan lintas proyek (dasar KAS, berjalan dengan hak pengguna sehingga RLS berlaku) ----------
-- Pendapatan = DPP invoice klien pada tahun itu. Biaya = tagihan supplier dibayar + upah disetujui + pembayaran SPK
--            + kas keluar disetujui + sewa alat dan BBM. Ini perkiraan manajemen, bukan laporan akuntansi.
create or replace function yearly_summary(p_year int) returns jsonb
language sql stable set search_path = public as $$
with rev as (select project_id, sum(dpp) v from client_invoices where extract(year from invoice_date) = p_year group by 1),
sup as (select p.project_id, sum(s.amount) v from supplier_invoices s join purchase_orders p on p.id = s.po_id
         where s.status = 'paid' and extract(year from s.paid_at) = p_year group by 1),
pay as (select project_id, sum(total_net) v from payroll_runs where status = 'approved' and extract(year from week_start) = p_year group by 1),
spkp as (select s.project_id, sum(x.amount) v from spk_payments x join spk s on s.id = x.spk_id where extract(year from x.paid_at) = p_year group by 1),
pet as (select project_id, sum(amount) v from petty_cash where status = 'approved' and direction = 'out' and extract(year from tx_date) = p_year group by 1),
eqp as (select project_id, sum(rental_cost + fuel_cost) v from equipment_usage where extract(year from month) = p_year group by 1),
calc as (
  select pr.id, pr.name, pr.status, pr.contract_value,
         coalesce(rev.v, 0) as revenue,
         coalesce(sup.v, 0) + coalesce(pay.v, 0) + coalesce(spkp.v, 0) + coalesce(pet.v, 0) + coalesce(eqp.v, 0) as cost
  from projects pr
  left join rev on rev.project_id = pr.id left join sup on sup.project_id = pr.id left join pay on pay.project_id = pr.id
  left join spkp on spkp.project_id = pr.id left join pet on pet.project_id = pr.id left join eqp on eqp.project_id = pr.id)
select jsonb_build_object('year', p_year,
  'projects', coalesce(jsonb_agg(jsonb_build_object('id', id, 'name', name, 'status', status, 'contract', contract_value,
                'revenue', revenue, 'cost', cost) order by name) filter (where revenue > 0 or cost > 0), '[]'::jsonb))
from calc;
$$;
grant execute on function yearly_summary(int) to authenticated;
revoke execute on function yearly_summary(int) from anon;
