-- Tahap 14: Master data (proyek, anggota, RAB). Jalankan setelah 13_errors.sql.

-- Daftar anggota proyek bisa dibaca sendiri, serta oleh owner dan PM
create policy "anggota baca" on project_members for select
  using (user_id = auth.uid() or my_role() in ('owner', 'pm'));

-- Buat proyek (pembuatnya otomatis menjadi anggota agar proyek langsung terlihat)
create or replace function create_project(p_code text, p_name text, p_client text, p_contract numeric,
                                          p_start date default null, p_end date default null)
returns uuid language plpgsql security definer set search_path = public as $$
declare rid uuid;
begin
  if my_role() not in ('pm', 'owner') then raise exception 'Hanya PM atau owner yang dapat membuat proyek'; end if;
  if coalesce(trim(p_code), '') = '' or coalesce(trim(p_name), '') = '' or coalesce(trim(p_client), '') = '' then
    raise exception 'Kode, nama, dan klien wajib diisi'; end if;
  if p_contract is null or p_contract < 0 then raise exception 'Nilai kontrak tidak valid'; end if;
  if p_start is not null and p_end is not null and p_end < p_start then raise exception 'Tanggal selesai sebelum tanggal mulai'; end if;
  insert into projects(code, name, client_name, contract_value, start_date, end_date, status)
  values (trim(p_code), trim(p_name), trim(p_client), p_contract, p_start, p_end, 'active') returning id into rid;
  insert into project_members(project_id, user_id) values (rid, auth.uid()) on conflict do nothing;
  return rid;
exception when unique_violation then raise exception 'Kode proyek % sudah dipakai', p_code;
end $$;

-- Tambah atau keluarkan anggota proyek
create or replace function set_project_member(p_project uuid, p_user uuid, p_on boolean) returns void
language plpgsql security definer set search_path = public as $$
begin
  if my_role() not in ('pm', 'owner') or not is_member(p_project) then raise exception 'Tidak diizinkan'; end if;
  if not exists (select 1 from profiles where id = p_user and is_active) then raise exception 'Pengguna tidak ditemukan atau tidak aktif'; end if;
  if p_on then insert into project_members(project_id, user_id) values (p_project, p_user) on conflict do nothing;
  else delete from project_members where project_id = p_project and user_id = p_user; end if;
end $$;

-- Impor RAB massal (atomik: gagal satu baris = tidak ada yang masuk). Kode yang sudah ada diperbarui.
create or replace function import_rab(p_project uuid, p_rows jsonb) returns int
language plpgsql security definer set search_path = public as $$
declare n int; dup text;
begin
  if my_role() not in ('estimator', 'pm') or not is_member(p_project) then raise exception 'Tidak diizinkan'; end if;
  if jsonb_typeof(p_rows) <> 'array' or jsonb_array_length(p_rows) = 0 then raise exception 'Tidak ada baris untuk diimpor'; end if;
  if jsonb_array_length(p_rows) > 2000 then raise exception 'Maksimal 2000 baris per impor'; end if;
  if exists (select 1 from jsonb_array_elements(p_rows) r
              where coalesce(trim(r->>'code'), '') = '' or coalesce(trim(r->>'description'), '') = ''
                 or coalesce((r->>'volume')::numeric, -1) < 0 or coalesce((r->>'unit_price')::numeric, -1) < 0) then
    raise exception 'Ada baris tidak valid (kode, uraian, volume, atau harga kosong atau negatif)'; end if;
  select trim(r->>'code') into dup from jsonb_array_elements(p_rows) r group by trim(r->>'code') having count(*) > 1 limit 1;
  if dup is not null then raise exception 'Kode ganda dalam file: %', dup; end if;

  insert into rab_items(project_id, code, description, unit, volume, unit_price)
  select p_project, trim(r->>'code'), trim(r->>'description'), coalesce(nullif(trim(r->>'unit'), ''), 'ls'),
         (r->>'volume')::numeric, (r->>'unit_price')::numeric
    from jsonb_array_elements(p_rows) r
  on conflict (project_id, code) do update
     set description = excluded.description, unit = excluded.unit, volume = excluded.volume, unit_price = excluded.unit_price;
  get diagnostics n = row_count;
  return n;
end $$;
