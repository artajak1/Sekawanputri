-- =====================================================================
-- Aplikasi Manajemen Proyek Konstruksi - Skema Supabase (Tahap 1)
-- Jalankan di Supabase SQL Editor. Aman dijalankan ulang (IF NOT EXISTS).
-- Tahap berikutnya: PO, SPK subcon, adendum, retensi, alat berat, pajak, dst.
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------- ENUM ----------
do $$ begin
  create type app_role as enum ('mandor','admin_proyek','pm','estimator','finance','owner');
  create type approval_status as enum ('draft','submitted','approved','rejected');
  create type project_status as enum ('planning','active','handover','retention','closed');
exception when duplicate_object then null; end $$;

-- ---------- PROFIL & PERAN ----------
create table if not exists profiles (
  id          uuid primary key references auth.users(id) on delete cascade,
  full_name   text not null,
  role        app_role not null default 'mandor',
  phone_wa    text,                       -- untuk notifikasi WhatsApp (Fonnte/Wablas)
  is_active   boolean not null default true,
  created_at  timestamptz not null default now()
);

-- Penugasan user ke proyek (satu user bisa banyak proyek)
create table if not exists project_members (
  project_id  uuid not null,
  user_id     uuid not null references profiles(id) on delete cascade,
  primary key (project_id, user_id)
);

-- ---------- PROYEK ----------
create table if not exists projects (
  id              uuid primary key default gen_random_uuid(),
  code            text unique not null,
  name            text not null,
  client_name     text not null,
  contract_value  numeric(18,2) not null default 0,
  start_date      date,
  end_date        date,
  retention_pct   numeric(5,2) not null default 5.00,   -- retensi 5%
  status          project_status not null default 'planning',
  created_at      timestamptz not null default now()
);
alter table project_members
  drop constraint if exists project_members_project_id_fkey,
  add constraint project_members_project_id_fkey
  foreign key (project_id) references projects(id) on delete cascade;

-- ---------- RAB (rincian volume & harga satuan) ----------
create table if not exists rab_items (
  id           uuid primary key default gen_random_uuid(),
  project_id   uuid not null references projects(id) on delete cascade,
  code         text not null,
  description  text not null,
  unit         text not null,
  volume       numeric(18,3) not null default 0,
  unit_price   numeric(18,2) not null default 0,
  total        numeric(18,2) generated always as (volume * unit_price) stored,
  unique (project_id, code)
);

-- ---------- LAPORAN HARIAN ----------
-- client_id dibuat di HP (uuid) -> kunci idempoten agar sync ulang tidak menggandakan data
create table if not exists daily_reports (
  id            uuid primary key default gen_random_uuid(),
  client_id     uuid unique not null,
  project_id    uuid not null references projects(id) on delete cascade,
  report_date   date not null,
  weather       text,
  physical_pct  numeric(5,2) check (physical_pct between 0 and 100),
  notes         text,
  status        approval_status not null default 'draft',
  created_by    uuid not null references profiles(id),
  created_at    timestamptz not null default now(),
  updated_at    timestamptz not null default now(),
  unique (project_id, report_date, created_by)
);
create index if not exists idx_dr_project_date on daily_reports (project_id, report_date desc);

-- ---------- ABSENSI TUKANG (HOK) ----------
create table if not exists workers (
  id          uuid primary key default gen_random_uuid(),
  project_id  uuid not null references projects(id) on delete cascade,
  name        text not null,
  skill       text,
  daily_wage  numeric(14,2) not null default 0,
  is_active   boolean not null default true
);

create table if not exists attendance (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid unique not null,
  worker_id   uuid not null references workers(id) on delete cascade,
  work_date   date not null,
  hok         numeric(3,2) not null default 1 check (hok between 0 and 2),  -- 0.5 = setengah hari
  created_by  uuid not null references profiles(id),
  unique (worker_id, work_date)
);
create index if not exists idx_att_date on attendance (work_date);

-- ---------- KASBON TUKANG ----------
create table if not exists worker_advances (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid unique not null,
  worker_id   uuid not null references workers(id) on delete cascade,
  amount      numeric(14,2) not null check (amount > 0),
  given_on    date not null default current_date,
  settled     boolean not null default false,
  created_by  uuid not null references profiles(id)
);

-- ---------- KAS KECIL ----------
create table if not exists petty_cash (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid unique not null,
  project_id  uuid not null references projects(id) on delete cascade,
  tx_date     date not null default current_date,
  direction   text not null check (direction in ('in','out')),
  amount      numeric(14,2) not null check (amount > 0),
  description text not null,
  status      approval_status not null default 'submitted',
  created_by  uuid not null references profiles(id),
  created_at  timestamptz not null default now()
);
create index if not exists idx_pc_project_date on petty_cash (project_id, tx_date desc);

-- ---------- LAMPIRAN FOTO (path saja, file di Storage) ----------
-- Simpan hanya path + ukuran; JANGAN simpan base64 di tabel (hemat egress)
create table if not exists attachments (
  id            uuid primary key default gen_random_uuid(),
  client_id     uuid unique not null,
  project_id    uuid not null references projects(id) on delete cascade,
  ref_table     text not null,           -- 'daily_reports' | 'petty_cash' | dst
  ref_id        uuid not null,
  storage_path  text not null,
  mime_type     text not null,
  size_bytes    integer not null,
  width         integer,
  height        integer,
  created_by    uuid not null references profiles(id),
  created_at    timestamptz not null default now()
);
create index if not exists idx_att_ref on attachments (ref_table, ref_id);

-- ---------- APPROVAL BERJENJANG ----------
create table if not exists approvals (
  id            uuid primary key default gen_random_uuid(),
  project_id    uuid not null references projects(id) on delete cascade,
  ref_table     text not null,
  ref_id        uuid not null,
  level         smallint not null check (level in (1,2)),   -- 1 = PM, 2 = Owner
  status        approval_status not null default 'submitted',
  requested_by  uuid not null references profiles(id),
  decided_by    uuid references profiles(id),
  decided_at    timestamptz,
  note          text,
  created_at    timestamptz not null default now(),
  unique (ref_table, ref_id, level)
);
create index if not exists idx_appr_pending on approvals (level, status) where status = 'submitted';

-- ---------- ANTREAN WHATSAPP ----------
create table if not exists wa_outbox (
  id          uuid primary key default gen_random_uuid(),
  to_phone    text not null,
  message     text not null,
  sent_at     timestamptz,
  attempts    smallint not null default 0,
  last_error  text,
  created_at  timestamptz not null default now()
);

-- ---------- JEJAK AUDIT ----------
create table if not exists audit_log (
  id          bigserial primary key,
  table_name  text not null,
  row_id      uuid,
  action      text not null,             -- INSERT / UPDATE / DELETE
  actor       uuid,
  old_data    jsonb,
  new_data    jsonb,
  at          timestamptz not null default now()
);

create or replace function fn_audit() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into audit_log(table_name,row_id,action,actor,old_data,new_data)
  values (tg_table_name,
          coalesce((to_jsonb(new)->>'id')::uuid,(to_jsonb(old)->>'id')::uuid),
          tg_op, auth.uid(),
          case when tg_op <> 'INSERT' then to_jsonb(old) end,
          case when tg_op <> 'DELETE' then to_jsonb(new) end);
  return coalesce(new, old);
end $$;

do $$
declare t text;
begin
  foreach t in array array['daily_reports','petty_cash','approvals','projects','rab_items','worker_advances']
  loop
    execute format('drop trigger if exists trg_audit on %I', t);
    execute format('create trigger trg_audit after insert or update or delete on %I
                    for each row execute function fn_audit()', t);
  end loop;
end $$;

-- updated_at otomatis
create or replace function fn_touch() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;
drop trigger if exists trg_touch on daily_reports;
create trigger trg_touch before update on daily_reports
  for each row execute function fn_touch();

-- ---------- HELPER RLS ----------
create or replace function my_role() returns app_role
language sql stable security definer set search_path = public as
$$ select role from profiles where id = auth.uid() $$;

create or replace function is_member(pid uuid) returns boolean
language sql stable security definer set search_path = public as
$$ select exists(select 1 from project_members where project_id = pid and user_id = auth.uid())
       or my_role() in ('owner','finance') $$;

-- ---------- ROW LEVEL SECURITY ----------
alter table profiles        enable row level security;
alter table project_members enable row level security;
alter table projects        enable row level security;
alter table rab_items       enable row level security;
alter table daily_reports   enable row level security;
alter table workers         enable row level security;
alter table attendance      enable row level security;
alter table worker_advances enable row level security;
alter table petty_cash      enable row level security;
alter table attachments     enable row level security;
alter table approvals       enable row level security;
alter table audit_log       enable row level security;

create policy "profil sendiri/anggota" on profiles for select
  using (id = auth.uid() or my_role() in ('pm','owner','finance'));

create policy "proyek terlihat anggota" on projects for select using (is_member(id));
create policy "proyek diubah PM/owner" on projects for all
  using (my_role() in ('pm','owner')) with check (my_role() in ('pm','owner'));

create policy "RAB baca anggota" on rab_items for select using (is_member(project_id));
create policy "RAB tulis estimator/PM" on rab_items for all
  using (my_role() in ('estimator','pm')) with check (my_role() in ('estimator','pm'));

create policy "laporan baca anggota" on daily_reports for select using (is_member(project_id));
create policy "laporan tulis mandor" on daily_reports for insert
  with check (is_member(project_id) and my_role() in ('mandor','pm') and created_by = auth.uid());
create policy "laporan ubah (draft sendiri / PM)" on daily_reports for update
  using ((created_by = auth.uid() and status in ('draft','rejected')) or my_role() = 'pm');

create policy "kas kecil baca" on petty_cash for select using (is_member(project_id));
create policy "kas kecil tulis admin" on petty_cash for insert
  with check (is_member(project_id) and my_role() in ('admin_proyek','pm') and created_by = auth.uid());

create policy "lampiran baca" on attachments for select using (is_member(project_id));
create policy "lampiran tulis" on attachments for insert
  with check (is_member(project_id) and created_by = auth.uid());

create policy "approval baca" on approvals for select using (is_member(project_id));
create policy "approval L1 oleh PM, L2 oleh owner" on approvals for update
  using ((level = 1 and my_role() = 'pm') or (level = 2 and my_role() = 'owner'));

create policy "audit hanya owner" on audit_log for select using (my_role() = 'owner');

-- ---------- STORAGE ----------
-- Buat bucket privat 'site-photos' via Dashboard > Storage (public = false).
-- Gunakan signed URL berumur pendek saat menampilkan foto, dan thumbnail
-- (lihat imageCompress.js -> makeThumbnail) di daftar agar egress minimal.

-- CATATAN: policy untuk workers, attendance, worker_advances dibuat dengan pola
-- yang sama (join ke projects lewat worker_id) pada tahap payroll.
