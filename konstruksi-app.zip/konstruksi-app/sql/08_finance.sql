-- Tahap 8: Keuangan. Jalankan setelah 07_dashboard.sql.

-- Pengaturan pajak & batas. PERIKSA dengan akuntan/konsultan pajak Anda sebelum dipakai untuk faktur resmi.
--  ppn_pct        : tarif EFEKTIF PPN (12% x DPP nilai lain 11/12 = 11%)
--  pph_final_pct  : PPh Final jasa konstruksi (1,75 kualifikasi kecil | 2,65 menengah/besar | 4 tanpa sertifikat)
--  pay_owner_min  : pembayaran tagihan supplier >= nilai ini butuh persetujuan owner
insert into app_settings values ('ppn_pct', '11'), ('pph_final_pct', '2.65'), ('pay_owner_min', '25000000')
on conflict do nothing;

-- ---------- Termin klien ----------
create table if not exists client_terms (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid unique not null,
  project_id  uuid not null references projects(id) on delete cascade,
  term_no     int not null,
  description text not null,
  pct         numeric(5,2) not null check (pct > 0 and pct <= 100),
  amount      numeric(16,2) not null check (amount > 0),      -- DPP (di luar PPN)
  due_date    date,
  status      text not null default 'planned' check (status in ('planned','invoiced','paid')),
  created_by  uuid not null references profiles(id),
  unique (project_id, term_no)
);

-- ---------- Invoice resmi ke klien ----------
create sequence if not exists inv_seq;
create table if not exists client_invoices (
  id               uuid primary key default gen_random_uuid(),
  project_id       uuid not null references projects(id) on delete cascade,
  term_id          uuid unique not null references client_terms(id),
  invoice_no       text unique not null,
  invoice_date     date not null default current_date,
  dpp              numeric(16,2) not null,
  ppn_amount       numeric(16,2) not null,
  pph_amount       numeric(16,2) not null,      -- PPh Final dipotong pemberi kerja
  retention_amount numeric(16,2) not null,      -- retensi tertahan (default 5%)
  net_receivable   numeric(16,2) not null,      -- DPP + PPN - PPh Final - retensi
  status           text not null default 'issued' check (status in ('issued','paid')),
  paid_at          timestamptz,
  created_by       uuid references profiles(id)
);

alter table client_terms    enable row level security;
alter table client_invoices enable row level security;
create policy "termin baca" on client_terms for select
  using (is_member(project_id) and my_role() in ('pm','finance','owner','estimator'));
create policy "termin kelola" on client_terms for all
  using (my_role() in ('pm','finance') and is_member(project_id) and status = 'planned')
  with check (my_role() in ('pm','finance') and is_member(project_id) and created_by = auth.uid() and status = 'planned');
create policy "invoice baca" on client_invoices for select
  using (is_member(project_id) and my_role() in ('pm','finance','owner'));
-- Invoice dibuat/dilunasi hanya lewat fungsi di bawah.

create or replace function issue_client_invoice(p_term uuid) returns uuid
language plpgsql security definer set search_path = public as $$
declare t client_terms; ppn numeric; pph numeric; ret numeric; ret_pct numeric; rid uuid; vat numeric; ph numeric;
begin
  if my_role() <> 'finance' then raise exception 'Hanya Finance yang dapat menerbitkan invoice'; end if;
  select * into t from client_terms where id = p_term for update;
  if not found or not is_member(t.project_id) then raise exception 'Termin tidak ditemukan'; end if;
  if t.status <> 'planned' then raise exception 'Termin sudah ditagihkan'; end if;
  select coalesce(value::numeric, 11) into vat from app_settings where key = 'ppn_pct';
  select coalesce(value::numeric, 2.65) into ph from app_settings where key = 'pph_final_pct';
  select retention_pct into ret_pct from projects where id = t.project_id;
  ppn := round(t.amount * vat / 100, 0);
  pph := round(t.amount * ph / 100, 0);
  ret := round(t.amount * coalesce(ret_pct, 5) / 100, 0);
  insert into client_invoices(project_id, term_id, invoice_no, dpp, ppn_amount, pph_amount, retention_amount, net_receivable, created_by)
  values (t.project_id, t.id, 'INV-' || to_char(current_date, 'YYMM') || '-' || lpad(nextval('inv_seq')::text, 4, '0'),
          t.amount, ppn, pph, ret, t.amount + ppn - pph - ret, auth.uid())
  returning id into rid;
  update client_terms set status = 'invoiced' where id = t.id;
  return rid;
end $$;

create or replace function mark_client_invoice_paid(p_invoice uuid) returns void
language plpgsql security definer set search_path = public as $$
declare i client_invoices;
begin
  if my_role() <> 'finance' then raise exception 'Hanya Finance'; end if;
  select * into i from client_invoices where id = p_invoice for update;
  if not found or not is_member(i.project_id) then raise exception 'Invoice tidak ditemukan'; end if;
  if i.status = 'paid' then raise exception 'Sudah lunas'; end if;
  update client_invoices set status = 'paid', paid_at = now() where id = p_invoice;
  update client_terms set status = 'paid' where id = i.term_id;
end $$;

-- ---------- Pembayaran besar butuh owner (level 2) ----------
alter table supplier_invoices add column if not exists owner_approved boolean not null default false;

create or replace function approve_invoice_payment(p_invoice uuid) returns void
language plpgsql security definer set search_path = public as $$
declare i supplier_invoices; pid uuid;
begin
  if my_role() <> 'owner' then raise exception 'Hanya owner'; end if;
  select * into i from supplier_invoices where id = p_invoice for update;
  if not found then raise exception 'Tagihan tidak ditemukan'; end if;
  update supplier_invoices set owner_approved = true where id = p_invoice;
  perform notify_role('finance', 'Pembayaran tagihan ' || i.invoice_no || ' (Rp ' ||
          to_char(i.amount, 'FM999G999G999G999') || ') disetujui owner.', 'pay-ok-' || p_invoice);
end $$;

-- Cegah klien menyetel status/persetujuan sendiri saat insert tagihan
create or replace function fn_invoice_guard() returns trigger language plpgsql as $$
begin new.status := 'unpaid'; new.paid_at := null; new.owner_approved := false; return new; end $$;
drop trigger if exists trg_invoice_guard on supplier_invoices;
create trigger trg_invoice_guard before insert on supplier_invoices for each row execute function fn_invoice_guard();

create or replace function fn_invoice_notify() returns trigger
language plpgsql security definer set search_path = public as $$
declare lim numeric;
begin
  select coalesce(value::numeric, 25000000) into lim from app_settings where key = 'pay_owner_min';
  if new.amount >= lim then
    perform notify_role('owner', 'Tagihan ' || new.invoice_no || ' senilai Rp ' ||
            to_char(new.amount, 'FM999G999G999G999') || ' menunggu persetujuan pembayaran Anda.', 'pay-req-' || new.id);
  end if;
  return new;
end $$;
drop trigger if exists trg_invoice_notify on supplier_invoices;
create trigger trg_invoice_notify after insert on supplier_invoices for each row execute function fn_invoice_notify();

-- pay_invoice dari tahap 6, ditambah syarat persetujuan owner
create or replace function pay_invoice(p_invoice uuid) returns void
language plpgsql security definer set search_path = public as $$
declare inv supplier_invoices; m record; vat numeric; lim numeric;
begin
  if my_role() <> 'finance' then raise exception 'Hanya Finance yang dapat membayar'; end if;
  select * into inv from supplier_invoices where id = p_invoice for update;
  if not found then raise exception 'Tagihan tidak ditemukan'; end if;
  if inv.status = 'paid' then raise exception 'Tagihan sudah dibayar'; end if;
  select coalesce(value::numeric, 25000000) into lim from app_settings where key = 'pay_owner_min';
  if inv.amount >= lim and not inv.owner_approved then
    raise exception 'Pembayaran sebesar ini harus disetujui owner lebih dulu'; end if;
  select received_value, invoiced into m from po_match where po_id = inv.po_id;
  select coalesce(value::numeric, 0) into vat from app_settings where key = 'po_vat_pct';
  if m.invoiced > m.received_value * (1 + coalesce(vat, 0) / 100) + 1 then
    raise exception 'Total tagihan melebihi nilai barang yang sudah diterima. Cocokkan surat jalan dulu.'; end if;
  update supplier_invoices set status = 'paid', paid_at = now() where id = p_invoice;
end $$;

-- ---------- Ringkasan keuangan proyek (satu panggilan) ----------
create or replace function finance_summary(p_project uuid) returns jsonb
language sql stable set search_path = public as $$
select jsonb_build_object(
  'receivable', coalesce((select sum(net_receivable) from client_invoices where project_id = p_project and status = 'issued'), 0),
  'retention_held', coalesce((select sum(retention_amount) from client_invoices where project_id = p_project), 0),
  'ppn_out', coalesce((select sum(ppn_amount) from client_invoices where project_id = p_project), 0),
  'pph_final', coalesce((select sum(pph_amount) from client_invoices where project_id = p_project), 0),
  'payable', coalesce((select sum(s.amount) from supplier_invoices s join purchase_orders p on p.id = s.po_id
                        where p.project_id = p_project and s.status = 'unpaid'), 0),
  'terms_planned', coalesce((select sum(amount) from client_terms where project_id = p_project and status = 'planned'), 0)
);
$$;
grant execute on function finance_summary(uuid) to authenticated;
revoke execute on function finance_summary(uuid) from anon;

do $$ declare t text; begin
  foreach t in array array['client_terms','client_invoices'] loop
    execute format('drop trigger if exists trg_audit on %I', t);
    execute format('create trigger trg_audit after insert or update or delete on %I for each row execute function fn_audit()', t);
  end loop; end $$;

-- ---------- PENGETATAN (menutup celah dari tahap 1 dan 3) ----------
-- Tanpa ini, pengguna yang membuat data bisa menyetel status 'approved' sendiri lewat API.
create or replace function fn_force_submitted() returns trigger language plpgsql as $$
begin new.status := 'submitted'; return new; end $$;
drop trigger if exists trg_pc_force on petty_cash;
create trigger trg_pc_force before insert on petty_cash for each row execute function fn_force_submitted();

create or replace function fn_report_status_guard() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  if new.status in ('approved', 'rejected')
     and (tg_op = 'INSERT' or new.status is distinct from old.status)
     and my_role() <> 'pm' then
    raise exception 'Hanya PM yang dapat menyetujui atau menolak laporan';
  end if;
  return new;
end $$;
drop trigger if exists trg_report_guard on daily_reports;
create trigger trg_report_guard before insert or update on daily_reports
  for each row execute function fn_report_status_guard();
