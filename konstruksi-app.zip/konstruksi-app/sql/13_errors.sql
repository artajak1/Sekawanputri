-- Tahap 13: Log error dari aplikasi (agar bug saat update fitur mudah dilacak). Jalankan setelah 12.
create table if not exists client_errors (
  id         bigserial primary key,
  user_id    uuid default auth.uid(),
  source     text not null,                 -- modul atau jenis (mis. 'ErrorBoundary:kas-kecil', 'window.error')
  message    text not null,
  stack      text,
  url        text,
  user_agent text,
  app_version text,
  at         timestamptz not null default now()
);
create index if not exists idx_client_errors_at on client_errors (at desc);
alter table client_errors enable row level security;

-- Setiap pengguna login boleh menulis, hanya owner yang boleh membaca
create policy "error tulis" on client_errors for insert to authenticated
  with check (user_id = auth.uid() and length(message) < 2000 and length(coalesce(stack, '')) < 6000);
create policy "error baca owner" on client_errors for select using (my_role() = 'owner');

-- Bersihkan log lama (90 hari) tiap Minggu dini hari
select cron.schedule('bersih-error', '0 20 * * 0', $$delete from client_errors where at < now() - interval '90 days'$$);
