-- Tahap 9: Punch list, Serah terima, Retensi. Jalankan setelah 08_finance.sql.

insert into app_settings values ('maintenance_months', '6') on conflict do nothing;  -- masa pemeliharaan (bulan)

-- ---------- Punch list ----------
create table if not exists punch_items (
  id          uuid primary key default gen_random_uuid(),
  client_id   uuid unique not null,
  project_id  uuid not null references projects(id) on delete cascade,
  title       text not null,
  location    text,
  status      text not null default 'open' check (status in ('open','fixed','verified')),
  verify_note text,
  created_by  uuid not null references profiles(id),
  created_at  timestamptz not null default now(),
  fixed_at    timestamptz,
  verified_at timestamptz
);
create index if not exists idx_punch_project on punch_items (project_id, status);

-- Perbaikan dicatat sebagai baris tersendiri agar bisa dikirim lewat antrean offline beserta foto
create table if not exists punch_fixes (
  id         uuid primary key default gen_random_uuid(),
  client_id  uuid unique not null,
  punch_id   uuid not null references punch_items(id) on delete cascade,
  note       text,
  created_by uuid not null references profiles(id),
  created_at timestamptz not null default now()
);

create or replace function fn_punch_force_open() returns trigger language plpgsql as $$
begin new.status := 'open'; new.verify_note := null; new.fixed_at := null; new.verified_at := null; return new; end $$;
drop trigger if exists trg_punch_force on punch_items;
create trigger trg_punch_force before insert on punch_items for each row execute function fn_punch_force_open();

create or replace function fn_punch_fix_after() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  update punch_items set status = 'fixed', fixed_at = now() where id = new.punch_id and status = 'open';
  return new;
end $$;
drop trigger if exists trg_punch_fix on punch_fixes;
create trigger trg_punch_fix after insert on punch_fixes for each row execute function fn_punch_fix_after();

create or replace function verify_punch(p_id uuid, p_ok boolean, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare p punch_items;
begin
  if my_role() <> 'pm' then raise exception 'Hanya PM yang dapat memvalidasi'; end if;
  select * into p from punch_items where id = p_id for update;
  if not found or not is_member(p.project_id) then raise exception 'Punch list tidak ditemukan'; end if;
  if p.status <> 'fixed' then raise exception 'Item belum ditandai selesai'; end if;
  if p_ok then
    update punch_items set status = 'verified', verified_at = now(), verify_note = p_note where id = p_id;
  else
    update punch_items set status = 'open', fixed_at = null, verify_note = p_note where id = p_id;
  end if;
end $$;

-- ---------- Serah terima & retensi ----------
create table if not exists handovers (
  project_id    uuid primary key references projects(id) on delete cascade,
  handover_date date not null,
  completed_by  uuid references profiles(id),
  created_at    timestamptz not null default now()
);
create table if not exists retention_claims (
  id          uuid primary key default gen_random_uuid(),
  project_id  uuid unique not null references projects(id) on delete cascade,
  amount      numeric(16,2) not null,
  due_date    date not null,
  status      text not null default 'held' check (status in ('held','released')),
  released_at timestamptz
);

create or replace function complete_handover(p_project uuid, p_date date default current_date) returns date
language plpgsql security definer set search_path = public as $$
declare v_open int; v_amt numeric; v_months int; v_due date; v_name text;
begin
  if my_role() <> 'pm' or not is_member(p_project) then raise exception 'Hanya PM proyek ini'; end if;
  if exists (select 1 from handovers where project_id = p_project) then raise exception 'Proyek sudah diserahterimakan'; end if;
  select count(*) into v_open from punch_items where project_id = p_project and status <> 'verified';
  if v_open > 0 then raise exception 'Masih ada % punch list yang belum diverifikasi', v_open; end if;
  select coalesce(sum(retention_amount), 0) into v_amt from client_invoices where project_id = p_project;
  select coalesce(value::int, 6) into v_months from app_settings where key = 'maintenance_months';
  v_due := (p_date + make_interval(months => v_months))::date;
  select name into v_name from projects where id = p_project;

  insert into handovers(project_id, handover_date, completed_by) values (p_project, p_date, auth.uid());
  insert into retention_claims(project_id, amount, due_date) values (p_project, v_amt, v_due);
  update projects set status = 'retention' where id = p_project;

  perform notify_role('finance', 'Serah terima ' || v_name || ' selesai. Retensi Rp ' || to_char(v_amt, 'FM999G999G999G999') ||
                      ' jatuh tempo ' || to_char(v_due, 'DD/MM/YYYY') || '.', 'ho-f-' || p_project);
  perform notify_role('owner', 'Serah terima ' || v_name || ' selesai. Masa pemeliharaan sampai ' || to_char(v_due, 'DD/MM/YYYY') || '.', 'ho-o-' || p_project);
  return v_due;
end $$;

create or replace function release_retention(p_project uuid) returns void
language plpgsql security definer set search_path = public as $$
declare c retention_claims;
begin
  if my_role() <> 'finance' then raise exception 'Hanya Finance'; end if;
  select * into c from retention_claims where project_id = p_project for update;
  if not found then raise exception 'Belum ada retensi (serah terima belum selesai)'; end if;
  if c.status = 'released' then raise exception 'Retensi sudah dicairkan'; end if;
  if current_date < c.due_date then raise exception 'Belum jatuh tempo (%)', to_char(c.due_date, 'DD/MM/YYYY'); end if;
  update retention_claims set status = 'released', released_at = now() where id = c.id;
  update projects set status = 'closed' where id = p_project;
end $$;

-- Pengingat harian: H-14, H-7, dan hari jatuh tempo (dedupe mencegah pesan ganda)
create or replace function retention_reminders() returns void
language plpgsql security definer set search_path = public as $$
declare c record; d int;
begin
  for c in select rc.id, rc.amount, rc.due_date, p.name from retention_claims rc
             join projects p on p.id = rc.project_id where rc.status = 'held'
              and (rc.due_date - current_date) in (14, 7, 0) loop
    d := c.due_date - current_date;
    perform notify_role('finance', 'Retensi ' || c.name || ' Rp ' || to_char(c.amount, 'FM999G999G999G999') ||
            case when d = 0 then ' jatuh tempo HARI INI.' else ' jatuh tempo ' || d || ' hari lagi.' end, 'ret-f-' || c.id || '-' || d);
    perform notify_role('owner', 'Retensi ' || c.name || case when d = 0 then ' jatuh tempo hari ini.' else ' jatuh tempo ' || d || ' hari lagi.' end,
            'ret-o-' || c.id || '-' || d);
  end loop;
end $$;
revoke all on function retention_reminders() from public, anon, authenticated;
select cron.schedule('retensi-harian', '0 1 * * *', 'select retention_reminders()');  -- 08.00 WIB

-- ---------- RLS ----------
alter table punch_items      enable row level security;
alter table punch_fixes      enable row level security;
alter table handovers        enable row level security;
alter table retention_claims enable row level security;

create policy "punch baca" on punch_items for select using (is_member(project_id));
create policy "punch buat" on punch_items for insert
  with check (my_role() in ('mandor','admin_proyek','pm') and is_member(project_id) and created_by = auth.uid());
create policy "perbaikan baca" on punch_fixes for select
  using (exists (select 1 from punch_items p where p.id = punch_id and is_member(p.project_id)));
create policy "perbaikan buat" on punch_fixes for insert
  with check (my_role() in ('mandor','admin_proyek','pm') and created_by = auth.uid()
    and exists (select 1 from punch_items p where p.id = punch_id and is_member(p.project_id)));
create policy "serah terima baca" on handovers for select using (is_member(project_id));
create policy "retensi baca" on retention_claims for select
  using (is_member(project_id) and my_role() in ('pm','finance','owner'));

do $$ declare t text; begin
  foreach t in array array['punch_items','handovers','retention_claims'] loop
    execute format('drop trigger if exists trg_audit on %I', t);
    execute format('create trigger trg_audit after insert or update or delete on %I for each row execute function fn_audit()', t);
  end loop; end $$;
