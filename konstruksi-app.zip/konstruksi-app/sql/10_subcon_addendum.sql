-- Tahap 10: SPK Subkontraktor + Adendum (tambah/kurang). Jalankan setelah 09_handover.sql.

insert into app_settings values ('spk_owner_min', '50000000') on conflict do nothing;  -- SPK >= ini butuh owner

-- ---------- Master subkontraktor ----------
create table if not exists subcontractors (
  id uuid primary key default gen_random_uuid(),
  name text not null, phone text, is_active boolean not null default true
);

-- ---------- SPK (kontrak borongan) ----------
create sequence if not exists spk_seq;
create table if not exists spk (
  id             uuid primary key default gen_random_uuid(),
  client_id      uuid unique not null,
  project_id     uuid not null references projects(id) on delete cascade,
  subcon_id      uuid not null references subcontractors(id),
  spk_number     text unique,
  title          text not null,
  contract_value numeric(16,2) not null check (contract_value > 0),
  status         text not null default 'submitted' check (status in ('submitted','approved','rejected')),
  created_by     uuid not null references profiles(id),
  created_at     timestamptz not null default now()
);
create table if not exists spk_progress (          -- riwayat progres kumulatif, dicatat PM
  id uuid primary key default gen_random_uuid(),
  spk_id uuid not null references spk(id) on delete cascade,
  pct numeric(5,2) not null check (pct between 0 and 100),
  note text, created_by uuid not null references profiles(id), created_at timestamptz not null default now()
);
create table if not exists spk_payments (
  id uuid primary key default gen_random_uuid(),
  spk_id uuid not null references spk(id) on delete cascade,
  amount numeric(16,2) not null check (amount > 0),
  paid_by uuid not null references profiles(id), paid_at timestamptz not null default now()
);

-- ---------- Adendum (pekerjaan tambah/kurang) ----------
create sequence if not exists add_seq;
create table if not exists addenda (
  id         uuid primary key default gen_random_uuid(),
  client_id  uuid unique not null,
  project_id uuid not null references projects(id) on delete cascade,
  number     text unique,
  title      text not null,
  reason     text,
  items      jsonb not null,       -- [{type:'tambah'|'kurang', description, unit, qty, unit_price}]
  delta      numeric(16,2) not null default 0,   -- tambah dikurangi kurang
  status     text not null default 'submitted' check (status in ('submitted','approved','rejected')),
  created_by uuid not null references profiles(id),
  created_at timestamptz not null default now()
);
alter table projects add column if not exists contract_original numeric(18,2);

-- ---------- Trigger: nomor, total, approval, notifikasi ----------
create or replace function fn_spk_before() returns trigger language plpgsql as $$
begin
  new.status := 'submitted';
  new.spk_number := 'SPK-' || to_char(current_date, 'YYMM') || '-' || lpad(nextval('spk_seq')::text, 4, '0');
  return new;
end $$;
drop trigger if exists trg_spk_before on spk;
create trigger trg_spk_before before insert on spk for each row execute function fn_spk_before();

create or replace function fn_add_before() returns trigger language plpgsql as $$
declare bad int; d numeric;
begin
  if jsonb_typeof(new.items) <> 'array' or jsonb_array_length(new.items) = 0 then
    raise exception 'Adendum harus memiliki minimal satu item'; end if;
  select count(*) into bad from jsonb_array_elements(new.items) i
   where (i->>'type') not in ('tambah','kurang') or coalesce((i->>'qty')::numeric, 0) <= 0 or coalesce(i->>'description', '') = '';
  if bad > 0 then raise exception 'Item adendum tidak valid'; end if;
  select coalesce(sum(case when i->>'type' = 'tambah' then 1 else -1 end
                      * (i->>'qty')::numeric * coalesce((i->>'unit_price')::numeric, 0)), 0)
    into d from jsonb_array_elements(new.items) i;
  new.delta := d; new.status := 'submitted';
  new.number := 'ADD-' || to_char(current_date, 'YYMM') || '-' || lpad(nextval('add_seq')::text, 3, '0');
  return new;
end $$;
drop trigger if exists trg_add_before on addenda;
create trigger trg_add_before before insert on addenda for each row execute function fn_add_before();

create or replace function fn_doc_after() returns trigger
language plpgsql security definer set search_path = public as $$
declare lim numeric; v_val numeric; v_label text;
begin
  insert into approvals(project_id, ref_table, ref_id, level, requested_by)
  values (new.project_id, tg_table_name, new.id, 1, new.created_by) on conflict do nothing;
  if tg_table_name = 'addenda' then
    insert into approvals(project_id, ref_table, ref_id, level, requested_by)
    values (new.project_id, 'addenda', new.id, 2, new.created_by) on conflict do nothing;  -- adendum selalu sampai owner
    v_label := new.number;
  else
    select coalesce(value::numeric, 50000000) into lim from app_settings where key = 'spk_owner_min';
    if new.contract_value >= lim then
      insert into approvals(project_id, ref_table, ref_id, level, requested_by)
      values (new.project_id, 'spk', new.id, 2, new.created_by) on conflict do nothing;
    end if;
    v_label := new.spk_number;
  end if;
  perform notify_project_role(new.project_id, 'pm', v_label || ' menunggu persetujuan Anda.', 'doc-new-' || new.id);
  return new;
end $$;
drop trigger if exists trg_spk_after on spk;
create trigger trg_spk_after after insert on spk for each row execute function fn_doc_after();
drop trigger if exists trg_add_after on addenda;
create trigger trg_add_after after insert on addenda for each row execute function fn_doc_after();

-- ---------- Keputusan umum: SPK dan Adendum (PM level 1, owner level 2) ----------
create or replace function decide_doc(p_table text, p_id uuid, p_level smallint, p_approve boolean, p_note text default null)
returns text language plpgsql security definer set search_path = public as $$
declare v_pid uuid; v_label text; v_delta numeric := 0; a approvals; v_pending int; v_new numeric;
begin
  if p_table = 'spk' then select project_id, spk_number into v_pid, v_label from spk where id = p_id;
  elsif p_table = 'addenda' then select project_id, number, delta into v_pid, v_label, v_delta from addenda where id = p_id;
  else raise exception 'Jenis dokumen tidak dikenal'; end if;
  if v_pid is null or not is_member(v_pid) then raise exception 'Dokumen tidak ditemukan'; end if;

  select * into a from approvals where ref_table = p_table and ref_id = p_id and level = p_level for update;
  if not found then raise exception 'Level % tidak diperlukan', p_level; end if;
  if a.status <> 'submitted' then raise exception 'Sudah diputuskan'; end if;
  if (p_level = 1 and my_role() <> 'pm') or (p_level = 2 and my_role() <> 'owner') then
    raise exception 'Peran Anda tidak boleh memutuskan level %', p_level; end if;
  if p_level = 2 and exists (select 1 from approvals where ref_table = p_table and ref_id = p_id and level = 1 and status <> 'approved') then
    raise exception 'Level 1 (PM) harus disetujui lebih dulu'; end if;

  update approvals set status = case when p_approve then 'approved'::approval_status else 'rejected' end,
         decided_by = auth.uid(), decided_at = now(), note = p_note where id = a.id;

  if not p_approve then
    execute format('update %I set status = ''rejected'' where id = $1', p_table) using p_id;
    return 'rejected';
  end if;
  select count(*) into v_pending from approvals where ref_table = p_table and ref_id = p_id and status <> 'approved';
  if v_pending = 0 then
    execute format('update %I set status = ''approved'' where id = $1', p_table) using p_id;
    if p_table = 'addenda' then
      select contract_value + v_delta into v_new from projects where id = v_pid for update;
      if v_new < 0 then raise exception 'Nilai kontrak tidak boleh negatif'; end if;
      update projects set contract_original = coalesce(contract_original, contract_value), contract_value = v_new where id = v_pid;
      perform notify_role('finance', v_label || ' disetujui. Nilai kontrak menjadi Rp ' || to_char(v_new, 'FM999G999G999G999') || '.', 'doc-ok-' || p_id);
    else
      perform notify_project_role(v_pid, 'pm', v_label || ' disetujui.', 'doc-ok-' || p_id);
    end if;
  elsif p_level = 1 then
    perform notify_role('owner', v_label || ' sudah disetujui PM, menunggu persetujuan Anda.', 'doc-l2-' || p_id);
  end if;
  return 'approved';
end $$;

-- ---------- Progres dan pembayaran SPK ----------
create or replace function set_spk_progress(p_spk uuid, p_pct numeric, p_note text default null) returns void
language plpgsql security definer set search_path = public as $$
declare s spk; cur numeric;
begin
  if my_role() <> 'pm' then raise exception 'Hanya PM yang mencatat progres subkon'; end if;
  select * into s from spk where id = p_spk for update;
  if not found or not is_member(s.project_id) then raise exception 'SPK tidak ditemukan'; end if;
  if s.status <> 'approved' then raise exception 'SPK belum disetujui'; end if;
  select coalesce(max(pct), 0) into cur from spk_progress where spk_id = p_spk;
  if p_pct < cur then raise exception 'Progres tidak boleh turun (saat ini %)', cur; end if;
  if p_pct > 100 then raise exception 'Progres maksimal 100'; end if;
  insert into spk_progress(spk_id, pct, note, created_by) values (p_spk, p_pct, p_note, auth.uid());
end $$;

create or replace function pay_spk(p_spk uuid, p_amount numeric) returns void
language plpgsql security definer set search_path = public as $$
declare s spk; prog numeric; paid numeric; allowed numeric;
begin
  if my_role() <> 'finance' then raise exception 'Hanya Finance yang dapat membayar'; end if;
  select * into s from spk where id = p_spk for update;
  if not found or not is_member(s.project_id) then raise exception 'SPK tidak ditemukan'; end if;
  if s.status <> 'approved' then raise exception 'SPK belum disetujui'; end if;
  select coalesce(max(pct), 0) into prog from spk_progress where spk_id = p_spk;
  select coalesce(sum(amount), 0) into paid from spk_payments where spk_id = p_spk;
  allowed := round(s.contract_value * prog / 100 - paid, 0);
  if p_amount <= 0 or p_amount > allowed then
    raise exception 'Pembayaran melebihi progres yang disetujui. Maksimal saat ini Rp %', to_char(greatest(allowed, 0), 'FM999G999G999G999'); end if;
  insert into spk_payments(spk_id, amount, paid_by) values (p_spk, p_amount, auth.uid());
end $$;

create or replace view spk_summary with (security_invoker = true) as
select s.id, s.project_id, s.spk_number, s.title, s.contract_value, s.status, sc.name as subcon,
       coalesce((select max(pct) from spk_progress where spk_id = s.id), 0) as progress_pct,
       coalesce((select sum(amount) from spk_payments where spk_id = s.id), 0) as paid
from spk s join subcontractors sc on sc.id = s.subcon_id;

-- ---------- RLS ----------
alter table subcontractors enable row level security;
alter table spk            enable row level security;
alter table spk_progress   enable row level security;
alter table spk_payments   enable row level security;
alter table addenda        enable row level security;

create policy "subkon baca" on subcontractors for select using (my_role() in ('pm','finance','owner','estimator'));
create policy "subkon kelola" on subcontractors for all using (my_role() in ('pm','finance')) with check (my_role() in ('pm','finance'));
create policy "spk baca" on spk for select using (is_member(project_id) and my_role() in ('pm','finance','owner','estimator'));
create policy "spk buat" on spk for insert with check (my_role() = 'pm' and is_member(project_id) and created_by = auth.uid());
create policy "progres baca" on spk_progress for select
  using (exists (select 1 from spk s where s.id = spk_id and is_member(s.project_id)) and my_role() in ('pm','finance','owner'));
create policy "bayar baca" on spk_payments for select
  using (exists (select 1 from spk s where s.id = spk_id and is_member(s.project_id)) and my_role() in ('pm','finance','owner'));
create policy "adendum baca" on addenda for select using (is_member(project_id) and my_role() in ('pm','finance','owner','estimator'));
create policy "adendum buat" on addenda for insert
  with check (my_role() in ('estimator','pm') and is_member(project_id) and created_by = auth.uid());
-- Tanpa policy update/delete: dokumen tidak bisa diubah setelah diajukan.

do $$ declare t text; begin
  foreach t in array array['spk','spk_payments','addenda'] loop
    execute format('drop trigger if exists trg_audit on %I', t);
    execute format('create trigger trg_audit after insert or update or delete on %I for each row execute function fn_audit()', t);
  end loop; end $$;
