-- Tahap 4: Notifikasi WhatsApp. Jalankan setelah 03_petty_cash.sql.

-- 1) Kolom pendukung antrean
alter table wa_outbox
  add column if not exists locked_at timestamptz,
  add column if not exists dedupe_key text;
create unique index if not exists uq_wa_dedupe on wa_outbox (dedupe_key) where dedupe_key is not null;
create index if not exists idx_wa_pending on wa_outbox (created_at) where sent_at is null;
alter table wa_outbox enable row level security;   -- tanpa policy: hanya service_role yang bisa akses

-- 2) Helper: kirim pesan ke semua user berperan tertentu (dan opsional anggota proyek saja)
create or replace function notify_role(p_role app_role, p_message text, p_key text default null)
returns void language plpgsql security definer set search_path = public as $$
declare r record;
begin
  for r in select id, phone_wa from profiles
            where role = p_role and is_active and phone_wa is not null loop
    insert into wa_outbox(to_phone, message, dedupe_key)
    values (r.phone_wa, p_message, case when p_key is null then null else p_key || ':' || r.id end)
    on conflict do nothing;
  end loop;
end $$;
revoke all on function notify_role(app_role, text, text) from public, anon, authenticated;

-- 2b) Versi per proyek: hanya anggota proyek itu (pakai untuk peran pm/admin_proyek/mandor/estimator;
--     owner dan finance memang lintas proyek, cukup notify_role)
create or replace function notify_project_role(p_project uuid, p_role app_role, p_message text, p_key text default null)
returns void language plpgsql security definer set search_path = public as $$
declare r record;
begin
  for r in select p.id, p.phone_wa from profiles p
            join project_members m on m.user_id = p.id and m.project_id = p_project
           where p.role = p_role and p.is_active and p.phone_wa is not null loop
    insert into wa_outbox(to_phone, message, dedupe_key)
    values (r.phone_wa, p_message, case when p_key is null then null else p_key || ':' || r.id end)
    on conflict do nothing;
  end loop;
end $$;
revoke all on function notify_project_role(uuid, app_role, text, text) from public, anon, authenticated;

-- 3) Klaim batch (aman dari kirim ganda walau fungsi berjalan paralel)
create or replace function claim_wa_batch(p_limit int default 10)
returns setof wa_outbox language plpgsql security definer set search_path = public as $$
begin
  return query
  update wa_outbox w set attempts = attempts + 1, locked_at = now()
   where w.id in (
     select id from wa_outbox
      where sent_at is null and attempts < 5
        and (locked_at is null or locked_at < now() - interval '2 minutes')
      order by created_at limit p_limit for update skip locked)
  returning w.*;
end $$;
revoke all on function claim_wa_batch(int) from public, anon, authenticated;
grant execute on function claim_wa_batch(int) to service_role;

-- 4) (Sudah diterapkan di 03_petty_cash.sql: decide_approval memakai notify_role dengan kunci dedupe.)

-- 5) Jadwal: panggil Edge Function tiap menit (pg_cron + pg_net, aktifkan di Database > Extensions)
create extension if not exists pg_cron;
create extension if not exists pg_net;

-- Simpan rahasia di Vault, jangan di kode:
--   select vault.create_secret('https://<PROJECT-REF>.supabase.co/functions/v1/send-wa', 'wa_fn_url');
--   select vault.create_secret('<ISI-CRON_SECRET-ANDA>', 'wa_cron_secret');
select cron.schedule('kirim-wa', '* * * * *', $$
  select net.http_post(
    url     := (select decrypted_secret from vault.decrypted_secrets where name = 'wa_fn_url'),
    headers := jsonb_build_object('x-cron-secret',
               (select decrypted_secret from vault.decrypted_secrets where name = 'wa_cron_secret')),
    body    := '{}'::jsonb);
$$);
