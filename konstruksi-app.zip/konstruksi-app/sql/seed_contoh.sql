-- Data awal CONTOH untuk mencoba aplikasi. Jalankan di SQL Editor SETELAH sql 01-13 dan setelah akun dibuat.
-- Ganti nilai di dalam <...> dengan UUID akun dari Authentication > Users.

-- 1) Peran akun (owner dulu, lalu yang lain lewat set_user_role setelah login sebagai owner)
-- update profiles set role = 'owner', phone_wa = '081234567890' where id = '<UUID-OWNER>';
-- Untuk akun lain (jalankan dari SQL Editor sebagai postgres boleh langsung):
-- update profiles set role = 'pm',           phone_wa = '08...' where id = '<UUID-PM>';
-- update profiles set role = 'admin_proyek', phone_wa = '08...' where id = '<UUID-ADMIN>';
-- update profiles set role = 'mandor',       phone_wa = '08...' where id = '<UUID-MANDOR>';
-- update profiles set role = 'finance',      phone_wa = '08...' where id = '<UUID-FINANCE>';
-- update profiles set role = 'estimator'                       where id = '<UUID-ESTIMATOR>';

-- 2) Proyek contoh + penugasan anggota (owner dan finance otomatis melihat semua proyek)
with p as (
  insert into projects (code, name, client_name, contract_value, start_date, end_date, status)
  values ('GSG-01', 'Gedung Serbaguna Tahap 2', 'Pemerintah Desa Contoh', 1850000000, '2026-10-01', '2027-03-31', 'active')
  returning id
)
select id from p;   -- catat id proyek di hasil query

-- insert into project_members (project_id, user_id) values
--   ('<ID-PROYEK>', '<UUID-PM>'), ('<ID-PROYEK>', '<UUID-ADMIN>'), ('<ID-PROYEK>', '<UUID-MANDOR>'), ('<ID-PROYEK>', '<UUID-ESTIMATOR>');

-- 3) Master contoh
-- insert into suppliers (name, phone) values ('Toko Besi Jaya', '0812...'), ('UD Pasir Makmur', '0813...');
-- insert into subcontractors (name) values ('CV Karya Keramik');
-- insert into workers (project_id, name, skill, daily_wage) values
--   ('<ID-PROYEK>', 'Pak Slamet', 'Tukang batu', 180000), ('<ID-PROYEK>', 'Mas Rudi', 'Kenek', 140000);
-- insert into project_schedule values ('<ID-PROYEK>', '2026-10-05', 5), ('<ID-PROYEK>', '2026-10-12', 12), ('<ID-PROYEK>', '2026-10-19', 22);
-- insert into rab_items (project_id, code, description, unit, volume, unit_price) values
--   ('<ID-PROYEK>', 'A.1', 'Galian tanah pondasi', 'm3', 120, 85000);
