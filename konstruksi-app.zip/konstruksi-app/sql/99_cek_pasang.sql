-- Pemeriksaan setelah memasang 00_pasang_semua.sql. Jalankan SELURUH isi file ini; hasilnya satu tabel.
-- Kolom "hasil" harus OK di semua baris. Kirimkan baris yang bukan OK kepada saya.
with ada_tabel as (select tablename from pg_tables where schemaname = 'public'),
     tabel_harus(n) as (values ('addenda'),('app_settings'),('approvals'),('attachments'),('attendance'),('audit_log'),('client_errors'),('client_invoices'),('client_terms'),('daily_reports'),('delivery_items'),('delivery_notes'),('drawing_versions'),('drawings'),('equipment'),('equipment_logs'),('handovers'),('payroll_lines'),('payroll_runs'),('petty_cash'),('po_items'),('profiles'),('project_members'),('project_schedule'),('projects'),('punch_fixes'),('punch_items'),('purchase_orders'),('rab_items'),('retention_claims'),('spk'),('spk_payments'),('spk_progress'),('subcontractors'),('supplier_invoices'),('suppliers'),('wa_outbox'),('worker_advances'),('workers')),
     fungsi_harus(n) as (values ('approve_equipment'),('approve_invoice_payment'),('assign_project'),('claim_wa_batch'),('complete_handover'),('create_drawing'),('create_project'),('dashboard_summary'),('decide_approval'),('decide_doc'),('decide_payroll'),('decide_po'),('decide_report'),('finance_summary'),('fn_add_before'),('fn_audit'),('fn_delivery_after'),('fn_doc_after'),('fn_eqlog_before'),('fn_equipment_after'),('fn_equipment_before'),('fn_force_submitted'),('fn_invoice_guard'),('fn_invoice_notify'),('fn_lock_attendance'),('fn_new_user'),('fn_petty_cash_approvals'),('fn_po_after'),('fn_po_before'),('fn_punch_fix_after'),('fn_punch_force_open'),('fn_report_status_guard'),('fn_spk_before'),('fn_touch'),('generate_payroll'),('import_rab'),('is_member'),('issue_client_invoice'),('mark_client_invoice_paid'),('my_role'),('notify_project_role'),('notify_role'),('pay_invoice'),('pay_spk'),('register_drawing_version'),('release_retention'),('retention_reminders'),('set_project_member'),('set_spk_progress'),('set_user_role'),('verify_punch'),('yearly_summary')),
     ada_fungsi as (select p.proname from pg_proc p join pg_namespace s on s.oid = p.pronamespace where s.nspname = 'public')
select 'tabel hilang' as pemeriksaan, coalesce(string_agg(n, ', '), '-') as detail,
       case when count(*) = 0 then 'OK' else 'GAGAL' end as hasil
  from tabel_harus where n not in (select tablename from ada_tabel)
union all
select 'fungsi hilang', coalesce(string_agg(n, ', '), '-'), case when count(*) = 0 then 'OK' else 'GAGAL' end
  from fungsi_harus where n not in (select proname from ada_fungsi)
union all
select 'tabel tanpa RLS', coalesce(string_agg(tablename, ', '), '-'), case when count(*) = 0 then 'OK' else 'GAGAL' end
  from pg_tables where schemaname = 'public' and not rowsecurity
union all
select 'tabel RLS tanpa policy (wa_outbox memang begitu)', coalesce(string_agg(c.relname, ', '), '-'),
       case when coalesce(string_agg(c.relname, ', '), '') in ('', 'wa_outbox') then 'OK' else 'PERIKSA' end
  from pg_class c join pg_namespace n on n.oid = c.relnamespace
 where n.nspname = 'public' and c.relkind = 'r' and c.relrowsecurity
   and not exists (select 1 from pg_policies p where p.schemaname = 'public' and p.tablename = c.relname)
union all
select 'jumlah policy', count(*)::text, case when count(*) >= 130 then 'OK' else 'PERIKSA' end from pg_policies where schemaname = 'public'
union all
select 'trigger audit', count(*)::text, case when count(*) >= 21 then 'OK' else 'PERIKSA' end from pg_trigger where tgname = 'trg_audit' and not tgisinternal
union all
select 'trigger profil otomatis di auth.users', count(*)::text, case when count(*) = 1 then 'OK' else 'GAGAL' end from pg_trigger where tgname = 'trg_new_user'
union all
select 'pengaturan app_settings', count(*)::text, case when count(*) >= 9 then 'OK' else 'GAGAL' end from app_settings
union all
select 'jadwal cron', coalesce(string_agg(jobname, ', '), '-'), case when count(*) >= 3 then 'OK' else 'PERIKSA (aktifkan pg_cron)' end from cron.job
union all
select 'view', count(*)::text, case when count(*) >= 5 then 'OK' else 'GAGAL' end from pg_views where schemaname = 'public'
order by 1;
