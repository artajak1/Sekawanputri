-- Tahap 2: Auth + peran. Jalankan setelah 01_schema.sql.

-- 1) Profil otomatis saat user dibuat (Dashboard > Authentication > Add user)
create or replace function fn_new_user() returns trigger
language plpgsql security definer set search_path = public as $$
begin
  insert into profiles (id, full_name, role)
  values (new.id, coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)), 'mandor')
  on conflict (id) do nothing;
  return new;
end $$;

drop trigger if exists trg_new_user on auth.users;
create trigger trg_new_user after insert on auth.users
  for each row execute function fn_new_user();

-- 2) Hanya owner yang boleh mengubah peran / menugaskan proyek
create or replace function set_user_role(target uuid, new_role app_role)
returns void language plpgsql security definer set search_path = public as $$
begin
  if my_role() <> 'owner' then raise exception 'Hanya owner yang boleh mengubah peran'; end if;
  update profiles set role = new_role where id = target;
end $$;

create or replace function assign_project(target uuid, pid uuid)
returns void language plpgsql security definer set search_path = public as $$
begin
  if my_role() not in ('owner','pm') then raise exception 'Tidak diizinkan'; end if;
  insert into project_members(project_id, user_id) values (pid, target) on conflict do nothing;
end $$;

-- 3) Pengguna tidak bisa mengubah perannya sendiri lewat update langsung
create policy "update profil: nama/telepon saja" on profiles for update
  using (id = auth.uid())
  with check (id = auth.uid() and role = (select role from profiles where id = auth.uid()));

-- Cara pakai pertama kali:
--  a. Buat akun Anda di Dashboard, lalu jalankan sekali di SQL Editor:
--     update profiles set role = 'owner' where id = '<UUID-akun-anda>';
--  b. Setelah itu atur peran lainnya: select set_user_role('<uuid>', 'pm');
