-- Tahap 5: Payroll (absensi HOK, kasbon, rekap upah mingguan). Jalankan setelah 04_whatsapp.sql.

-- 1) Pelengkap tabel
alter table worker_advances add column if not exists repaid numeric(14,2) not null default 0;
insert into app_settings values ('advance_max_pct', '50') on conflict do nothing;  -- potongan kasbon maks % dari upah kotor

create table if not exists payroll_runs (
  id          uuid primary key default gen_random_uuid(),
  project_id  uuid not null references projects(id) on delete cascade,
  week_start  date not null,                      -- hari pertama pekan (Senin)
  status      approval_status not null default 'submitted',
  total_gross numeric(16,2) not null default 0,
  total_deduct numeric(16,2) not null default 0,
  total_net   numeric(16,2) not null default 0,
  created_by  uuid not null references profiles(id),
  decided_by  uuid references profiles(id),
  decided_at  timestamptz,
  unique (project_id, week_start)
);
create table if not exists payroll_lines (
  run_id          uuid not null references payroll_runs(id) on delete cascade,
  worker_id       uuid not null references workers(id),
  hok_total       numeric(6,2) not null,
  daily_wage      numeric(14,2) not null,         -- upah dibekukan saat dihitung
  gross           numeric(16,2) not null,
  advance_deduct  numeric(14,2) not null default 0,
  net             numeric(16,2) not null,
  primary key (run_id, worker_id)
);

-- 2) RLS
alter table payroll_runs  enable row level security;
alter table payroll_lines enable row level security;

create policy "pekerja baca" on workers for select using (is_member(project_id));
create policy "pekerja kelola" on workers for all
  using (my_role() in ('pm','admin_proyek') and is_member(project_id))
  with check (my_role() in ('pm','admin_proyek') and is_member(project_id));

create policy "absensi baca" on attendance for select
  using (exists (select 1 from workers w where w.id = worker_id and is_member(w.project_id)));
create policy "absensi tulis" on attendance for insert
  with check (my_role() in ('mandor','admin_proyek','pm') and created_by = auth.uid()
    and exists (select 1 from workers w where w.id = worker_id and is_member(w.project_id)));
create policy "absensi ubah" on attendance for update
  using (my_role() in ('mandor','admin_proyek','pm')
    and exists (select 1 from workers w where w.id = worker_id and is_member(w.project_id)));

create policy "kasbon baca" on worker_advances for select
  using (exists (select 1 from workers w where w.id = worker_id and is_member(w.project_id))
         and my_role() in ('admin_proyek','pm','finance','owner'));
create policy "kasbon tulis" on worker_advances for insert
  with check (my_role() in ('admin_proyek','pm') and created_by = auth.uid()
    and exists (select 1 from workers w where w.id = worker_id and is_member(w.project_id)));

create policy "rekap baca" on payroll_runs for select using (is_member(project_id));
create policy "baris rekap baca" on payroll_lines for select
  using (exists (select 1 from payroll_runs r where r.id = run_id and is_member(r.project_id)));
-- Tulis hanya lewat fungsi di bawah (security definer)

-- 3) Absensi pekan yang sudah disetujui tidak boleh diubah
create or replace function fn_lock_attendance() returns trigger
language plpgsql security definer set search_path = public as $$
declare d date := coalesce(new.work_date, old.work_date); pid uuid;
begin
  select project_id into pid from workers where id = coalesce(new.worker_id, old.worker_id);
  if exists (select 1 from payroll_runs where project_id = pid and status = 'approved'
             and d between week_start and week_start + 6) then
    raise exception 'Upah pekan ini sudah disetujui, absensi terkunci';
  end if;
  return coalesce(new, old);
end $$;
drop trigger if exists trg_lock_att on attendance;
create trigger trg_lock_att before insert or update or delete on attendance
  for each row execute function fn_lock_attendance();

-- 4) Hitung rekap upah satu pekan (boleh dihitung ulang selama belum disetujui)
create or replace function generate_payroll(p_project uuid, p_week_start date)
returns uuid language plpgsql security definer set search_path = public as $$
declare rid uuid; w record; v_hok numeric; gross numeric; owed numeric; cap numeric; ded numeric;
        pct numeric; tg numeric := 0; td numeric := 0;
begin
  if my_role() not in ('pm','admin_proyek') or not is_member(p_project) then
    raise exception 'Tidak diizinkan'; end if;
  select value::numeric into pct from app_settings where key = 'advance_max_pct';
  pct := coalesce(pct, 50);

  select id into rid from payroll_runs where project_id = p_project and week_start = p_week_start;
  if rid is not null then
    if (select status from payroll_runs where id = rid) = 'approved' then
      raise exception 'Rekap pekan ini sudah disetujui'; end if;
    delete from payroll_lines where run_id = rid;
    update payroll_runs set status = 'submitted', decided_by = null, decided_at = null where id = rid;
  else
    insert into payroll_runs(project_id, week_start, created_by)
    values (p_project, p_week_start, auth.uid()) returning id into rid;
  end if;

  for w in select id, daily_wage from workers where project_id = p_project and is_active loop
    select coalesce(sum(a.hok), 0) into v_hok from attendance a
     where a.worker_id = w.id and a.work_date between p_week_start and p_week_start + 6;
    continue when v_hok = 0;
    gross := v_hok * w.daily_wage;
    select coalesce(sum(amount - repaid), 0) into owed from worker_advances where worker_id = w.id and not settled;
    cap := floor(gross * pct / 100);
    ded := least(owed, cap);
    insert into payroll_lines values (rid, w.id, v_hok, w.daily_wage, gross, ded, gross - ded);
    tg := tg + gross; td := td + ded;
  end loop;

  update payroll_runs set total_gross = tg, total_deduct = td, total_net = tg - td where id = rid;
  perform notify_project_role(p_project, 'pm', 'Rekap upah pekan ' || to_char(p_week_start, 'DD/MM') ||
    ' menunggu persetujuan (total bersih Rp ' || to_char(tg - td, 'FM999G999G999G999') || ').',
    'payroll-' || rid || '-' || extract(epoch from now())::bigint);
  return rid;
end $$;

-- 5) Keputusan PM. Potongan kasbon baru dicatat saat disetujui (FIFO dari kasbon terlama).
create or replace function decide_payroll(p_run uuid, p_approve boolean)
returns approval_status language plpgsql security definer set search_path = public as $$
declare r payroll_runs; l record; a record; left_amt numeric; take numeric;
begin
  if my_role() <> 'pm' then raise exception 'Hanya PM yang dapat memutuskan'; end if;
  select * into r from payroll_runs where id = p_run for update;
  if not found or not is_member(r.project_id) then raise exception 'Rekap tidak ditemukan'; end if;
  if r.status = 'approved' then raise exception 'Sudah disetujui'; end if;

  if not p_approve then
    update payroll_runs set status = 'rejected', decided_by = auth.uid(), decided_at = now() where id = p_run;
    return 'rejected';
  end if;

  for l in select worker_id, advance_deduct from payroll_lines where run_id = p_run and advance_deduct > 0 loop
    left_amt := l.advance_deduct;
    for a in select id, amount, repaid from worker_advances
              where worker_id = l.worker_id and not settled order by given_on, id for update loop
      exit when left_amt <= 0;
      take := least(left_amt, a.amount - a.repaid);
      update worker_advances set repaid = repaid + take, settled = (repaid + take >= amount) where id = a.id;
      left_amt := left_amt - take;
    end loop;
  end loop;

  update payroll_runs set status = 'approved', decided_by = auth.uid(), decided_at = now() where id = p_run;
  perform notify_role('finance', 'Upah pekan ' || to_char(r.week_start, 'DD/MM') ||
    ' disetujui, total bersih Rp ' || to_char(r.total_net, 'FM999G999G999G999') || '. Siap dibayarkan.', 'payroll-ok-' || p_run);
  return 'approved';
end $$;
