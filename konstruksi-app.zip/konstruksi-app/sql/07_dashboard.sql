-- Tahap 7: Dasbor eksekutif. Jalankan setelah 06_purchase_orders.sql.

-- 1) Jadwal rencana mingguan (kurva S rencana), diisi PM/Estimator
create table if not exists project_schedule (
  project_id      uuid not null references projects(id) on delete cascade,
  week_start      date not null,
  planned_cum_pct numeric(5,2) not null check (planned_cum_pct between 0 and 100),
  primary key (project_id, week_start)
);
alter table project_schedule enable row level security;
create policy "jadwal baca" on project_schedule for select using (is_member(project_id));
create policy "jadwal tulis" on project_schedule for all
  using (my_role() in ('pm','estimator') and is_member(project_id))
  with check (my_role() in ('pm','estimator') and is_member(project_id));

-- 2) Persetujuan laporan harian oleh PM (dibutuhkan agar progres masuk kurva S)
create or replace function decide_report(p_report uuid, p_approve boolean, p_note text default null)
returns approval_status language plpgsql security definer set search_path = public as $$
declare r daily_reports;
begin
  if my_role() <> 'pm' then raise exception 'Hanya PM yang dapat memutuskan'; end if;
  select * into r from daily_reports where id = p_report for update;
  if not found or not is_member(r.project_id) then raise exception 'Laporan tidak ditemukan'; end if;
  if r.status <> 'submitted' then raise exception 'Laporan sudah diputuskan'; end if;
  update daily_reports set status = case when p_approve then 'approved'::approval_status else 'rejected' end,
         notes = case when p_approve or p_note is null then notes else coalesce(notes, '') || E'\n[PM] ' || p_note end
   where id = p_report;
  return case when p_approve then 'approved'::approval_status else 'rejected' end;
end $$;

-- 3) Ringkasan dasbor dalam SATU panggilan (hemat egress). Berjalan dengan hak pengguna, jadi RLS tetap berlaku.
create or replace function dashboard_summary(p_project uuid) returns jsonb
language sql stable set search_path = public as $$
select jsonb_build_object(
  'contract_value', (select contract_value from projects where id = p_project),
  'actual_pct',  (select coalesce(max(physical_pct), 0) from daily_reports where project_id = p_project and status = 'approved'),
  'planned_pct', coalesce((select planned_cum_pct from project_schedule
                            where project_id = p_project and week_start <= current_date
                            order by week_start desc limit 1), 0),
  'cash_balance', coalesce((select balance from petty_cash_balance where project_id = p_project), 0),
  'po', (select jsonb_build_object('ordered', coalesce(sum(ordered), 0), 'received', coalesce(sum(received_value), 0),
                                   'invoiced', coalesce(sum(invoiced), 0), 'paid', coalesce(sum(paid), 0))
           from po_match where project_id = p_project and status in ('approved', 'partial', 'received')),
  'pending', (select count(*) from approvals where project_id = p_project and status = 'submitted')
           + (select count(*) from payroll_runs where project_id = p_project and status = 'submitted')
           + (select count(*) from daily_reports where project_id = p_project and status = 'submitted'),
  'curve', coalesce((select jsonb_agg(jsonb_build_object(
              'w', s.week_start, 'plan', s.planned_cum_pct,
              'act', (select case when s.week_start <= current_date then coalesce(max(r.physical_pct), 0) end
                        from daily_reports r where r.project_id = p_project and r.status = 'approved'
                         and r.report_date <= s.week_start + 6)) order by s.week_start)
            from project_schedule s where s.project_id = p_project), '[]'::jsonb)
);
$$;
grant execute on function dashboard_summary(uuid) to authenticated;
revoke execute on function dashboard_summary(uuid) from anon;

-- Contoh isi jadwal (ganti UUID proyek):
-- insert into project_schedule values
--  ('<UUID>', '2026-10-05', 5), ('<UUID>', '2026-10-12', 12), ('<UUID>', '2026-10-19', 22), ('<UUID>', '2026-10-26', 34);
