-- Tahap 3: Kas kecil + approval berjenjang. Jalankan setelah 02_auth.sql.

-- 1) Pengaturan: batas nominal yang butuh persetujuan owner (level 2)
create table if not exists app_settings (key text primary key, value text not null);
insert into app_settings values ('owner_approval_min', '5000000') on conflict do nothing;
alter table app_settings enable row level security;
create policy "settings baca" on app_settings for select using (auth.uid() is not null);
create policy "settings ubah owner" on app_settings for all
  using (my_role() = 'owner') with check (my_role() = 'owner');

-- 2) Saldo kas kecil per proyek (hanya transaksi yang sudah disetujui)
create or replace view petty_cash_balance with (security_invoker = true) as
select project_id,
       coalesce(sum(case direction when 'in' then amount else -amount end), 0) as balance
from petty_cash where status = 'approved' group by project_id;

-- 3) Setiap kas kecil baru otomatis membuat approval level 1 (+ level 2 jika nominal besar)
create or replace function fn_petty_cash_approvals() returns trigger
language plpgsql security definer set search_path = public as $$
declare min_owner numeric;
begin
  select value::numeric into min_owner from app_settings where key = 'owner_approval_min';
  insert into approvals(project_id, ref_table, ref_id, level, requested_by)
  values (new.project_id, 'petty_cash', new.id, 1, new.created_by)
  on conflict do nothing;
  if new.direction = 'out' and new.amount >= coalesce(min_owner, 5000000) then
    insert into approvals(project_id, ref_table, ref_id, level, requested_by)
    values (new.project_id, 'petty_cash', new.id, 2, new.created_by)
    on conflict do nothing;
  end if;
  return new;
end $$;
drop trigger if exists trg_pc_approvals on petty_cash;
create trigger trg_pc_approvals after insert on petty_cash
  for each row execute function fn_petty_cash_approvals();

-- 4) Keputusan approval (satu pintu, divalidasi di server)
create or replace function decide_approval(p_ref_table text, p_ref_id uuid, p_level smallint,
                                           p_approve boolean, p_note text default null)
returns approval_status language plpgsql security definer set search_path = public as $$
declare a approvals; pending_left int; pc petty_cash;
begin
  select * into a from approvals
   where ref_table = p_ref_table and ref_id = p_ref_id and level = p_level for update;
  if not found then raise exception 'Approval tidak ditemukan'; end if;
  if a.status <> 'submitted' then raise exception 'Sudah diputuskan'; end if;
  if (p_level = 1 and my_role() <> 'pm') or (p_level = 2 and my_role() <> 'owner') then
    raise exception 'Peran Anda tidak boleh memutuskan level %', p_level;
  end if;
  if p_level = 2 and exists (select 1 from approvals where ref_table = p_ref_table
        and ref_id = p_ref_id and level = 1 and status <> 'approved') then
    raise exception 'Level 1 (PM) harus disetujui lebih dulu';
  end if;

  update approvals set status = case when p_approve then 'approved'::approval_status else 'rejected' end,
         decided_by = auth.uid(), decided_at = now(), note = p_note where id = a.id;

  if p_ref_table = 'petty_cash' then
    if not p_approve then
      update petty_cash set status = 'rejected' where id = p_ref_id;
      return 'rejected';
    end if;
    select count(*) into pending_left from approvals
     where ref_table = p_ref_table and ref_id = p_ref_id and status <> 'approved';
    if pending_left = 0 then
      update petty_cash set status = 'approved' where id = p_ref_id;
    elsif p_level = 1 then  -- teruskan ke owner via WhatsApp
      select * into pc from petty_cash where id = p_ref_id;
      perform notify_role('owner', 'Persetujuan diperlukan: kas keluar Rp ' || to_char(pc.amount, 'FM999G999G999G999') ||
              ' (' || pc.description || '). Buka aplikasi > Persetujuan.', 'pc-l2-' || pc.id);
    end if;
  end if;
  return case when p_approve then 'approved'::approval_status else 'rejected' end;
end $$;

-- 5) Policy Storage untuk foto nota (bucket privat 'site-photos')
-- Folder pertama path = project_id. Anggota proyek boleh unggah dan baca.
create policy "foto: anggota unggah" on storage.objects for insert to authenticated
  with check (bucket_id = 'site-photos' and is_member(((storage.foldername(name))[1])::uuid));
create policy "foto: anggota baca" on storage.objects for select to authenticated
  using (bucket_id = 'site-photos' and is_member(((storage.foldername(name))[1])::uuid));
create policy "foto: anggota timpa (retry upload)" on storage.objects for update to authenticated
  using (bucket_id = 'site-photos' and is_member(((storage.foldername(name))[1])::uuid));

-- 6) Pengiriman wa_outbox: jalankan lewat Edge Function terjadwal (tahap WhatsApp),
--    yang membaca baris sent_at is null lalu memanggil API Fonnte/Wablas.
