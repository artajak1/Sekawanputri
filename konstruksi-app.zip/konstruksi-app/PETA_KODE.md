# Peta Kode (untuk dilampirkan saat melanjutkan di AI Studio atau alat lain)

Aplikasi manajemen proyek konstruksi: React 18 + Vite + Tailwind 3 (PWA), backend Supabase. Bahasa antarmuka: Indonesia.
Tanpa file `.env` aplikasi berjalan dalam **mode demo** (data contoh di localStorage, klien Supabase tiruan di `src/demo/`).

## Struktur
- `src/main.jsx` → `AuthProvider` → `AuthGate` → `App` (+ `DialogHost`).
- `src/App.jsx` — navigasi per peran (array `NAV`: id, label, roles, komponen lazy). Tambah modul = tambah satu baris `NAV`.
- `src/auth.jsx` — klien Supabase atau demo (`DEMO`), login, `useAuth()`, `RoleGate`.
- `src/ui.jsx` — `Button`, `Card`, `Skeleton`, `ErrorBoundary`. `src/dialog.jsx` — `askConfirm`, `askText` (jangan pakai `window.confirm/prompt`).
- `src/offlineQueue.js` — antrean IndexedDB + auto-sync idempoten (kunci `client_id`). Semua input lapangan lewat `enqueue({table,row,photo,projectId})`.
- `src/imageCompress.js` — kompres foto di klien (<300 KB). `src/download.js` — `saveFile()` (unduhan aman). `src/exportExcel.js` — ekspor xlsx/csv.
- Modul (satu file satu menu): Dashboard, DailyReportForm, ReportApprovals, Payroll, PettyCash, PurchaseOrders, SubconAddendum, Finance, Equipment, Handover, MasterData, DrawingsArchive, ExportPanel.
- `sql/` — skema Supabase 01 sampai 14 (`00_pasang_semua.sql` = gabungan, `99_cek_pasang.sql` = pemeriksaan).
- `src/demo/engine.js` (klien tiruan) dan `src/demo/logic.js` (data contoh + aturan bisnis yang meniru SQL). `tests/demo-test.mjs` = 78 pemeriksaan (`npm run test:demo`).

## Aturan yang harus dijaga
1. Keamanan sebenarnya ada di **RLS dan fungsi SQL** (security definer). `RoleGate` hanya merapikan tampilan.
2. Status persetujuan hanya berubah lewat fungsi (`decide_*`), bukan update langsung. Dokumen yang sudah diajukan tidak punya jalur ubah.
3. Setiap perubahan aturan bisnis dilakukan di **dua tempat**: SQL (`sql/`) dan tiruannya di `src/demo/logic.js`; lalu jalankan `npm run test:demo`.
4. Input lapangan harus tahan offline (lewat `enqueue`), hemat egress (pilih kolom seperlunya, batasi baris), dan punya penanganan error (try/catch, pesan jelas, `console.error`).
5. Tampilan: palet slate, border `border-slate-200`, tombol `active:scale-[0.97]`, kartu `hover:-translate-y-0.5`, loading pakai `Skeleton`.

## Belum ada (lihat daftar di percakapan)
Layar kelola pengguna, koreksi/pembatalan data, laporan harian lengkap, stok gudang, RAP dan progres per item RAB, PDF invoice, ringkasan semua proyek, layar antrean gagal-kirim, tata letak tablet/desktop, mode gelap.
