# Panduan Pasang: Aplikasi Manajemen Proyek Konstruksi

## 0. Coba dulu tanpa Supabase (MODE DEMO)
Tanpa file `.env` (atau dengan `VITE_DEMO=true`), aplikasi berjalan dengan **data contoh di HP/laptop Anda sendiri**. Tidak perlu Supabase, SQL, atau internet setelah `npm install`.
```
# Termux: pkg install nodejs unzip
unzip konstruksi-app.zip && cd konstruksi-app
npm install
npm run dev        # buka http://localhost:5173 di Chrome (alamat lain tertulis di layar)
npm run test:demo  # (opsional) 78 pemeriksaan otomatis atas aturan bisnis
```
- Layar pertama: pilih peran (Owner, PM, Admin proyek, Mandor, Estimator, Keuangan). Peran bisa diganti kapan saja lewat **Menu > Alat mode demo**, jadi satu orang bisa mencoba seluruh alur persetujuan.
- Ada tiga proyek contoh: Gedung Serbaguna (aktif, data paling lengkap), Ruko Mastrip (masa retensi), Gudang Sumbersari (ditutup, untuk arsip dan rekap tahunan).
- Tombol "Percepat jatuh tempo retensi" dan "Reset data" ada di Menu. Data tersimpan di penyimpanan browser; hapus data situs untuk mengulang.
- **Batas mode demo:** hak akses database (RLS) hanya ditiru sebagian; WhatsApp, jadwal otomatis, dan penyimpanan foto permanen tidak disimulasikan (foto hanya hidup selama halaman terbuka); angka dan aturan bisnis mengikuti SQL tetapi ditulis ulang di JavaScript, jadi tetap perlu diuji ulang di Supabase sungguhan.

Stack: React + Vite + Tailwind (PWA) di depan, Supabase (Postgres, Auth, Storage, Edge Function) di belakang.

## Isi proyek
```
src/            kode aplikasi (App.jsx = navigasi, tiap modul 1 file, auth, antrean offline, kompresi gambar, ekspor)
sql/            00_pasang_semua.sql (satu kali jalan), 01 sampai 14 (versi terpisah), 99_cek_pasang.sql, seed_contoh.sql
supabase/functions/send-wa/   pengirim WhatsApp (Fonnte)
public/         ikon PWA
```

## A. Siapkan Supabase (setelah puas dengan demo)
Lakukan di **proyek percobaan yang kosong** dulu, bukan proyek untuk data asli.
1. Buat proyek di supabase.com (pilih wilayah Singapore). Simpan kata sandi database. Catat **Project URL** dan **anon public key** (Settings > API).
2. Authentication > Providers > Email: **matikan "Allow new users to sign up"**. Akun dibuat manual lewat Authentication > Users > Add user.
3. Database > Extensions: aktifkan **pg_cron** dan **pg_net**.
4. Storage: buat dua bucket **privat** (Public = off): `site-photos` dan `drawings`.
5. SQL Editor > New query: buka `sql/00_pasang_semua.sql`, salin seluruh isinya, tempel, tekan **Run**.
   - File ini membungkus semua langkah 01 sampai 14 dalam satu transaksi. Kalau ada satu error, **semuanya dibatalkan** dan tidak ada yang setengah terpasang. Perbaiki, lalu jalankan ulang dari awal.
   - Kirimkan pesan error lengkapnya (termasuk nama baris atau fungsi) kepada pembuat kode untuk diperbaiki.
6. Query baru lagi: tempel `sql/99_cek_pasang.sql`, Run. Kolom **hasil** harus OK di semua baris. Baris yang GAGAL atau PERIKSA, kirimkan juga.
7. Buat akun Anda di Authentication > Users, lalu jadikan owner (komentar di `sql/seed_contoh.sql`). Isi `phone_wa` (08xxxxxxxxxx) untuk owner, PM, admin proyek, dan finance.
8. Buat akun PM, admin, mandor, finance, estimator dan atur perannya. Setelah itu proyek, anggota, tukang, supplier, jadwal kurva S, dan RAB diisi dari menu **Master data** di aplikasi.
9. Isi `.env` dengan URL dan anon key, jalankan ulang aplikasi. Banner "Mode demo" akan hilang dan layar login biasa muncul.
SQL belum pernah dijalankan di database sungguhan oleh pembuatnya, jadi langkah 5 dan 6 adalah ujian pertamanya.

## B. WhatsApp (Fonnte)
1. Daftar di fonnte.com, sambungkan nomor pengirim, ambil token.
2. Pasang Supabase CLI, lalu di folder proyek:
   `supabase link --project-ref <REF>`
   `supabase secrets set FONNTE_TOKEN=<token> CRON_SECRET=<teks-acak-panjang>`
   `supabase functions deploy send-wa --no-verify-jwt`
3. Di SQL Editor simpan dua rahasia Vault (alamat fungsi dan CRON_SECRET), petunjuknya ada di komentar `sql/04_whatsapp.sql`.
4. Uji: buat kas keluar di atas Rp 5.000.000 sebagai admin, setujui sebagai PM, dan lihat tabel `wa_outbox` (kolom `sent_at` terisi bila terkirim, `last_error` bila gagal).

## C. Jalankan aplikasi
```
cp .env.example .env      # isi URL dan anon key (kosong = mode demo)
npm install
npm run dev               # coba di laptop atau Termux
npm run build             # hasil di folder dist/
```
Deploy folder `dist/` ke hosting statis gratis (Cloudflare Pages, Netlify, atau Vercel). Pakai alamat HTTPS karena kamera, service worker, dan kompresi gambar butuh HTTPS.
Pada HP: buka alamatnya di Chrome, lalu menu > "Tambahkan ke layar utama".
**Jangan pernah** memasang service role key di aplikasi. Anon key memang publik, keamanan data dijaga RLS di database.

## D. Pengujian sebelum dipakai di lapangan
Lakukan dengan data contoh, bukan data proyek asli.
1. **Per peran**: masuk sebagai tiap peran, pastikan menu yang tampil sesuai dan tombol yang tidak berhak tidak muncul.
2. **Batas hak (RLS)**: masuk sebagai mandor, coba buka PO atau tagihan lewat menu lain. Seharusnya kosong atau ditolak. Masuk sebagai PM proyek A, pastikan proyek B tidak terlihat.
3. **Offline**: nyalakan mode pesawat, isi laporan harian dengan foto, lalu matikan mode pesawat. Indikator di atas berubah dari "n menunggu kirim" menjadi "Tersinkron", dan data muncul di Supabase satu kali saja.
4. **Alur persetujuan**: kas keluar kecil (PM saja) dan besar (PM lalu owner), PO di atas Rp 10 juta, adendum.
5. **Kompresi**: foto 3 sampai 5 MB di HP harus menjadi di bawah 300 KB (cek ukuran di Storage).
6. **Error**: matikan koneksi saat menekan tombol yang butuh server (mis. Setujui). Pesan error harus tampil dan aplikasi tidak macet. Lihat tabel `client_errors` untuk log.
7. **Ekspor**: unduh tiap laporan dan buka di Excel dan Google Sheets, cocokkan angka total dengan data.

## E. Rilis bertahap (disarankan)
1. Minggu 1 sampai 2: hanya Laporan harian + Absensi untuk satu mandor, sambil data lama tetap dicatat seperti biasa.
2. Berikutnya: Kas kecil, lalu PO dan penerimaan barang, lalu Keuangan dan SPK.
3. Selalu cadangkan database sebelum menjalankan SQL baru (`pg_dump` atau fitur backup Supabase).

## F. Yang belum ada (jujur)
- Koreksi data yang sudah diajukan (sengaja tidak ada jalur ubah demi jejak audit).
- Pajak masukan (PPN supplier), faktur pajak resmi, dan pembayaran sewa alat ke pemilik.
- Master data belum bisa mengubah nilai proyek yang sudah dibuat (nilai kontrak berubah hanya lewat Adendum), dan belum ada hapus proyek (sengaja).
- Impor RAB membaca CSV. Dari Excel gunakan Simpan sebagai CSV. Periksa pratinjau sebelum mengimpor: angka seperti `1.500` dibaca sebagai seribu lima ratus (pemisah ribuan).
- Notifikasi untuk owner dan finance dikirim ke semua yang berperan itu (lintas proyek). Peran lain sudah dibatasi per proyek.
- Tarif pajak (PPN 11% efektif, PPh Final 2,65%) hanya nilai awal; cocokkan dengan akuntan Anda.
