// offlineQueue.js — antrean lokal (IndexedDB) + auto-sync. Data tidak hilang saat sinyal putus.
// Setiap item punya client_id (UUID) -> upsert idempoten, aman diulang.
import { uploadPhoto } from './imageCompress.js';

const DB = 'konstruksi-queue';
const STORE = 'jobs';
const MAX_ATTEMPTS = 8;

const open = () =>
  new Promise((res, rej) => {
    const r = indexedDB.open(DB, 1);
    r.onupgradeneeded = () => r.result.createObjectStore(STORE, { keyPath: 'client_id' });
    r.onsuccess = () => res(r.result);
    r.onerror = () => rej(r.error);
  });

async function tx(mode, fn) {
  const db = await open();
  return new Promise((res, rej) => {
    const t = db.transaction(STORE, mode);
    const out = fn(t.objectStore(STORE));
    t.oncomplete = () => res(out?.result);
    t.onerror = () => rej(t.error);
  });
}

/** Simpan ke antrean. table: 'daily_reports' | 'petty_cash' | ...; photo: File (opsional) */
export async function enqueue({ table, row, photo, projectId }) {
  const client_id = row.client_id || crypto.randomUUID();
  const job = { client_id, table, row: { ...row, client_id }, photo: photo || null,
                projectId, attempts: 0, error: null, created: Date.now() };
  await tx('readwrite', (s) => s.put(job)); // Blob/File ikut tersimpan di IndexedDB
  trySync(); // coba langsung, tanpa menunggu
  return client_id;
}

export const pending = () => tx('readonly', (s) => s.getAll()).then((r) => r || []);

let running = false;
export async function trySync(supabase = window.__supabase, onChange = () => {}) {
  if (running || !navigator.onLine || !supabase) return;
  running = true;
  try {
    for (const job of await pending()) {
      if (job.attempts >= MAX_ATTEMPTS) continue;
      try {
        let attachment = null;
        if (job.photo) {
          attachment = await uploadPhoto(supabase, {
            projectId: job.projectId, clientId: job.client_id, file: job.photo,
          });
        }
        // Ingat bila baris sudah masuk: retry (mis. karena lampiran gagal) tidak mengulang upsert
        let rowId = job.rowId;
        if (!rowId) {
          const { data, error } = await supabase
            .from(job.table).upsert(job.row, { onConflict: 'client_id' }).select('id').single();
          if (error) throw error;
          rowId = job.rowId = data.id;
          await tx('readwrite', (s) => s.put(job));
        }
        if (attachment) {
          const { error: e2 } = await supabase.from('attachments').upsert(
            { client_id: job.client_id, project_id: job.projectId, ref_table: job.table,
              ref_id: rowId, storage_path: attachment.path, mime_type: attachment.mime,
              size_bytes: attachment.size_bytes, width: attachment.width, height: attachment.height,
              created_by: job.row.created_by },
            { onConflict: 'client_id' });
          if (e2) throw e2;
        }
        await tx('readwrite', (s) => s.delete(job.client_id)); // hapus HANYA setelah sukses
      } catch (err) {
        console.error('[sync]', job.table, job.client_id, err);
        await tx('readwrite', (s) => s.put({ ...job, attempts: job.attempts + 1, error: String(err.message || err) }));
      }
      onChange();
    }
  } finally {
    running = false;
  }
}

// Sync otomatis: saat sinyal kembali, saat tab aktif lagi, dan berkala
export function startAutoSync(supabase, onChange) {
  window.__supabase = supabase;
  const go = () => trySync(supabase, onChange);
  addEventListener('online', go);
  document.addEventListener('visibilitychange', () => !document.hidden && go());
  const id = setInterval(go, 30000);
  go();
  return () => { removeEventListener('online', go); clearInterval(id); };
}
