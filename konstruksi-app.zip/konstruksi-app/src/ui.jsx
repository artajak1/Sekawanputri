// ui.jsx — komponen dasar. Tailwind core utility saja, palet slate.
import React from 'react';

const cx = (...c) => c.filter(Boolean).join(' ');

const VARIANTS = {
  primary:
    'bg-slate-900 text-white border border-slate-900 hover:bg-slate-800 focus-visible:ring-slate-900/30',
  secondary:
    'bg-white text-slate-900 border border-slate-200 hover:bg-slate-50 hover:border-slate-300 focus-visible:ring-slate-400/30',
  danger:
    'bg-white text-red-700 border border-red-200 hover:bg-red-50 focus-visible:ring-red-500/25',
  ghost:
    'bg-transparent text-slate-700 border border-transparent hover:bg-slate-100 focus-visible:ring-slate-400/30',
};

const SIZES = {
  sm: 'h-8 px-3 text-sm',
  md: 'h-10 px-4 text-sm',
  lg: 'h-12 px-5 text-base', // target sentuh nyaman di lapangan
};

export const Button = React.forwardRef(function Button(
  { variant = 'primary', size = 'md', loading = false, disabled, className, children, ...props },
  ref
) {
  const isOff = disabled || loading;
  return (
    <button
      ref={ref}
      disabled={isOff}
      aria-busy={loading || undefined}
      className={cx(
        'inline-flex items-center justify-center gap-2 rounded-lg font-medium select-none',
        'transition-transform duration-100 active:scale-[0.97]',
        'transition-colors outline-none focus-visible:ring-4',
        'disabled:opacity-50 disabled:pointer-events-none',
        'motion-reduce:transition-none motion-reduce:active:scale-100',
        VARIANTS[variant],
        SIZES[size],
        className
      )}
      {...props}
    >
      {loading && (
        <span
          aria-hidden="true"
          className="h-3.5 w-3.5 rounded-full border-2 border-current border-t-transparent animate-spin"
        />
      )}
      {children}
    </button>
  );
});

export function Card({ as: Tag = 'div', interactive = false, className, children, ...props }) {
  return (
    <Tag
      className={cx(
        'rounded-xl border border-slate-200 bg-white p-4 shadow-sm',
        interactive &&
          'transition duration-150 hover:-translate-y-0.5 hover:border-slate-300 hover:shadow-md motion-reduce:hover:translate-y-0',
        className
      )}
      {...props}
    >
      {children}
    </Tag>
  );
}

export function Skeleton({ className }) {
  return <div aria-hidden="true" className={cx('animate-pulse rounded-md bg-slate-200/70', className)} />;
}

export function CardSkeleton() {
  return (
    <Card aria-busy="true">
      <Skeleton className="h-3 w-24" />
      <Skeleton className="mt-3 h-7 w-40" />
      <Skeleton className="mt-4 h-2 w-full" />
    </Card>
  );
}

// Error Boundary: satu modul rusak tidak menjatuhkan seluruh aplikasi
export class ErrorBoundary extends React.Component {
  state = { error: null };
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error, info) {
    // Dikirim ke tabel client_errors lewat logger.js (lihat sql/13_errors.sql)
    console.error('[ErrorBoundary]', this.props.name || 'modul', error, info.componentStack);
    window.__logError?.(`ErrorBoundary:${this.props.name || 'modul'}`, error);
  }
  render() {
    if (!this.state.error) return this.props.children;
    return (
      <Card className="border-red-200">
        <p className="text-sm font-medium text-slate-900">Modul ini gagal dimuat</p>
        <p className="mt-1 text-sm text-slate-600">Data Anda aman. Coba muat ulang modul.</p>
        <Button className="mt-3" variant="secondary" size="sm" onClick={() => this.setState({ error: null })}>
          Muat ulang
        </Button>
      </Card>
    );
  }
}

// Contoh pakai
export function Demo() {
  const [saving, setSaving] = React.useState(false);
  return (
    <div className="mx-auto max-w-md space-y-3 p-4">
      <Card interactive>
        <p className="text-sm text-slate-500">Progres fisik</p>
        <p className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">42,5%</p>
      </Card>
      <CardSkeleton />
      <Button
        size="lg"
        className="w-full"
        loading={saving}
        onClick={() => {
          setSaving(true);
          setTimeout(() => setSaving(false), 1200);
        }}
      >
        Simpan laporan
      </Button>
    </div>
  );
}
