// demo/engine.js — klien Supabase TIRUAN untuk mode demo. Data hidup di memori + localStorage HP, tidak dikirim ke mana pun.
// Hanya mendukung bagian API yang dipakai aplikasi ini. Bukan pengganti Supabase sungguhan.
import { seedDb, makeLogic } from './logic.js';

const DB_KEY = 'demo-db-v1';
const SESSION_KEY = 'demo-session-v1';
const uuid = () => crypto.randomUUID();
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const clone = (x) => (x === undefined ? x : JSON.parse(JSON.stringify(x)));
const get = (o, path) => path.split('.').reduce((a, k) => (a == null ? a : a[k]), o);
const same = (a, b) => a === b || (a != null && b != null && String(a) === String(b));

// Relasi untuk select bertingkat: 'tabel.nama' -> [kolomLokal, tabelTujuan, kolomTujuan, satu?]
const REL = {
  'project_members.profiles': ['user_id', 'profiles', 'id', true], 'daily_reports.profiles': ['created_by', 'profiles', 'id', true],
  'payroll_lines.workers': ['worker_id', 'workers', 'id', true], 'purchase_orders.suppliers': ['supplier_id', 'suppliers', 'id', true],
  'supplier_invoices.purchase_orders': ['po_id', 'purchase_orders', 'id', true], 'drawings.drawing_versions': ['id', 'drawing_versions', 'drawing_id', false],
};

function splitTop(s) { const out = []; let d = 0, cur = ''; for (const ch of s) { if (ch === '(') d++; if (ch === ')') d--; if (ch === ',' && !d) { out.push(cur.trim()); cur = ''; } else cur += ch; } if (cur.trim()) out.push(cur.trim()); return out; }

export function createMockClient() {
  let db = null;
  try { db = JSON.parse(localStorage.getItem(DB_KEY)); } catch { db = null; }
  if (!db || !db.profiles) db = seedDb();
  let session = null; try { session = JSON.parse(localStorage.getItem(SESSION_KEY)); } catch { session = null; }
  const listeners = new Set(); const blobs = new Map(); let saveTimer = null;
  const save = () => { clearTimeout(saveTimer); saveTimer = setTimeout(() => { try { localStorage.setItem(DB_KEY, JSON.stringify(db)); } catch { /* penuh */ } }, 150); };

  const auth = { uid: () => session?.user.id || null, role: () => db.profiles.find((p) => p.id === session?.user.id)?.role || null };
  const logic = makeLogic(() => db, auth);

  const rowsOf = (t) => (logic.views[t] ? logic.views[t]() : db[t]);

  function embed(t, row, token) {
    const m = token.match(/^([a-z_]+)(?:![a-z_]+)?\(([^)]*)\)$/); if (!m) return true;
    const rel = REL[`${t}.${m[1]}`]; if (!rel) return true;
    const [lk, tt, fk, one] = rel; const target = rowsOf(tt).filter((x) => same(x[fk], row[lk]));
    row[m[1]] = one ? clone(target[0] ?? null) : clone(target);
    return !(token.includes('!inner') && one && !target[0]);
  }

  class Q {
    constructor(table) { this.t = table; this.op = 'select'; this.f = []; this.ord = []; this.lim = null; this.rg = null; this.cols = '*'; this.one = null; this.pl = null; this.opt = {}; this.ret = false; }
    select(c = '*') { if (this.op === 'select') this.cols = c; else { this.ret = true; this.cols = c; } return this; }
    insert(p, o) { this.op = 'insert'; this.pl = p; this.opt = o || {}; return this; }
    upsert(p, o) { this.op = 'upsert'; this.pl = p; this.opt = o || {}; return this; }
    update(p) { this.op = 'update'; this.pl = p; return this; }
    delete() { this.op = 'delete'; return this; }
    eq(c, v) { this.f.push((r) => same(get(r, c), v)); return this; }
    neq(c, v) { this.f.push((r) => !same(get(r, c), v)); return this; }
    in(c, vs) { this.f.push((r) => vs.some((v) => same(get(r, c), v))); return this; }
    gte(c, v) { this.f.push((r) => get(r, c) != null && get(r, c) >= v); return this; }
    lte(c, v) { this.f.push((r) => get(r, c) != null && get(r, c) <= v); return this; }
    or(expr) {
      const conds = splitTop(expr).map((e) => { const [col, op, ...rest] = e.split('.'); const val = rest.join('.'); return (r) => op === 'ilike' ? new RegExp('^' + val.replace(/[.*+?^${}()|[\]\\]/g, '\\$&').replace(/%/g, '.*') + '$', 'i').test(String(get(r, col) ?? '')) : same(get(r, col), val); });
      this.f.push((r) => conds.some((c) => c(r))); return this;
    }
    order(c, o = {}) { this.ord.push([c, o.ascending !== false, o.nullsFirst]); return this; }
    limit(n) { this.lim = n; return this; }
    range(a, b) { this.rg = [a, b]; return this; }
    single() { this.one = 'single'; return this; }
    maybeSingle() { this.one = 'maybe'; return this; }
    then(res, rej) { return this.run().then(res, rej); }

    async run() {
      await sleep(90);
      try { const out = this.exec(); if (this.op !== 'select') save(); return out; }
      catch (e) { return { data: null, error: { message: e.message || String(e), code: e.code || 'P0001' } }; }
    }
    finish(rows) {
      let out = rows;
      if (this.one) {
        if (out.length === 0 && this.one === 'maybe') return { data: null, error: null };
        if (out.length !== 1) return { data: null, error: { message: 'JSON object requested, multiple (or no) rows returned', code: 'PGRST116' } };
        out = out[0];
      }
      return { data: clone(out), error: null };
    }
    exec() {
      const t = this.t;
      if (this.op === 'select') {
        const tokens = splitTop(this.cols).filter((c) => c.includes('('));
        let rows = rowsOf(t).map((r) => ({ ...r })); const keep = [];
        const needEmbedFirst = tokens.length > 0;
        if (needEmbedFirst) rows = rows.filter((r) => tokens.map((tk) => embed(t, r, tk)).every(Boolean));
        rows = rows.filter((r) => this.f.every((fn) => fn(r))); void keep;
        for (const [c, asc, nf] of [...this.ord].reverse()) {
          rows.sort((a, b) => { const x = get(a, c), y = get(b, c); if (x == null && y == null) return 0; if (x == null) return nf ? -1 : 1; if (y == null) return nf ? 1 : -1; return (x < y ? -1 : x > y ? 1 : 0) * (asc ? 1 : -1); });
        }
        if (this.rg) rows = rows.slice(this.rg[0], this.rg[1] + 1);
        if (this.lim != null) rows = rows.slice(0, this.lim);
        return this.finish(rows);
      }
      const tbl = db[t]; if (!tbl) throw new Error(`Tabel ${t} tidak ada di mode demo`);
      if (this.op === 'insert' || this.op === 'upsert') {
        const items = Array.isArray(this.pl) ? this.pl : [this.pl]; const out = [];
        const keys = (this.opt.onConflict || 'id').split(',').map((s) => s.trim());
        for (const item of items) {
          let existing = null;
          if (this.op === 'upsert') existing = tbl.find((r) => keys.every((k) => item[k] !== undefined && same(r[k], item[k])));
          if (!existing && item.client_id && tbl.some((r) => r.client_id === item.client_id)) {
            if (this.op === 'insert') { const e = new Error('Data dengan client_id ini sudah ada'); e.code = '23505'; throw e; }
            existing = tbl.find((r) => r.client_id === item.client_id);
          }
          if (existing) { logic.beforeUpdate?.(t, existing, item); Object.assign(existing, item, { id: existing.id }); out.push(existing); continue; }
          const row = { id: uuid(), created_at: new Date().toISOString(), ...item };
          logic.beforeInsert(t, row); tbl.push(row);
          try { logic.afterInsert(t, row); } catch (e) { tbl.splice(tbl.indexOf(row), 1); throw e; }
          out.push(row);
        }
        return this.ret ? this.finish(out) : { data: null, error: null };
      }
      const hit = tbl.filter((r) => this.f.every((fn) => fn(r)));
      if (this.op === 'update') { hit.forEach((r) => Object.assign(r, this.pl)); return this.ret ? this.finish(hit) : { data: null, error: null }; }
      if (this.op === 'delete') { hit.forEach((r) => tbl.splice(tbl.indexOf(r), 1)); return { data: null, error: null }; }
      throw new Error('Operasi tidak didukung');
    }
  }

  const notify = (event) => listeners.forEach((cb) => { try { cb(event, session); } catch { /* abaikan */ } });
  const authApi = {
    async getSession() { return { data: { session } }; },
    onAuthStateChange(cb) { listeners.add(cb); return { data: { subscription: { unsubscribe: () => listeners.delete(cb) } } }; },
    async signInWithPassword({ email }) {
      await sleep(250); const u = db.profiles.find((p) => p.email === String(email).trim().toLowerCase());
      if (!u) return { data: null, error: { message: 'Invalid login credentials' } };
      session = { user: { id: u.id, email: u.email } }; localStorage.setItem(SESSION_KEY, JSON.stringify(session)); notify('SIGNED_IN'); return { data: { session }, error: null };
    },
    async signOut() { session = null; localStorage.removeItem(SESSION_KEY); notify('SIGNED_OUT'); return { error: null }; },
  };

  const storage = { from: (bucket) => ({
    async upload(path, blob) { blobs.set(`${bucket}/${path}`, blob); return { data: { path }, error: null }; },
    async remove(paths) { paths.forEach((p) => blobs.delete(`${bucket}/${p}`)); return { data: null, error: null }; },
    async createSignedUrl(path) {
      const b = blobs.get(`${bucket}/${path}`);
      if (b) return { data: { signedUrl: URL.createObjectURL(b) }, error: null };
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 560"><rect width="800" height="560" fill="#f8fafc"/><rect x="40" y="40" width="720" height="480" fill="none" stroke="#0f172a" stroke-width="3"/><path d="M40 200H760M300 40V520M300 360H760" stroke="#64748b" stroke-width="2" fill="none"/><text x="60" y="90" font-family="sans-serif" font-size="26" fill="#0f172a">GAMBAR CONTOH (MODE DEMO)</text><text x="60" y="125" font-family="sans-serif" font-size="16" fill="#64748b">${path.split('/').pop()}</text></svg>`;
      return { data: { signedUrl: URL.createObjectURL(new Blob([svg], { type: 'image/svg+xml' })) }, error: null };
    },
  }) };

  const client = {
    from: (t) => new Q(t), auth: authApi, storage,
    async rpc(name, args = {}) {
      await sleep(90);
      try { const fn = logic.rpc[name]; if (!fn) throw new Error(`Fungsi ${name} belum ada di mode demo`); const data = fn(args); save(); return { data: clone(data ?? null), error: null }; }
      catch (e) { return { data: null, error: { message: e.message || String(e), code: 'P0001' } }; }
    },
    // alat khusus demo
    demo: {
      users: () => clone(db.profiles.map((p) => ({ id: p.id, email: p.email, full_name: p.full_name, role: p.role }))),
      reset() { localStorage.removeItem(DB_KEY); db = seedDb(); logic.rebind?.(); save(); },
      expireRetention() { db.retention_claims.forEach((c) => { if (c.status === 'held') c.due_date = new Date().toISOString().slice(0, 10); }); save(); },
    },
  };
  return client;
}
