// demo/logic.js — data contoh + aturan bisnis yang meniru SQL (trigger, view, fungsi). Hanya untuk mode demo.
const uuid = () => crypto.randomUUID();
const iso = (d) => d.toISOString().slice(0, 10);
const addDays = (d, n) => { const x = new Date(d); x.setUTCDate(x.getUTCDate() + n); return x; };
const mondayOf = (d = new Date()) => { const x = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())); x.setUTCDate(x.getUTCDate() - ((x.getUTCDay() + 6) % 7)); return x; };
const nowISO = () => new Date().toISOString();
const fail = (m) => { throw new Error(m); };
const rp = (n) => new Intl.NumberFormat('id-ID').format(Math.round(n));
const smooth = (n) => Array.from({ length: n }, (_, i) => { const t = (i + 1) / n; return Math.round((3 * t * t - 2 * t * t * t) * 1000) / 10; });

export function seedDb() {
  const today = new Date(); const T = iso(today); const mon = mondayOf(today); const yr = today.getFullYear();
  const D = Object.fromEntries(['addenda', 'app_settings', 'approvals', 'attachments', 'attendance', 'client_errors', 'client_invoices', 'client_terms', 'daily_reports', 'delivery_items', 'delivery_notes', 'drawings', 'drawing_versions', 'equipment', 'equipment_logs', 'handovers', 'payroll_lines', 'payroll_runs', 'petty_cash', 'po_items', 'profiles', 'project_members', 'project_schedule', 'projects', 'punch_fixes', 'punch_items', 'purchase_orders', 'rab_items', 'retention_claims', 'spk', 'spk_payments', 'spk_progress', 'subcontractors', 'supplier_invoices', 'suppliers', 'worker_advances', 'workers', 'wa_outbox'].map((k) => [k, []]));
  const U = {};
  [['owner', 'Bapak Santoso', 'owner@demo.id'], ['pm', 'Hendra Wijaya', 'pm@demo.id'], ['admin_proyek', 'Sari Wulandari', 'admin@demo.id'], ['mandor', 'Budi Santoso', 'mandor@demo.id'], ['estimator', 'Dewi Lestari', 'estimator@demo.id'], ['finance', 'Rina Pratama', 'finance@demo.id']]
    .forEach(([role, full_name, email], i) => { U[role] = `00000000-0000-4000-8000-00000000000${i + 1}`; D.profiles.push({ id: U[role], email, full_name, role, is_active: true, phone_wa: '0812000000' }); });
  [['owner_approval_min', 5e6], ['po_owner_min', 1e7], ['po_vat_pct', 0], ['ppn_pct', 11], ['pph_final_pct', 2.65], ['pay_owner_min', 25e6], ['spk_owner_min', 5e7], ['advance_max_pct', 50], ['maintenance_months', 6]]
    .forEach(([key, value]) => D.app_settings.push({ key, value: String(value) }));

  const pA = uuid(), pB = uuid(), pC = uuid();
  D.projects.push(
    { id: pA, code: 'GSG-01', name: 'Gedung Serbaguna Tahap 2', client_name: 'Pemerintah Desa Contoh', contract_value: 1850000000, contract_original: null, retention_pct: 5, status: 'active', start_date: iso(addDays(mon, -42)), end_date: iso(addDays(mon, 70)) },
    { id: pB, code: 'RKO-07', name: 'Ruko Jalan Mastrip', client_name: 'PT Maju Bersama', contract_value: 920000000, contract_original: 900000000, retention_pct: 5, status: 'retention', start_date: `${yr}-01-10`, end_date: iso(addDays(today, -120)) },
    { id: pC, code: 'GDG-03', name: 'Gudang Sumbersari', client_name: 'CV Tani Makmur', contract_value: 760000000, contract_original: null, retention_pct: 5, status: 'closed', start_date: `${yr - 1}-03-01`, end_date: `${yr - 1}-12-20` });
  [['pm', pA], ['admin_proyek', pA], ['mandor', pA], ['estimator', pA], ['pm', pB]].forEach(([r, p]) => D.project_members.push({ project_id: p, user_id: U[r] }));

  // jadwal + laporan harian
  const plan = smooth(16);
  plan.forEach((v, i) => D.project_schedule.push({ project_id: pA, week_start: iso(addDays(mon, (i - 6) * 7)), planned_cum_pct: v }));
  const notes = ['Galian dan pondasi selesai', 'Pengecoran sloof', 'Kolom lantai 1 dicor', 'Balok lantai 2 terpasang', 'Pembesian pelat lantai 2', 'Pengecoran pelat lantai 2'];
  for (let k = 0; k < 6; k++) D.daily_reports.push({ id: uuid(), client_id: uuid(), project_id: pA, report_date: iso(addDays(mon, (k - 6) * 7 + 4)), weather: k % 3 === 2 ? 'Berawan' : 'Cerah', physical_pct: Math.round(plan[k] * 0.94 * 10) / 10, notes: notes[k], status: 'approved', created_by: U.mandor, created_at: nowISO() });
  const lastAct = Math.round(plan[5] * 0.94 * 10) / 10;
  [[-1, 'Cerah', 'Bekisting kolom lantai 2 dipasang'], [-2, 'Hujan ringan', 'Pekerjaan terhenti 2 jam karena hujan']].forEach(([d, w, n], i) => D.daily_reports.push({ id: uuid(), client_id: uuid(), project_id: pA, report_date: iso(addDays(today, d)), weather: w, physical_pct: lastAct + 1 + i * 0.4, notes: n, status: 'submitted', created_by: U.mandor, created_at: nowISO() }));

  // tukang, absensi, kasbon
  const W = [['Pak Slamet', 'Tukang batu', 180000, 600000], ['Pak Joko', 'Tukang kayu', 160000, 100000], ['Mas Rudi', 'Kenek', 140000, 0], ['Mas Dedi', 'Kenek', 140000, 0]].map(([name, skill, daily_wage, k]) => {
    const w = { id: uuid(), project_id: pA, name, skill, daily_wage, is_active: true }; D.workers.push(w);
    if (k) D.worker_advances.push({ id: uuid(), client_id: uuid(), worker_id: w.id, amount: k, repaid: 0, settled: false, given_on: iso(addDays(today, -10)), created_by: U.admin_proyek }); return w; });
  for (let wk = -1; wk <= 0; wk++) W.forEach((w, wi) => { for (let d = 0; d < 6; d++) { const date = addDays(mon, wk * 7 + d); if (iso(date) > T) continue; const hok = (wi + d) % 5 === 4 ? 0.5 : (wi === 3 && d === 2) ? 0 : 1; D.attendance.push({ id: uuid(), client_id: uuid(), worker_id: w.id, work_date: iso(date), hok, created_by: U.mandor }); } });

  // kas kecil + approval
  const pc = (dir, amount, description, status, daysAgo, apr) => { const id = uuid(); D.petty_cash.push({ id, client_id: uuid(), project_id: pA, tx_date: iso(addDays(today, -daysAgo)), direction: dir, amount, description, status, created_by: U.admin_proyek, created_at: nowISO() });
    apr.forEach(([level, st]) => D.approvals.push({ id: uuid(), project_id: pA, ref_table: 'petty_cash', ref_id: id, level, status: st, requested_by: U.admin_proyek, decided_by: null, decided_at: null, note: null, created_at: nowISO() })); };
  pc('in', 5000000, 'Isi ulang kas dari kantor', 'approved', 4, [[1, 'approved']]); pc('out', 350000, 'Paku dan kawat bendrat', 'approved', 3, [[1, 'approved']]);
  pc('out', 1250000, 'Upah angkut pasir', 'submitted', 1, [[1, 'submitted']]); pc('out', 6400000, 'Besi beton tambahan 10 mm', 'submitted', 0, [[1, 'approved'], [2, 'submitted']]);

  // supplier, PO, surat jalan, tagihan
  const S = ['Toko Besi Jaya', 'UD Pasir Makmur', 'CV Semen Sentosa'].map((name) => { const s = { id: uuid(), name, phone: '0813000000', is_active: true }; D.suppliers.push(s); return s; });
  const ym = iso(today).slice(2, 4) + iso(today).slice(5, 7);
  const mkPO = (n, sup, status, items, apr) => { const id = uuid(); const total = items.reduce((s, i) => s + i.qty * i.unit_price, 0);
    D.purchase_orders.push({ id, client_id: uuid(), project_id: pA, supplier_id: sup.id, po_number: `PO-${ym}-00${n}`, po_date: T, status, total, items, notes: null, created_by: U.admin_proyek, created_at: nowISO() });
    const pis = items.map((it, i) => { const pi = { id: uuid(), po_id: id, line_no: i + 1, ...it }; D.po_items.push(pi); return pi; });
    apr.forEach(([level, st]) => D.approvals.push({ id: uuid(), project_id: pA, ref_table: 'purchase_orders', ref_id: id, level, status: st, requested_by: U.admin_proyek, decided_by: null, decided_at: null, note: null, created_at: nowISO() }));
    return { id, pis }; };
  const deliver = (po, qtys, sj) => { const dn = { id: uuid(), client_id: uuid(), po_id: po.id, sj_number: sj, received_date: T, items: [], notes: null, created_by: U.admin_proyek, created_at: nowISO() }; D.delivery_notes.push(dn); qtys.forEach((q, i) => q > 0 && D.delivery_items.push({ delivery_id: dn.id, po_item_id: po.pis[i].id, qty: q })); };
  const po1 = mkPO(41, S[0], 'partial', [{ description: 'Besi beton 10 mm', unit: 'batang', qty: 100, unit_price: 85000 }, { description: 'Kawat bendrat', unit: 'roll', qty: 10, unit_price: 30000 }], [[1, 'approved'], [2, 'approved']]); deliver(po1, [40, 10], 'SJ-0912');
  mkPO(42, S[1], 'submitted', [{ description: 'Pasir pasang', unit: 'rit', qty: 12, unit_price: 1200000 }], [[1, 'submitted'], [2, 'submitted']]);
  const po3 = mkPO(43, S[2], 'received', [{ description: 'Semen 50 kg', unit: 'sak', qty: 1000, unit_price: 60000 }], [[1, 'approved'], [2, 'approved']]); deliver(po3, [1000], 'SJ-0388');
  D.supplier_invoices.push({ id: uuid(), client_id: uuid(), po_id: po1.id, invoice_no: 'INV-8812', amount: 6000000, invoice_date: T, due_date: null, status: 'unpaid', paid_at: null, owner_approved: false, created_by: U.admin_proyek },
    { id: uuid(), client_id: uuid(), po_id: po3.id, invoice_no: 'KW-2290', amount: 48500000, invoice_date: T, due_date: null, status: 'unpaid', paid_at: null, owner_approved: false, created_by: U.admin_proyek });

  // SPK + adendum
  const sc = { id: uuid(), name: 'CV Karya Keramik', phone: null, is_active: true }; D.subcontractors.push(sc, { id: uuid(), name: 'Pak Hendra Plafon', phone: null, is_active: true });
  const mkApr = (p, table, id, rows) => rows.forEach(([level, st]) => D.approvals.push({ id: uuid(), project_id: p, ref_table: table, ref_id: id, level, status: st, requested_by: U.pm, decided_by: null, decided_at: null, note: null, created_at: nowISO() }));
  const s1 = uuid(); D.spk.push({ id: s1, client_id: uuid(), project_id: pA, subcon_id: sc.id, spk_number: `SPK-${ym}-0007`, title: 'Pasang keramik lantai 1', contract_value: 85000000, status: 'approved', created_by: U.pm, created_at: nowISO() });
  mkApr(pA, 'spk', s1, [[1, 'approved'], [2, 'approved']]); D.spk_progress.push({ id: uuid(), spk_id: s1, pct: 25, created_by: U.pm }, { id: uuid(), spk_id: s1, pct: 40, created_by: U.pm }); D.spk_payments.push({ id: uuid(), spk_id: s1, amount: 20000000, paid_by: U.finance, paid_at: nowISO() });
  const s2 = uuid(); D.spk.push({ id: s2, client_id: uuid(), project_id: pA, subcon_id: D.subcontractors[1].id, spk_number: `SPK-${ym}-0008`, title: 'Pekerjaan plafon gypsum', contract_value: 62000000, status: 'submitted', created_by: U.pm, created_at: nowISO() }); mkApr(pA, 'spk', s2, [[1, 'approved'], [2, 'submitted']]);
  const a1 = uuid(); D.addenda.push({ id: a1, client_id: uuid(), project_id: pA, number: `ADD-${ym}-001`, title: 'Penambahan kanopi area parkir', reason: 'Permintaan klien', items: [{ type: 'tambah', description: 'Kanopi baja ringan', unit: 'ls', qty: 1, unit_price: 46500000 }], delta: 46500000, status: 'submitted', created_by: U.estimator, created_at: nowISO() }); mkApr(pA, 'addenda', a1, [[1, 'submitted'], [2, 'submitted']]);

  // alat berat
  const eq = (code, name, unit, own, rate, norm, status) => { const e = { id: uuid(), client_id: uuid(), project_id: pA, code, name, meter_unit: unit, ownership: own, rental_rate: rate, rental_basis: 'jam', fuel_norm: norm, status, is_active: true, created_by: U.admin_proyek, created_at: nowISO() }; D.equipment.push(e); return e; };
  const ex = eq('EX-01', 'Excavator PC200', 'HM', 'sewa', 350000, 12, 'approved'), dt = eq('DT-02', 'Dump truck Hino', 'KM', 'milik', 0, 0.25, 'approved'); eq('VR-01', 'Vibro roller', 'HM', 'sewa', 275000, 6, 'pending');
  let hm = 1186, km = 41200;
  for (let d = 5; d >= 1; d--) { const date = iso(addDays(today, -d)); D.equipment_logs.push({ id: uuid(), client_id: uuid(), equipment_id: ex.id, log_date: date, meter_start: hm, meter_end: hm + 8.5, fuel_liters: 140, fuel_price: 12500, note: null, created_by: U.admin_proyek, created_at: nowISO() }); hm += 8.5;
    D.equipment_logs.push({ id: uuid(), client_id: uuid(), equipment_id: dt.id, log_date: date, meter_start: km, meter_end: km + 120, fuel_liters: 30, fuel_price: 12500, note: null, created_by: U.admin_proyek, created_at: nowISO() }); km += 120; }

  // punch list
  [['Retak dinding kamar mandi', 'Lantai 2 ruang B', 'open'], ['Keramik lantai tidak rata', 'Lobi', 'fixed'], ['Cat plafon belang', 'Ruang rapat', 'verified']].forEach(([title, location, status]) => D.punch_items.push({ id: uuid(), client_id: uuid(), project_id: pA, title, location, status, verify_note: null, created_by: U.mandor, created_at: nowISO() }));

  // termin + invoice proyek A
  const term = (p, no, description, pct, amount, status) => { const t = { id: uuid(), client_id: uuid(), project_id: p, term_no: no, description, pct, amount, status, created_by: U.finance }; D.client_terms.push(t); return t; };
  const inv = (p, t, no, date, paid) => { const dpp = t.amount, ppn = Math.round(dpp * 0.11), pph = Math.round(dpp * 0.0265), ret = Math.round(dpp * 0.05); D.client_invoices.push({ id: uuid(), project_id: p, term_id: t.id, invoice_no: no, invoice_date: date, dpp, ppn_amount: ppn, pph_amount: pph, retention_amount: ret, net_receivable: dpp + ppn - pph - ret, status: paid ? 'paid' : 'issued', paid_at: paid ? nowISO() : null, created_by: U.finance }); return ret; };
  inv(pA, term(pA, 1, 'Uang muka', 20, 370000000, 'invoiced'), `INV-${ym}-0031`, iso(addDays(mon, -40)), false); term(pA, 2, 'Pekerjaan struktur', 30, 555000000, 'planned'); term(pA, 3, 'Pekerjaan arsitektur', 30, 555000000, 'planned');
  // proyek B (masa retensi) dan C (ditutup) untuk arsip dan rekap tahunan
  const rB = inv(pB, term(pB, 1, 'Termin 1', 20, 180000000, 'paid'), `INV-${yr}-B01`, `${yr}-03-15`, true) + inv(pB, term(pB, 2, 'Termin 2', 20, 121000000, 'paid'), `INV-${yr}-B02`, `${yr}-06-20`, true);
  D.handovers.push({ project_id: pB, handover_date: iso(addDays(today, -120)), completed_by: U.pm }); D.retention_claims.push({ id: uuid(), project_id: pB, amount: rB, due_date: iso(addDays(today, 62)), status: 'held', released_at: null });
  D.payroll_runs.push({ id: uuid(), project_id: pB, week_start: `${yr}-04-06`, status: 'approved', total_gross: 95000000, total_deduct: 5000000, total_net: 90000000, created_by: U.pm }, { id: uuid(), project_id: pC, week_start: `${yr - 1}-08-04`, status: 'approved', total_gross: 125000000, total_deduct: 5000000, total_net: 120000000, created_by: U.pm });
  D.petty_cash.push({ id: uuid(), client_id: uuid(), project_id: pB, tx_date: `${yr}-05-02`, direction: 'out', amount: 35000000, description: 'Operasional lapangan', status: 'approved', created_by: U.admin_proyek, created_at: nowISO() });
  inv(pC, term(pC, 1, 'Termin akhir', 50, 410000000, 'paid'), `INV-${yr - 1}-C01`, `${yr - 1}-11-10`, true);

  // gambar kerja
  const dw = (code, title, category, vers) => { const id = uuid(); D.drawings.push({ id, project_id: pA, code, title, category, created_by: U.estimator, created_at: nowISO() });
    vers.forEach(([version, days, size, note], i) => D.drawing_versions.push({ id: uuid(), drawing_id: id, version, storage_path: `${pA}/${id}/v${version}.svg`, mime_type: 'image/svg+xml', size_bytes: size, note: note || null, is_current: i === vers.length - 1, created_by: U.estimator, created_at: iso(addDays(today, -days)) + 'T08:00:00Z' })); };
  dw('ARS-01', 'Denah lantai 1', 'arsitektur', [[1, 48, 1700000], [2, 22, 1750000], [3, 8, 1800000, 'Posisi pintu ruang B digeser']]); dw('STR-04', 'Detail penulangan kolom K1', 'struktur', [[1, 45, 940000]]);

  // RAB
  [['A.1', 'Galian tanah pondasi', 'm3', 120, 85000], ['A.2', 'Pondasi batu kali', 'm3', 64.5, 980000], ['B.1', 'Beton K-250 kolom', 'm3', 38, 1650000], ['B.2', 'Besi beton ulir', 'kg', 5400, 16500], ['B.3', 'Bekisting kolom', 'm2', 210, 185000], ['C.1', 'Pasangan bata merah', 'm2', 640, 135000], ['C.2', 'Plesteran dan acian', 'm2', 1280, 78000], ['D.1', 'Keramik lantai 60x60', 'm2', 520, 245000]]
    .forEach(([code, description, unit, volume, unit_price]) => D.rab_items.push({ id: uuid(), project_id: pA, code, description, unit, volume, unit_price, total: volume * unit_price }));
  return D;
}

export function makeLogic(getDb, auth) {
  const db = () => getDb(); const uid = () => auth.uid(); const role = () => auth.role();
  const isMember = (pid) => ['owner', 'finance'].includes(role()) || db().project_members.some((m) => m.project_id === pid && m.user_id === uid());
  const setting = (k, d) => { const s = db().app_settings.find((x) => x.key === k); return s ? Number(s.value) : d; };
  const need = (...roles) => { if (!roles.includes(role())) fail('Peran Anda tidak diizinkan melakukan ini'); };
  const find = (t, id) => db()[t].find((r) => r.id === id);
  const addApr = (p, table, id, level) => db().approvals.push({ id: uuid(), project_id: p, ref_table: table, ref_id: id, level, status: 'submitted', requested_by: uid(), decided_by: null, decided_at: null, note: null, created_at: nowISO() });
  const num = (t, prefix) => `${prefix}-${nowISO().slice(2, 4)}${nowISO().slice(5, 7)}-${String(db()[t].length + 1).padStart(4, '0')}`;

  // ---- tampilan (view) dan pembatasan baca ala RLS ----
  const poMatch = () => db().purchase_orders.map((p) => {
    const its = db().po_items.filter((i) => i.po_id === p.id);
    const received = its.reduce((s, i) => s + db().delivery_items.filter((d) => d.po_item_id === i.id).reduce((a, d) => a + Number(d.qty), 0) * i.unit_price, 0);
    const invs = db().supplier_invoices.filter((x) => x.po_id === p.id);
    return { po_id: p.id, project_id: p.project_id, po_number: p.po_number, status: p.status, ordered: p.total, received_value: received, invoiced: invs.reduce((s, x) => s + Number(x.amount), 0), paid: invs.filter((x) => x.status === 'paid').reduce((s, x) => s + Number(x.amount), 0) };
  });
  const usageRows = () => {
    const g = {};
    db().equipment_logs.forEach((l) => { const e = find('equipment', l.equipment_id); const month = l.log_date.slice(0, 7) + '-01'; const k = e.id + month; const u = (g[k] ||= { equipment_id: e.id, project_id: e.project_id, code: e.code, name: e.name, meter_unit: e.meter_unit, ownership: e.ownership, fuel_norm: e.fuel_norm, month, days: 0, usage: 0, fuel_liters: 0, fuel_cost: 0, e });
      u.days += 1; u.usage += l.meter_end - l.meter_start; u.fuel_liters += Number(l.fuel_liters); u.fuel_cost += Number(l.fuel_liters) * Number(l.fuel_price || 0); });
    return Object.values(g).map((u) => ({ ...u, per_unit: u.usage > 0 ? Math.round((u.fuel_liters / u.usage) * 1000) / 1000 : null,
      rental_cost: u.e.ownership === 'sewa' ? (u.e.rental_basis === 'jam' ? u.usage * u.e.rental_rate : u.days * u.e.rental_rate) : 0, e: undefined }));
  };
  const views = {
    projects: () => db().projects.filter((p) => isMember(p.id)),
    project_members: () => db().project_members.filter((m) => m.user_id === uid() || ['owner', 'pm'].includes(role())),
    profiles: () => db().profiles.filter((p) => p.id === uid() || ['pm', 'owner', 'finance'].includes(role())),
    petty_cash_balance: () => { const o = {}; db().petty_cash.filter((r) => r.status === 'approved').forEach((r) => { o[r.project_id] = (o[r.project_id] || 0) + (r.direction === 'in' ? 1 : -1) * Number(r.amount); }); return Object.entries(o).map(([project_id, balance]) => ({ project_id, balance })); },
    po_match: poMatch,
    spk_summary: () => db().spk.map((s) => ({ id: s.id, project_id: s.project_id, spk_number: s.spk_number, title: s.title, contract_value: s.contract_value, status: s.status, subcon: find('subcontractors', s.subcon_id)?.name,
      progress_pct: Math.max(0, ...db().spk_progress.filter((p) => p.spk_id === s.id).map((p) => Number(p.pct))), paid: db().spk_payments.filter((p) => p.spk_id === s.id).reduce((a, p) => a + Number(p.amount), 0) })),
    equipment_usage: usageRows,
    equipment_log_check: () => {
      const by = {}; db().equipment_logs.forEach((l) => (by[l.equipment_id] ||= []).push(l));
      return Object.values(by).flatMap((ls) => { ls.sort((a, b) => (a.log_date < b.log_date ? -1 : 1)); const e = find('equipment', ls[0].equipment_id);
        return ls.map((l, i) => ({ id: l.id, equipment_id: l.equipment_id, log_date: l.log_date, meter_start: l.meter_start, meter_end: l.meter_end, fuel_liters: l.fuel_liters, usage: l.meter_end - l.meter_start,
          per_unit: l.meter_end > l.meter_start ? Math.round((l.fuel_liters / (l.meter_end - l.meter_start)) * 1000) / 1000 : null, gap_prev: i ? l.meter_start - ls[i - 1].meter_end : null, fuel_norm: e.fuel_norm })); });
    },
  };

  // ---- trigger ----
  function beforeInsert(t, row) {
    const D = db();
    if (t === 'daily_reports' && !['draft', 'submitted'].includes(row.status || 'submitted')) { if (role() !== 'pm') fail('Hanya PM yang dapat menyetujui atau menolak laporan'); }
    if (t === 'daily_reports') row.status = row.status || 'submitted';
    const today = iso(new Date());
    if (t === 'petty_cash') { row.status = 'submitted'; row.tx_date ||= today; }
    if (t === 'supplier_invoices') row.invoice_date ||= today;
    if (t === 'delivery_notes') row.received_date ||= today;
    if (t === 'equipment_logs') row.log_date ||= today;
    if (t === 'daily_reports') row.report_date ||= today;
    if (t === 'purchase_orders') {
      if (!Array.isArray(row.items) || !row.items.length) fail('PO harus memiliki minimal satu item');
      if (row.items.some((i) => !(Number(i.qty) > 0) || !i.description)) fail('Item PO tidak valid (nama atau jumlah kosong)');
      row.total = row.items.reduce((s, i) => s + Number(i.qty) * Number(i.unit_price || 0), 0); row.status = 'submitted'; row.po_date = row.po_date || iso(new Date());
      row.po_number = `PO-${nowISO().slice(2, 4)}${nowISO().slice(5, 7)}-${String(D.purchase_orders.length + 41).padStart(4, '0')}`;
    }
    if (t === 'delivery_notes') {
      const po = find('purchase_orders', row.po_id); if (!po) fail('PO tidak ditemukan');
      if (!['approved', 'partial'].includes(po.status)) fail(`${po.po_number} belum disetujui atau sudah selesai diterima`);
      (row.items || []).forEach((e) => { const q = Number(e.qty) || 0; if (q <= 0) return; const it = D.po_items.find((i) => i.id === e.po_item_id && i.po_id === row.po_id); if (!it) fail('Item tidak ada di PO ini');
        const got = D.delivery_items.filter((d) => d.po_item_id === it.id).reduce((s, d) => s + Number(d.qty), 0); if (got + q > it.qty) fail(`Penerimaan “${it.description}” melebihi pesanan (${it.qty} ${it.unit})`); });
    }
    if (t === 'supplier_invoices') Object.assign(row, { status: 'unpaid', paid_at: null, owner_approved: false });
    if (t === 'spk') { row.status = 'submitted'; row.spk_number = num('spk', 'SPK'); }
    if (t === 'addenda') {
      if (!Array.isArray(row.items) || !row.items.length) fail('Adendum harus memiliki minimal satu item');
      if (row.items.some((i) => !['tambah', 'kurang'].includes(i.type) || !(Number(i.qty) > 0) || !i.description)) fail('Item adendum tidak valid');
      row.delta = row.items.reduce((s, i) => s + (i.type === 'tambah' ? 1 : -1) * Number(i.qty) * Number(i.unit_price || 0), 0); row.status = 'submitted'; row.number = num('addenda', 'ADD');
    }
    if (t === 'equipment') { if (D.equipment.some((e) => e.project_id === row.project_id && e.code === row.code)) fail('Kode alat sudah dipakai'); row.status = row.ownership === 'sewa' ? 'pending' : 'approved'; row.is_active = true; }
    if (t === 'equipment_logs') {
      const e = find('equipment', row.equipment_id); if (!e || e.status !== 'approved') fail('Alat belum disetujui atau tidak aktif');
      if (Number(row.meter_end) < Number(row.meter_start)) fail('Meter akhir tidak boleh lebih kecil dari meter awal');
      if (D.equipment_logs.some((l) => l.equipment_id === row.equipment_id && l.log_date === row.log_date)) fail('Sudah ada catatan untuk alat ini pada tanggal tersebut');
    }
    if (t === 'punch_items') Object.assign(row, { status: 'open', verify_note: null });
    if (t === 'worker_advances') Object.assign(row, { repaid: 0, settled: false, given_on: row.given_on || iso(new Date()) });
    if (t === 'attendance') beforeUpdate(t, null, row);
    if (t === 'client_terms') { row.status = 'planned'; if (D.client_terms.some((x) => x.project_id === row.project_id && x.term_no === row.term_no)) fail('Nomor termin sudah ada'); const used = D.client_terms.filter((x) => x.project_id === row.project_id).reduce((s, x) => s + Number(x.pct), 0); if (used + Number(row.pct) > 100) fail('Total persentase termin melebihi 100'); }
    if (['workers', 'suppliers', 'subcontractors'].includes(t) && row.is_active === undefined) row.is_active = true;
    if (t === 'project_schedule') { /* kunci gabungan ditangani upsert */ }
  }
  function beforeUpdate(t, existing, incoming) {
    if (t !== 'attendance') return;
    const wid = existing?.worker_id || incoming.worker_id, d = existing?.work_date || incoming.work_date; const w = find('workers', wid); if (!w) return;
    if (db().payroll_runs.some((r) => r.project_id === w.project_id && r.status === 'approved' && d >= r.week_start && d <= iso(addDays(new Date(r.week_start + 'T00:00:00Z'), 6)))) fail('Upah pekan ini sudah disetujui, absensi terkunci');
  }
  function afterInsert(t, row) {
    const D = db();
    if (t === 'petty_cash') { addApr(row.project_id, t, row.id, 1); if (row.direction === 'out' && Number(row.amount) >= setting('owner_approval_min', 5e6)) addApr(row.project_id, t, row.id, 2); }
    if (t === 'purchase_orders') {
      row.items.forEach((it, i) => D.po_items.push({ id: uuid(), po_id: row.id, line_no: i + 1, description: it.description, unit: it.unit || 'unit', qty: Number(it.qty), unit_price: Number(it.unit_price || 0) }));
      addApr(row.project_id, t, row.id, 1); if (row.total >= setting('po_owner_min', 1e7)) addApr(row.project_id, t, row.id, 2);
    }
    if (t === 'delivery_notes') {
      (row.items || []).forEach((e) => { const q = Number(e.qty) || 0; if (q > 0) D.delivery_items.push({ delivery_id: row.id, po_item_id: e.po_item_id, qty: q }); });
      const po = find('purchase_orders', row.po_id); const open = D.po_items.filter((i) => i.po_id === po.id && i.qty > D.delivery_items.filter((d) => d.po_item_id === i.id).reduce((s, d) => s + Number(d.qty), 0)).length; po.status = open === 0 ? 'received' : 'partial';
    }
    if (t === 'spk') { addApr(row.project_id, t, row.id, 1); if (row.contract_value >= setting('spk_owner_min', 5e7)) addApr(row.project_id, t, row.id, 2); }
    if (t === 'addenda') { addApr(row.project_id, t, row.id, 1); addApr(row.project_id, t, row.id, 2); }
    if (t === 'punch_fixes') { const p = find('punch_items', row.punch_id); if (p && p.status === 'open') p.status = 'fixed'; }
  }

  // ---- fungsi server ----
  function decide(table, id, level, approve, note) {
    const D = db(); const row = find(table, id);
    if (!row || !isMember(row.project_id)) fail('Dokumen tidak ditemukan');
    const a = D.approvals.find((x) => x.ref_table === table && x.ref_id === id && x.level === level);
    if (!a) fail(`Level ${level} tidak diperlukan`); if (a.status !== 'submitted') fail('Sudah diputuskan');
    if ((level === 1 && role() !== 'pm') || (level === 2 && role() !== 'owner')) fail(`Peran Anda tidak boleh memutuskan level ${level}`);
    if (level === 2 && D.approvals.some((x) => x.ref_table === table && x.ref_id === id && x.level === 1 && x.status !== 'approved')) fail('Level 1 (PM) harus disetujui lebih dulu');
    Object.assign(a, { status: approve ? 'approved' : 'rejected', decided_by: uid(), decided_at: nowISO(), note: note || null });
    if (!approve) { row.status = 'rejected'; return 'rejected'; }
    if (!D.approvals.some((x) => x.ref_table === table && x.ref_id === id && x.status !== 'approved')) {
      row.status = 'approved';
      if (table === 'addenda') { const p = find('projects', row.project_id); const v = Number(p.contract_value) + Number(row.delta); if (v < 0) fail('Nilai kontrak tidak boleh negatif'); p.contract_original ??= p.contract_value; p.contract_value = v; }
    }
    return 'approved';
  }
  const received = (poId) => poMatch().find((m) => m.po_id === poId);
  const rpc = {
    decide_approval: (a) => decide(a.p_ref_table, a.p_ref_id, Number(a.p_level), a.p_approve, a.p_note),
    decide_po: (a) => decide('purchase_orders', a.p_po, Number(a.p_level), a.p_approve, a.p_note),
    decide_doc: (a) => { if (!['spk', 'addenda'].includes(a.p_table)) fail('Jenis dokumen tidak dikenal'); return decide(a.p_table, a.p_id, Number(a.p_level), a.p_approve, a.p_note); },
    decide_report: (a) => { need('pm'); const r = find('daily_reports', a.p_report); if (!r || !isMember(r.project_id)) fail('Laporan tidak ditemukan'); if (r.status !== 'submitted') fail('Laporan sudah diputuskan'); r.status = a.p_approve ? 'approved' : 'rejected'; if (!a.p_approve && a.p_note) r.notes = `${r.notes || ''}\n[PM] ${a.p_note}`; return r.status; },
    generate_payroll: (a) => {
      need('pm', 'admin_proyek'); const D = db(); if (!isMember(a.p_project)) fail('Tidak diizinkan'); const pct = setting('advance_max_pct', 50);
      let run = D.payroll_runs.find((r) => r.project_id === a.p_project && r.week_start === a.p_week_start);
      if (run) { if (run.status === 'approved') fail('Rekap pekan ini sudah disetujui'); D.payroll_lines = D.payroll_lines.filter((l) => l.run_id !== run.id); Object.assign(run, { status: 'submitted', decided_by: null }); }
      else { run = { id: uuid(), project_id: a.p_project, week_start: a.p_week_start, status: 'submitted', total_gross: 0, total_deduct: 0, total_net: 0, created_by: uid() }; D.payroll_runs.push(run); }
      const end = iso(addDays(new Date(a.p_week_start + 'T00:00:00Z'), 6)); let tg = 0, td = 0;
      D.workers.filter((w) => w.project_id === a.p_project && w.is_active).forEach((w) => {
        const hok = D.attendance.filter((x) => x.worker_id === w.id && x.work_date >= a.p_week_start && x.work_date <= end).reduce((s, x) => s + Number(x.hok), 0); if (!hok) return;
        const gross = hok * w.daily_wage, owed = D.worker_advances.filter((x) => x.worker_id === w.id && !x.settled).reduce((s, x) => s + Number(x.amount) - Number(x.repaid), 0), ded = Math.min(owed, Math.floor((gross * pct) / 100));
        D.payroll_lines.push({ run_id: run.id, worker_id: w.id, hok_total: hok, daily_wage: w.daily_wage, gross, advance_deduct: ded, net: gross - ded }); tg += gross; td += ded; });
      Object.assign(run, { total_gross: tg, total_deduct: td, total_net: tg - td }); return run.id;
    },
    decide_payroll: (a) => {
      need('pm'); const D = db(); const r = find('payroll_runs', a.p_run); if (!r || !isMember(r.project_id)) fail('Rekap tidak ditemukan'); if (r.status === 'approved') fail('Sudah disetujui');
      if (!a.p_approve) { r.status = 'rejected'; return 'rejected'; }
      D.payroll_lines.filter((l) => l.run_id === r.id && l.advance_deduct > 0).forEach((l) => { let left = l.advance_deduct;
        D.worker_advances.filter((x) => x.worker_id === l.worker_id && !x.settled).sort((x, y) => (x.given_on < y.given_on ? -1 : 1)).forEach((x) => { if (left <= 0) return; const take = Math.min(left, x.amount - x.repaid); x.repaid += take; x.settled = x.repaid >= x.amount; left -= take; }); });
      r.status = 'approved'; return 'approved';
    },
    issue_client_invoice: (a) => {
      need('finance'); const D = db(); const t = find('client_terms', a.p_term); if (!t || !isMember(t.project_id)) fail('Termin tidak ditemukan'); if (t.status !== 'planned') fail('Termin sudah ditagihkan');
      const p = find('projects', t.project_id); const ppn = Math.round((t.amount * setting('ppn_pct', 11)) / 100), pph = Math.round((t.amount * setting('pph_final_pct', 2.65)) / 100), ret = Math.round((t.amount * (p.retention_pct ?? 5)) / 100);
      const id = uuid(); D.client_invoices.push({ id, project_id: t.project_id, term_id: t.id, invoice_no: num('client_invoices', 'INV'), invoice_date: iso(new Date()), dpp: t.amount, ppn_amount: ppn, pph_amount: pph, retention_amount: ret, net_receivable: t.amount + ppn - pph - ret, status: 'issued', paid_at: null, created_by: uid() }); t.status = 'invoiced'; return id;
    },
    mark_client_invoice_paid: (a) => { need('finance'); const i = find('client_invoices', a.p_invoice); if (!i || !isMember(i.project_id)) fail('Invoice tidak ditemukan'); if (i.status === 'paid') fail('Sudah lunas'); i.status = 'paid'; i.paid_at = nowISO(); find('client_terms', i.term_id).status = 'paid'; },
    approve_invoice_payment: (a) => { need('owner'); const i = find('supplier_invoices', a.p_invoice); if (!i) fail('Tagihan tidak ditemukan'); i.owner_approved = true; },
    pay_invoice: (a) => {
      need('finance'); const i = find('supplier_invoices', a.p_invoice); if (!i) fail('Tagihan tidak ditemukan'); if (i.status === 'paid') fail('Tagihan sudah dibayar');
      if (i.amount >= setting('pay_owner_min', 25e6) && !i.owner_approved) fail('Pembayaran sebesar ini harus disetujui owner lebih dulu');
      const m = received(i.po_id); if (m.invoiced > m.received_value * (1 + setting('po_vat_pct', 0) / 100) + 1) fail('Total tagihan melebihi nilai barang yang sudah diterima. Cocokkan surat jalan dulu.');
      i.status = 'paid'; i.paid_at = nowISO();
    },
    finance_summary: (a) => { const D = db(); const inv = D.client_invoices.filter((i) => i.project_id === a.p_project); const sum = (xs, f) => xs.reduce((s, x) => s + Number(f(x)), 0);
      return { receivable: sum(inv.filter((i) => i.status === 'issued'), (i) => i.net_receivable), retention_held: sum(inv, (i) => i.retention_amount), ppn_out: sum(inv, (i) => i.ppn_amount), pph_final: sum(inv, (i) => i.pph_amount),
        payable: sum(D.supplier_invoices.filter((s) => s.status === 'unpaid' && find('purchase_orders', s.po_id)?.project_id === a.p_project), (s) => s.amount), terms_planned: sum(D.client_terms.filter((t) => t.project_id === a.p_project && t.status === 'planned'), (t) => t.amount) }; },
    complete_handover: (a) => {
      need('pm'); const D = db(); if (!isMember(a.p_project)) fail('Hanya PM proyek ini'); if (D.handovers.some((h) => h.project_id === a.p_project)) fail('Proyek sudah diserahterimakan');
      const open = D.punch_items.filter((p) => p.project_id === a.p_project && p.status !== 'verified').length; if (open > 0) fail(`Masih ada ${open} punch list yang belum diverifikasi`);
      const date = a.p_date || iso(new Date()); const due = new Date(date + 'T00:00:00Z'); due.setUTCMonth(due.getUTCMonth() + setting('maintenance_months', 6));
      D.handovers.push({ project_id: a.p_project, handover_date: date, completed_by: uid() });
      D.retention_claims.push({ id: uuid(), project_id: a.p_project, amount: D.client_invoices.filter((i) => i.project_id === a.p_project).reduce((s, i) => s + Number(i.retention_amount), 0), due_date: iso(due), status: 'held', released_at: null });
      find('projects', a.p_project).status = 'retention'; return iso(due);
    },
    release_retention: (a) => { need('finance'); const c = db().retention_claims.find((x) => x.project_id === a.p_project); if (!c) fail('Belum ada retensi (serah terima belum selesai)'); if (c.status === 'released') fail('Retensi sudah dicairkan'); if (iso(new Date()) < c.due_date) fail(`Belum jatuh tempo (${c.due_date})`); c.status = 'released'; c.released_at = nowISO(); find('projects', a.p_project).status = 'closed'; },
    verify_punch: (a) => { need('pm'); const p = find('punch_items', a.p_id); if (!p || !isMember(p.project_id)) fail('Punch list tidak ditemukan'); if (p.status !== 'fixed') fail('Item belum ditandai selesai'); if (a.p_ok) { p.status = 'verified'; p.verified_at = nowISO(); p.verify_note = a.p_note || null; } else { p.status = 'open'; p.verify_note = a.p_note || null; } },
    approve_equipment: (a) => { need('owner'); const e = find('equipment', a.p_id); if (!e) fail('Alat tidak ditemukan'); if (e.status !== 'pending') fail('Sudah diputuskan'); e.status = a.p_ok ? 'approved' : 'rejected'; },
    set_spk_progress: (a) => { need('pm'); const s = find('spk', a.p_spk); if (!s || !isMember(s.project_id)) fail('SPK tidak ditemukan'); if (s.status !== 'approved') fail('SPK belum disetujui'); const cur = Math.max(0, ...db().spk_progress.filter((p) => p.spk_id === s.id).map((p) => Number(p.pct)));
      if (!(a.p_pct >= cur)) fail(`Progres tidak boleh turun (saat ini ${cur})`); if (a.p_pct > 100) fail('Progres maksimal 100'); db().spk_progress.push({ id: uuid(), spk_id: s.id, pct: a.p_pct, note: a.p_note || null, created_by: uid() }); },
    pay_spk: (a) => { need('finance'); const s = find('spk', a.p_spk); if (!s || !isMember(s.project_id)) fail('SPK tidak ditemukan'); if (s.status !== 'approved') fail('SPK belum disetujui');
      const v = views.spk_summary().find((x) => x.id === s.id); const allowed = Math.round((s.contract_value * v.progress_pct) / 100 - v.paid);
      if (!(a.p_amount > 0) || a.p_amount > allowed) fail(`Pembayaran melebihi progres yang disetujui. Maksimal saat ini Rp ${rp(Math.max(allowed, 0))}`); db().spk_payments.push({ id: uuid(), spk_id: s.id, amount: a.p_amount, paid_by: uid(), paid_at: nowISO() }); },
    create_project: (a) => { need('pm', 'owner'); const D = db(); if (![a.p_code, a.p_name, a.p_client].every((x) => String(x || '').trim())) fail('Kode, nama, dan klien wajib diisi'); if (!(a.p_contract >= 0)) fail('Nilai kontrak tidak valid');
      if (a.p_start && a.p_end && a.p_end < a.p_start) fail('Tanggal selesai sebelum tanggal mulai'); if (D.projects.some((p) => p.code === a.p_code.trim())) fail(`Kode proyek ${a.p_code} sudah dipakai`);
      const id = uuid(); D.projects.push({ id, code: a.p_code.trim(), name: a.p_name.trim(), client_name: a.p_client.trim(), contract_value: a.p_contract, contract_original: null, retention_pct: 5, status: 'active', start_date: a.p_start, end_date: a.p_end }); D.project_members.push({ project_id: id, user_id: uid() }); return id; },
    set_project_member: (a) => { need('pm', 'owner'); const D = db(); if (!isMember(a.p_project)) fail('Tidak diizinkan'); if (a.p_on) { if (!D.project_members.some((m) => m.project_id === a.p_project && m.user_id === a.p_user)) D.project_members.push({ project_id: a.p_project, user_id: a.p_user }); } else D.project_members = D.project_members.filter((m) => !(m.project_id === a.p_project && m.user_id === a.p_user)); },
    import_rab: (a) => { need('estimator', 'pm'); const D = db(); if (!isMember(a.p_project)) fail('Tidak diizinkan'); const rows = a.p_rows; if (!Array.isArray(rows) || !rows.length) fail('Tidak ada baris untuk diimpor'); if (rows.length > 2000) fail('Maksimal 2000 baris per impor');
      if (rows.some((r) => !String(r.code || '').trim() || !String(r.description || '').trim() || !(Number(r.volume) >= 0) || !(Number(r.unit_price) >= 0))) fail('Ada baris tidak valid (kode, uraian, volume, atau harga kosong atau negatif)');
      const seen = new Set(); rows.forEach((r) => { const c = r.code.trim(); if (seen.has(c)) fail(`Kode ganda dalam file: ${c}`); seen.add(c); });
      rows.forEach((r) => { const c = r.code.trim(); let it = D.rab_items.find((x) => x.project_id === a.p_project && x.code === c); if (!it) { it = { id: uuid(), project_id: a.p_project, code: c }; D.rab_items.push(it); }
        Object.assign(it, { description: r.description.trim(), unit: String(r.unit || '').trim() || 'ls', volume: Number(r.volume), unit_price: Number(r.unit_price) }); it.total = it.volume * it.unit_price; }); return rows.length; },
    create_drawing: (a) => { need('pm', 'estimator'); const D = db(); if (!isMember(a.p_project)) fail('Tidak diizinkan'); if (!String(a.p_code || '').trim() || !String(a.p_title || '').trim()) fail('Kode dan judul wajib diisi');
      if (D.drawings.some((d) => d.project_id === a.p_project && d.code === a.p_code.trim())) fail(`Kode gambar ${a.p_code} sudah ada`); const id = uuid(); D.drawings.push({ id, project_id: a.p_project, code: a.p_code.trim(), title: a.p_title.trim(), category: a.p_category || 'shop', created_by: uid(), created_at: nowISO() }); return id; },
    register_drawing_version: (a) => { need('pm', 'estimator'); const D = db(); const d = find('drawings', a.p_drawing); if (!d || !isMember(d.project_id)) fail('Tidak diizinkan'); if (a.p_path.split('/')[0] !== d.project_id) fail('Lokasi file tidak sesuai proyek');
      const v = Math.max(0, ...D.drawing_versions.filter((x) => x.drawing_id === d.id).map((x) => x.version)) + 1; D.drawing_versions.forEach((x) => { if (x.drawing_id === d.id) x.is_current = false; });
      D.drawing_versions.push({ id: uuid(), drawing_id: d.id, version: v, storage_path: a.p_path, mime_type: a.p_mime, size_bytes: a.p_size, note: a.p_note || null, is_current: true, created_by: uid(), created_at: nowISO() }); return v; },
    dashboard_summary: (a) => {
      const D = db(); const p = find('projects', a.p_project); const T = iso(new Date()); const sched = D.project_schedule.filter((s) => s.project_id === a.p_project).sort((x, y) => (x.week_start < y.week_start ? -1 : 1));
      const approved = D.daily_reports.filter((r) => r.project_id === a.p_project && r.status === 'approved'); const mm = poMatch().filter((m) => m.project_id === a.p_project && ['approved', 'partial', 'received'].includes(m.status)); const s = (k) => mm.reduce((t, m) => t + Number(m[k]), 0);
      return { contract_value: p.contract_value, actual_pct: Math.max(0, ...approved.map((r) => Number(r.physical_pct))), planned_pct: [...sched].reverse().find((x) => x.week_start <= T)?.planned_cum_pct ?? 0,
        cash_balance: views.petty_cash_balance().find((b) => b.project_id === a.p_project)?.balance ?? 0, po: { ordered: s('ordered'), received: s('received_value'), invoiced: s('invoiced'), paid: s('paid') },
        pending: D.approvals.filter((x) => x.project_id === a.p_project && x.status === 'submitted').length + D.payroll_runs.filter((r) => r.project_id === a.p_project && r.status === 'submitted').length + D.daily_reports.filter((r) => r.project_id === a.p_project && r.status === 'submitted').length,
        curve: sched.map((w) => ({ w: w.week_start, plan: w.planned_cum_pct, act: w.week_start <= T ? Math.max(0, ...approved.filter((r) => r.report_date <= iso(addDays(new Date(w.week_start + 'T00:00:00Z'), 6))).map((r) => Number(r.physical_pct))) : null })) };
    },
    yearly_summary: (a) => {
      const D = db(); const y = String(a.p_year); const usage = usageRows();
      const projects = views.projects().map((p) => {
        const revenue = D.client_invoices.filter((i) => i.project_id === p.id && i.invoice_date.startsWith(y)).reduce((s, i) => s + Number(i.dpp), 0);
        const cost = D.supplier_invoices.filter((i) => i.status === 'paid' && i.paid_at?.startsWith(y) && find('purchase_orders', i.po_id)?.project_id === p.id).reduce((s, i) => s + Number(i.amount), 0)
          + D.payroll_runs.filter((r) => r.project_id === p.id && r.status === 'approved' && r.week_start.startsWith(y)).reduce((s, r) => s + Number(r.total_net), 0)
          + D.spk_payments.filter((x) => x.paid_at.startsWith(y) && find('spk', x.spk_id)?.project_id === p.id).reduce((s, x) => s + Number(x.amount), 0)
          + D.petty_cash.filter((r) => r.project_id === p.id && r.status === 'approved' && r.direction === 'out' && r.tx_date.startsWith(y)).reduce((s, r) => s + Number(r.amount), 0)
          + usage.filter((u) => u.project_id === p.id && u.month.startsWith(y)).reduce((s, u) => s + u.rental_cost + u.fuel_cost, 0);
        return { id: p.id, name: p.name, status: p.status, contract: p.contract_value, revenue, cost };
      }).filter((p) => p.revenue > 0 || p.cost > 0).sort((x, y2) => (x.name < y2.name ? -1 : 1));
      return { year: a.p_year, projects };
    },
  };
  return { views, rpc, beforeInsert, afterInsert, beforeUpdate, afterUpdate: undefined };
}
