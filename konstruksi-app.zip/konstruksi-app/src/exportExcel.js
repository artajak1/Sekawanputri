// exportExcel.js — ekspor laporan ke .xlsx (rapi, berformat) atau .csv. ExcelJS dimuat HANYA saat tombol ditekan,
// jadi tidak membebani HP entry-level maupun kuota saat aplikasi dibuka.
import { supabase } from './auth.jsx';
import { saveFile } from './download.js';
import { loadExcelJS } from './excel-loader.js';

const PAGE = 1000; // batas baris per permintaan Supabase

async function fetchAll(make) {
  const out = [];
  for (let from = 0; ; from += PAGE) {
    const { data, error } = await make().range(from, from + PAGE - 1);
    if (error) throw error;
    out.push(...data);
    if (data.length < PAGE) break;
  }
  return out;
}
const d = (s) => (s ? new Date(`${s}T00:00:00`) : null);
const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');

async function projectName(projectId) {
  const { data } = await supabase.from('projects').select('name').eq('id', projectId).single();
  return data?.name || 'proyek';
}

// ---------- Definisi laporan: kolom + pengambil data ----------
export const REPORTS = {
  daily: {
    label: 'Laporan harian', needs: 'range', roles: ['pm', 'owner', 'finance'],
    columns: [
      { header: 'Tanggal', key: 'date', width: 13, type: 'date' }, { header: 'Cuaca', key: 'weather', width: 14 },
      { header: 'Progres fisik (%)', key: 'pct', width: 16, type: 'pct' }, { header: 'Status', key: 'status', width: 12 },
      { header: 'Pelapor', key: 'by', width: 20 }, { header: 'Catatan', key: 'notes', width: 60, wrap: true }],
    async rows({ projectId, from, to }) {
      const rows = await fetchAll(() => supabase.from('daily_reports')
        .select('report_date, weather, physical_pct, status, notes, profiles!daily_reports_created_by_fkey(full_name)')
        .eq('project_id', projectId).gte('report_date', from).lte('report_date', to).order('report_date'));
      const ST = { draft: 'Draf', submitted: 'Diajukan', approved: 'Disetujui', rejected: 'Ditolak' };
      return rows.map((r) => ({ date: d(r.report_date), weather: r.weather, pct: Number(r.physical_pct), status: ST[r.status], by: r.profiles?.full_name, notes: r.notes }));
    },
  },
  payroll: {
    label: 'Rekap gaji mingguan', needs: 'week', roles: ['pm', 'finance', 'owner', 'admin_proyek'],
    columns: [
      { header: 'Tukang', key: 'name', width: 24 }, { header: 'HOK', key: 'hok', width: 8, type: 'num', sum: true },
      { header: 'Upah harian', key: 'wage', width: 15, type: 'rp' }, { header: 'Upah kotor', key: 'gross', width: 16, type: 'rp', sum: true },
      { header: 'Potongan kasbon', key: 'ded', width: 17, type: 'rp', sum: true }, { header: 'Upah bersih', key: 'net', width: 16, type: 'rp', sum: true }],
    async rows({ projectId, weekStart }) {
      const { data: run, error } = await supabase.from('payroll_runs').select('id, status').eq('project_id', projectId).eq('week_start', weekStart).maybeSingle();
      if (error) throw error;
      if (!run) throw new Error('Rekap upah pekan ini belum dihitung.');
      const rows = await fetchAll(() => supabase.from('payroll_lines').select('hok_total, daily_wage, gross, advance_deduct, net, workers(name)').eq('run_id', run.id));
      return rows.map((r) => ({ name: r.workers.name, hok: Number(r.hok_total), wage: Number(r.daily_wage), gross: Number(r.gross), ded: Number(r.advance_deduct), net: Number(r.net) }))
        .sort((a, b) => a.name.localeCompare(b.name, 'id'));
    },
  },
  petty: {
    label: 'Kas kecil', needs: 'range', roles: ['admin_proyek', 'pm', 'finance', 'owner'],
    columns: [
      { header: 'Tanggal', key: 'date', width: 13, type: 'date' }, { header: 'Keterangan', key: 'desc', width: 44, wrap: true },
      { header: 'Status', key: 'status', width: 12 }, { header: 'Masuk', key: 'in', width: 16, type: 'rp', sum: true },
      { header: 'Keluar', key: 'out', width: 16, type: 'rp', sum: true }, { header: 'Saldo (disetujui)', key: 'bal', width: 18, type: 'rp' }],
    async rows({ projectId, from, to }) {
      const rows = await fetchAll(() => supabase.from('petty_cash').select('tx_date, direction, amount, description, status')
        .eq('project_id', projectId).gte('tx_date', from).lte('tx_date', to).order('tx_date').order('created_at'));
      const ST = { submitted: 'Menunggu', approved: 'Disetujui', rejected: 'Ditolak', draft: 'Draf' };
      let bal = 0;
      return rows.map((r) => {
        const a = Number(r.amount); if (r.status === 'approved') bal += r.direction === 'in' ? a : -a;
        return { date: d(r.tx_date), desc: r.description, status: ST[r.status], in: r.direction === 'in' ? a : null, out: r.direction === 'out' ? a : null, bal };
      });
    },
    note: () => 'Saldo hanya menghitung transaksi berstatus Disetujui.',
  },
  rab: {
    label: 'RAB', needs: 'none', roles: ['estimator', 'pm', 'owner', 'finance'],
    columns: [
      { header: 'Kode', key: 'code', width: 12 }, { header: 'Uraian pekerjaan', key: 'desc', width: 50, wrap: true },
      { header: 'Satuan', key: 'unit', width: 10 }, { header: 'Volume', key: 'vol', width: 12, type: 'num' },
      { header: 'Harga satuan', key: 'price', width: 16, type: 'rp' }, { header: 'Jumlah', key: 'total', width: 18, type: 'rp', sum: true, formula: (r) => `D${r}*E${r}` }],
    async rows({ projectId }) {
      const rows = await fetchAll(() => supabase.from('rab_items').select('code, description, unit, volume, unit_price').eq('project_id', projectId).order('code'));
      return rows.map((r) => ({ code: r.code, desc: r.description, unit: r.unit, vol: Number(r.volume), price: Number(r.unit_price), total: Number(r.volume) * Number(r.unit_price) }));
    },
  },
};

const FMT = { rp: '#,##0', num: '#,##0.0#', pct: '0.0', date: 'dd/mm/yyyy' };

// ---------- Excel ----------
async function toXlsx(def, rows, meta) {
  const ExcelJS = await loadExcelJS();                            // dimuat saat dibutuhkan
  const wb = new ExcelJS.Workbook(); wb.creator = 'Sistem Manajemen Proyek';
  const ws = wb.addWorksheet(def.label.slice(0, 30), { views: [{ state: 'frozen', ySplit: 4 }], pageSetup: { orientation: 'landscape', fitToPage: true, fitToWidth: 1, fitToHeight: 0 } });
  const n = def.columns.length, border = { style: 'thin', color: { argb: 'FFE2E8F0' } };

  ws.mergeCells(1, 1, 1, n); ws.getCell(1, 1).value = `${def.label} · ${meta.project}`; ws.getCell(1, 1).font = { bold: true, size: 14, color: { argb: 'FF0F172A' } };
  ws.mergeCells(2, 1, 2, n); ws.getCell(2, 1).value = [meta.period, meta.note].filter(Boolean).join(' · '); ws.getCell(2, 1).font = { size: 10, color: { argb: 'FF64748B' } };

  const head = ws.getRow(4); head.height = 22;
  def.columns.forEach((c, i) => {
    const cell = head.getCell(i + 1); cell.value = c.header;
    cell.font = { bold: true, color: { argb: 'FFFFFFFF' } }; cell.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF0F172A' } };
    cell.alignment = { vertical: 'middle', horizontal: ['rp', 'num', 'pct'].includes(c.type) ? 'right' : 'left' };
    ws.getColumn(i + 1).width = c.width;
  });
  rows.forEach((r, ri) => {
    const row = ws.getRow(5 + ri);
    def.columns.forEach((c, i) => {
      const cell = row.getCell(i + 1);
      cell.value = c.formula ? { formula: c.formula(5 + ri), result: r[c.key] } : r[c.key] ?? null;
      if (FMT[c.type]) cell.numFmt = FMT[c.type];
      cell.alignment = { vertical: 'top', wrapText: !!c.wrap, horizontal: ['rp', 'num', 'pct'].includes(c.type) ? 'right' : 'left' };
      cell.border = { bottom: border };
    });
  });
  if (def.columns.some((c) => c.sum) && rows.length) {
    const tr = ws.getRow(5 + rows.length); const first = 5, last = 4 + rows.length;
    tr.getCell(1).value = 'Total';
    def.columns.forEach((c, i) => {
      if (!c.sum) return; const L = ws.getColumn(i + 1).letter, cell = tr.getCell(i + 1);
      cell.value = { formula: `SUM(${L}${first}:${L}${last})` }; cell.numFmt = FMT[c.type]; cell.alignment = { horizontal: 'right' };
    });
    tr.font = { bold: true }; for (let i = 1; i <= n; i++) tr.getCell(i).border = { top: { style: 'thin', color: { argb: 'FF0F172A' } } };
  }
  return new Blob([await wb.xlsx.writeBuffer()], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
}

// ---------- CSV (titik koma, UTF-8 BOM, aman dari formula injection) ----------
function toCsv(def, rows) {
  const safe = (v) => {
    if (v == null) return '';
    let s = v instanceof Date ? v.toISOString().slice(0, 10) : String(v);
    if (/^[=+\-@\t\r]/.test(s) && typeof v === 'string') s = `'${s}`;
    return `"${s.replace(/"/g, '""')}"`;
  };
  const lines = [def.columns.map((c) => safe(c.header)).join(';'), ...rows.map((r) => def.columns.map((c) => safe(r[c.key])).join(';'))];
  return new Blob(['\uFEFF' + lines.join('\r\n')], { type: 'text/csv;charset=utf-8' });
}

/** Ekspor satu laporan. params: { projectId, from, to, weekStart }. format: 'xlsx' | 'csv'. */
export async function exportReport(key, params, format = 'xlsx') {
  const def = REPORTS[key]; if (!def) throw new Error('Laporan tidak dikenal');
  const [rows, project] = await Promise.all([def.rows(params), projectName(params.projectId)]);
  if (!rows.length) throw new Error('Tidak ada data pada periode ini.');
  const period = key === 'payroll' ? `Pekan mulai ${params.weekStart}` : params.from ? `${params.from} s/d ${params.to}` : '';
  const stamp = new Date().toISOString().slice(0, 10);
  const name = `${slug(def.label)}-${slug(project)}-${stamp}.${format}`;
  const blob = format === 'csv' ? toCsv(def, rows) : await toXlsx(def, rows, { project, period, note: def.note?.(params) });
  const res = await saveFile(blob, name);
  return { rows: rows.length, name, declined: res.status === 'declined' };
}
