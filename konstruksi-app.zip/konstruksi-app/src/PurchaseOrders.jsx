// PurchaseOrders.jsx — daftar PO + approval, PO baru, terima barang (surat jalan). Tulis lewat antrean offline.
import React, { useCallback, useEffect, useState } from 'react';
import { supabase, useAuth, RoleGate } from './auth.jsx';
import { enqueue } from './offlineQueue.js';
import { compressImage } from './imageCompress.js';
import { Button, Card, Skeleton, ErrorBoundary } from './ui.jsx';

const rp = (n) => 'Rp ' + new Intl.NumberFormat('id-ID').format(n || 0);
const field = 'w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-slate-900 focus:ring-4 focus:ring-slate-900/10';
const ST = { submitted: ['Menunggu persetujuan', 'text-amber-700'], approved: ['Disetujui', 'text-green-700'],
  rejected: ['Ditolak', 'text-red-700'], partial: ['Diterima sebagian', 'text-sky-700'], received: ['Diterima lengkap', 'text-green-700'] };

function List({ projectId, refreshKey }) {
  const { profile } = useAuth();
  const [rows, setRows] = useState(null);
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    try {
      const [a, m, ap] = await Promise.all([
        supabase.from('purchase_orders').select('id, po_number, po_date, status, total, suppliers(name)')
          .eq('project_id', projectId).order('created_at', { ascending: false }).limit(20),
        supabase.from('po_match').select('po_id, received_value, invoiced, paid').eq('project_id', projectId),
        supabase.from('approvals').select('ref_id, level, status').eq('project_id', projectId).eq('ref_table', 'purchase_orders'),
      ]);
      if (a.error) throw a.error;
      const mm = Object.fromEntries((m.data || []).map((x) => [x.po_id, x]));
      const aa = {}; (ap.data || []).forEach((x) => { (aa[x.ref_id] ||= {})[x.level] = x.status; });
      setRows(a.data.map((r) => ({ ...r, match: mm[r.id], appr: aa[r.id] || {} }))); setErr('');
    } catch (e) { console.error('[po]', e); setErr('Tidak bisa memuat PO. Periksa sinyal.'); }
  }, [projectId]);
  useEffect(() => { load(); }, [load, refreshKey]);

  async function decide(id, level, approve) {
    const { error } = await supabase.rpc('decide_po', { p_po: id, p_level: level, p_approve: approve });
    if (error) { console.error('[decide_po]', error); setErr(error.message); } else load();
  }

  if (!rows) return <Card><Skeleton className="h-4 w-28" /><Skeleton className="mt-3 h-12 w-full" /></Card>;
  return (
    <div className="space-y-3">
      {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
      {rows.length === 0 && <Card><p className="text-sm text-slate-500">Belum ada PO.</p></Card>}
      {rows.map((r) => {
        const myLevel = profile.role === 'pm' ? 1 : profile.role === 'owner' ? 2 : 0;
        const canDecide = r.status === 'submitted' && myLevel && r.appr[myLevel] === 'submitted' && (myLevel === 1 || r.appr[1] === 'approved');
        const over = r.match && r.match.invoiced > r.match.received_value + 1;
        return (
          <Card key={r.id} interactive>
            <div className="flex items-start justify-between gap-3">
              <div className="min-w-0"><p className="font-semibold text-slate-900">{r.po_number}</p>
                <p className="truncate text-sm text-slate-500">{r.suppliers?.name}</p></div>
              <p className="whitespace-nowrap font-semibold">{rp(r.total)}</p>
            </div>
            <p className={`mt-1 text-xs ${ST[r.status][1]}`}>{ST[r.status][0]}</p>
            {['approved', 'partial', 'received'].includes(r.status) && r.match && (
              <p className="mt-2 text-xs text-slate-500">Diterima {rp(r.match.received_value)} · Ditagih {rp(r.match.invoiced)} · Dibayar {rp(r.match.paid)}
                {over && <span className="ml-1 font-medium text-red-700">Tagihan melebihi barang diterima</span>}</p>)}
            {canDecide && (
              <div className="mt-3 flex gap-2">
                <Button size="sm" onClick={() => decide(r.id, myLevel, true)}>Setujui</Button>
                <Button size="sm" variant="danger" onClick={() => decide(r.id, myLevel, false)}>Tolak</Button>
              </div>)}
          </Card>);
      })}
    </div>
  );
}

function NewPO({ projectId, onDone }) {
  const { user } = useAuth();
  const [suppliers, setSuppliers] = useState(null);
  const [sid, setSid] = useState('');
  const [items, setItems] = useState([{ description: '', unit: 'sak', qty: '', unit_price: '' }]);
  const [msg, setMsg] = useState({ t: '', ok: false });
  const [busy, setBusy] = useState(false);

  useEffect(() => { supabase.from('suppliers').select('id, name').eq('is_active', true).order('name')
    .then(({ data }) => { setSuppliers(data || []); if (data?.[0]) setSid(data[0].id); }); }, []);

  const upd = (i, k) => (e) => setItems(items.map((x, j) => (j === i ? { ...x, [k]: e.target.value } : x)));
  const total = items.reduce((s, x) => s + (Number(x.qty) || 0) * (Number(x.unit_price) || 0), 0);

  async function submit(e) {
    e.preventDefault();
    const clean = items.filter((x) => x.description.trim() || x.qty).map((x) => ({
      description: x.description.trim(), unit: x.unit.trim() || 'unit', qty: Number(x.qty), unit_price: Number(x.unit_price) || 0 }));
    if (!sid) return setMsg({ t: 'Pilih supplier.', ok: false });
    if (!clean.length || clean.some((x) => !x.description || !(x.qty > 0))) return setMsg({ t: 'Lengkapi nama dan jumlah setiap item.', ok: false });
    setBusy(true);
    try {
      await enqueue({ table: 'purchase_orders', projectId, row: {
        project_id: projectId, supplier_id: sid, items: clean, created_by: user.id } });
      setMsg({ t: 'PO diajukan. Terkirim otomatis saat ada sinyal.', ok: true });
      setItems([{ description: '', unit: 'sak', qty: '', unit_price: '' }]); onDone?.();
    } catch (err) { console.error('[po baru]', err); setMsg({ t: 'Gagal menyimpan di perangkat.', ok: false }); }
    finally { setBusy(false); }
  }

  if (!suppliers) return <Card><Skeleton className="h-10 w-full" /></Card>;
  return (
    <Card as="form" onSubmit={submit} className="space-y-3">
      <select className={field} value={sid} onChange={(e) => setSid(e.target.value)}>
        {suppliers.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
      {items.map((x, i) => (
        <div key={i} className="space-y-2 rounded-lg border border-slate-100 p-3">
          <input className={field} placeholder="Nama material" value={x.description} onChange={upd(i, 'description')} />
          <div className="grid grid-cols-3 gap-2">
            <input className={field} inputMode="decimal" placeholder="Jumlah" value={x.qty} onChange={upd(i, 'qty')} />
            <input className={field} placeholder="Satuan" value={x.unit} onChange={upd(i, 'unit')} />
            <input className={field} inputMode="numeric" placeholder="Harga satuan" value={x.unit_price} onChange={upd(i, 'unit_price')} />
          </div>
          {items.length > 1 && <button type="button" className="text-xs text-slate-500" onClick={() => setItems(items.filter((_, j) => j !== i))}>Hapus item</button>}
        </div>))}
      <Button type="button" variant="secondary" size="sm" onClick={() => setItems([...items, { description: '', unit: 'sak', qty: '', unit_price: '' }])}>Tambah item</Button>
      <div className="flex justify-between border-t border-slate-100 pt-3 text-sm"><span>Total</span><strong>{rp(total)}</strong></div>
      {msg.t && <p role="alert" className={`text-sm ${msg.ok ? 'text-green-700' : 'text-red-700'}`}>{msg.t}</p>}
      <Button size="lg" className="w-full" loading={busy}>Ajukan PO</Button>
    </Card>
  );
}

function Receive({ projectId, onDone }) {
  const { user } = useAuth();
  const [pos, setPos] = useState(null);
  const [po, setPo] = useState('');
  const [lines, setLines] = useState([]);
  const [qty, setQty] = useState({});
  const [sj, setSj] = useState('');
  const [photo, setPhoto] = useState(null);
  const [msg, setMsg] = useState({ t: '', ok: false });
  const [busy, setBusy] = useState(false);

  useEffect(() => { supabase.from('purchase_orders').select('id, po_number, suppliers(name)').eq('project_id', projectId)
    .in('status', ['approved', 'partial']).then(({ data }) => { setPos(data || []); if (data?.[0]) setPo(data[0].id); }); }, [projectId]);
  useEffect(() => { if (!po) return setLines([]);
    supabase.from('po_items').select('id, description, unit, qty').eq('po_id', po).order('line_no')
      .then(({ data }) => { setLines(data || []); setQty({}); }); }, [po]);

  async function pick(e) {
    const f = e.target.files[0]; setPhoto(null); if (!f) return;
    try { const c = await compressImage(f); setPhoto(new File([c.blob], `sj.${c.ext}`, { type: c.mime })); }
    catch (err) { console.error('[sj foto]', err); setMsg({ t: 'Foto tidak bisa diproses.', ok: false }); }
  }
  async function submit(e) {
    e.preventDefault();
    const items = lines.map((l) => ({ po_item_id: l.id, qty: Number(qty[l.id]) || 0 })).filter((x) => x.qty > 0);
    if (!sj.trim()) return setMsg({ t: 'Isi nomor surat jalan.', ok: false });
    if (!items.length) return setMsg({ t: 'Isi jumlah barang yang diterima.', ok: false });
    if (!photo) return setMsg({ t: 'Foto surat jalan wajib dilampirkan.', ok: false });
    setBusy(true);
    try {
      await enqueue({ table: 'delivery_notes', projectId, photo, row: { po_id: po, sj_number: sj.trim(), items, created_by: user.id } });
      setMsg({ t: 'Penerimaan tersimpan. Terkirim otomatis saat ada sinyal.', ok: true });
      setSj(''); setQty({}); setPhoto(null); e.target.reset(); onDone?.();
    } catch (err) { console.error('[terima]', err); setMsg({ t: 'Gagal menyimpan di perangkat.', ok: false }); }
    finally { setBusy(false); }
  }

  if (!pos) return <Card><Skeleton className="h-10 w-full" /></Card>;
  if (!pos.length) return <Card><p className="text-sm text-slate-700">Tidak ada PO yang menunggu penerimaan barang.</p></Card>;
  return (
    <Card as="form" onSubmit={submit} className="space-y-3">
      <select className={field} value={po} onChange={(e) => setPo(e.target.value)}>
        {pos.map((p) => <option key={p.id} value={p.id}>{p.po_number} · {p.suppliers?.name}</option>)}</select>
      <input className={field} placeholder="Nomor surat jalan" value={sj} onChange={(e) => setSj(e.target.value)} />
      {lines.map((l) => (
        <div key={l.id} className="flex items-center justify-between gap-3">
          <p className="min-w-0 truncate text-sm">{l.description} <span className="text-slate-400">(pesan {l.qty} {l.unit})</span></p>
          <input className={`${field} !w-24`} inputMode="decimal" placeholder="Diterima" value={qty[l.id] || ''} onChange={(e) => setQty({ ...qty, [l.id]: e.target.value })} />
        </div>))}
      <input className="text-sm" type="file" accept="image/*" capture="environment" onChange={pick} />
      {msg.t && <p role="alert" className={`text-sm ${msg.ok ? 'text-green-700' : 'text-red-700'}`}>{msg.t}</p>}
      <Button size="lg" className="w-full" loading={busy}>Simpan penerimaan</Button>
    </Card>
  );
}

export default function PurchaseOrders({ projectId }) {
  const { profile } = useAuth();
  const [tab, setTab] = useState('list');
  const [key, setKey] = useState(0);
  const bump = () => setKey((k) => k + 1);
  const tabs = [['list', 'Daftar'], ['new', 'PO baru', ['admin_proyek', 'pm']], ['recv', 'Terima barang', ['admin_proyek', 'pm']]]
    .filter((t) => !t[2] || t[2].includes(profile.role));
  return (
    <ErrorBoundary name="purchase-order">
      <div className="mx-auto max-w-md space-y-3 p-4">
        <div className="flex gap-2 overflow-x-auto">
          {tabs.map(([k, l]) => <Button key={k} size="sm" variant={tab === k ? 'primary' : 'secondary'} onClick={() => setTab(k)}>{l}</Button>)}
        </div>
        {tab === 'list' && <List projectId={projectId} refreshKey={key} />}
        {tab === 'new' && <NewPO projectId={projectId} onDone={bump} />}
        {tab === 'recv' && <Receive projectId={projectId} onDone={bump} />}
      </div>
    </ErrorBoundary>
  );
}
// Pakai: <RoleGate allow={['admin_proyek','pm','owner','finance']}><PurchaseOrders projectId={id}/></RoleGate>
