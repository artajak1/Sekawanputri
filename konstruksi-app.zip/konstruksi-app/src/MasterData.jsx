// MasterData.jsx — proyek + anggota, tukang + kasbon, supplier, jadwal kurva S, RAB (impor CSV).
import React, { useCallback, useEffect, useState } from 'react';
import { supabase, useAuth } from './auth.jsx';
import { enqueue } from './offlineQueue.js';
import { saveFile } from './download.js';
import { askConfirm } from './dialog.jsx';
import { Button, Card, Skeleton, ErrorBoundary } from './ui.jsx';

const rp = (n) => 'Rp ' + new Intl.NumberFormat('id-ID').format(Math.round(n || 0));
const field = 'w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-slate-900 focus:ring-4 focus:ring-slate-900/10';
const digits = (s) => Number(String(s).replace(/\D/g, ''));

function useMsg() { const [m, setM] = useState({ t: '', ok: false }); return [m, (t, ok = false) => setM({ t, ok })]; }
const Msg = ({ m }) => (m.t ? <p role="alert" className={`text-sm ${m.ok ? 'text-green-700' : 'text-red-700'}`}>{m.t}</p> : null);

// ---------------- Proyek + anggota ----------------
function ProyekTab({ projectId }) {
  const [m, say] = useMsg();
  const [f, setF] = useState({ code: '', name: '', client: '', contract: '', start: '', end: '' });
  const [members, setMembers] = useState(null);
  const [people, setPeople] = useState([]);
  const [pick, setPick] = useState('');
  const ROLE = { mandor: 'Mandor', admin_proyek: 'Admin proyek', pm: 'PM', estimator: 'Estimator', finance: 'Finance', owner: 'Owner' };

  const load = useCallback(async () => {
    if (!projectId) return setMembers([]);
    const [a, b] = await Promise.all([
      supabase.from('project_members').select('user_id, profiles(full_name, role)').eq('project_id', projectId),
      supabase.from('profiles').select('id, full_name, role').eq('is_active', true).order('full_name')]);
    if (a.error) { console.error('[anggota]', a.error); return say('Tidak bisa memuat anggota.'); }
    setMembers(a.data); setPeople(b.data || []);
  }, [projectId]); // eslint-disable-line
  useEffect(() => { load(); }, [load]);

  async function create(e) {
    e.preventDefault();
    const { error } = await supabase.rpc('create_project', { p_code: f.code, p_name: f.name, p_client: f.client, p_contract: digits(f.contract), p_start: f.start || null, p_end: f.end || null });
    if (error) { console.error('[create_project]', error); return say(error.message); }
    say('Proyek dibuat. Pilih di bagian atas layar untuk membukanya.', true); setF({ code: '', name: '', client: '', contract: '', start: '', end: '' });
    setTimeout(() => location.reload(), 1200);
  }
  async function setMember(id, on) {
    const { error } = await supabase.rpc('set_project_member', { p_project: projectId, p_user: id, p_on: on });
    if (error) { console.error('[member]', error); say(error.message); } else { say(''); load(); }
  }
  const ids = new Set((members || []).map((x) => x.user_id));
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <div className="space-y-3">
      <Msg m={m} />
      {projectId && (<Card>
        <p className="mb-2 text-sm font-medium text-slate-900">Anggota proyek terpilih</p>
        {!members ? <Skeleton className="h-10 w-full" /> : members.length === 0 ? <p className="text-sm text-slate-500">Belum ada anggota.</p>
          : <div className="divide-y divide-slate-100">{members.map((x) => (
            <div key={x.user_id} className="flex items-center justify-between py-2 text-sm"><span>{x.profiles?.full_name} <span className="text-xs text-slate-500">{ROLE[x.profiles?.role]}</span></span>
              <Button size="sm" variant="ghost" onClick={() => setMember(x.user_id, false)}>Keluarkan</Button></div>))}</div>}
        <div className="mt-3 flex gap-2"><select className={field} value={pick} onChange={(e) => setPick(e.target.value)}><option value="">Tambah anggota…</option>
          {people.filter((p) => !ids.has(p.id) && !['owner', 'finance'].includes(p.role)).map((p) => <option key={p.id} value={p.id}>{p.full_name} ({ROLE[p.role]})</option>)}</select>
          <Button variant="secondary" onClick={() => pick && setMember(pick, true).then?.(() => setPick(''))}>Tambah</Button></div>
        <p className="mt-2 text-xs text-slate-500">Owner dan Finance otomatis melihat semua proyek.</p>
      </Card>)}
      <Card as="form" onSubmit={create} className="space-y-2">
        <p className="text-sm font-medium text-slate-900">Proyek baru</p>
        <div className="grid grid-cols-2 gap-2"><input className={field} placeholder="Kode, mis. GSG-02" value={f.code} onChange={set('code')} />
          <input className={field} inputMode="numeric" placeholder="Nilai kontrak (Rp)" value={f.contract} onChange={set('contract')} /></div>
        <input className={field} placeholder="Nama proyek" value={f.name} onChange={set('name')} />
        <input className={field} placeholder="Nama klien" value={f.client} onChange={set('client')} />
        <div className="grid grid-cols-2 gap-2"><label className="text-xs text-slate-500">Mulai<input className={field} type="date" value={f.start} onChange={set('start')} /></label>
          <label className="text-xs text-slate-500">Selesai<input className={field} type="date" value={f.end} onChange={set('end')} /></label></div>
        <Button className="w-full">Buat proyek</Button>
      </Card>
    </div>
  );
}

// ---------------- Tukang + kasbon ----------------
function TukangTab({ projectId }) {
  const { user } = useAuth();
  const [m, say] = useMsg();
  const [rows, setRows] = useState(null);
  const [owed, setOwed] = useState({});
  const [f, setF] = useState({ name: '', skill: '', wage: '' });
  const [adv, setAdv] = useState({ worker: '', amount: '' });

  const load = useCallback(async () => {
    const [w, a] = await Promise.all([
      supabase.from('workers').select('id, name, skill, daily_wage, is_active').eq('project_id', projectId).order('name'),
      supabase.from('worker_advances').select('worker_id, amount, repaid').eq('settled', false)]);
    if (w.error) { console.error('[tukang]', w.error); return say('Tidak bisa memuat tukang.'); }
    setRows(w.data); const o = {}; (a.data || []).forEach((x) => { o[x.worker_id] = (o[x.worker_id] || 0) + Number(x.amount) - Number(x.repaid); }); setOwed(o);
    setAdv((x) => ({ ...x, worker: x.worker || w.data[0]?.id || '' }));
  }, [projectId]); // eslint-disable-line
  useEffect(() => { load(); }, [load]);

  async function add(e) {
    e.preventDefault();
    if (!f.name.trim() || !digits(f.wage)) return say('Isi nama dan upah harian.');
    const { error } = await supabase.from('workers').insert({ project_id: projectId, name: f.name.trim(), skill: f.skill.trim() || null, daily_wage: digits(f.wage) });
    if (error) { console.error('[tukang baru]', error); return say('Gagal menambah tukang.'); }
    setF({ name: '', skill: '', wage: '' }); say(''); load();
  }
  async function toggle(w) { const { error } = await supabase.from('workers').update({ is_active: !w.is_active }).eq('id', w.id); if (error) say('Gagal mengubah status.'); else load(); }
  async function kasbon(e) {
    e.preventDefault(); const amount = digits(adv.amount);
    if (!adv.worker || !amount) return say('Pilih tukang dan isi jumlah kasbon.');
    try { await enqueue({ table: 'worker_advances', projectId, row: { worker_id: adv.worker, amount, created_by: user.id } });
      setAdv({ ...adv, amount: '' }); say('Kasbon tersimpan. Terkirim otomatis saat ada sinyal.', true); setTimeout(load, 1500);
    } catch (err) { console.error('[kasbon]', err); say('Gagal menyimpan di perangkat.'); }
  }
  if (!rows) return <Card><Skeleton className="h-16 w-full" /></Card>;
  return (
    <div className="space-y-3">
      <Msg m={m} />
      <Card className="divide-y divide-slate-100 p-0">
        {rows.length === 0 && <p className="p-4 text-sm text-slate-500">Belum ada tukang.</p>}
        {rows.map((w) => (<div key={w.id} className={`flex items-center justify-between gap-3 p-4 ${w.is_active ? '' : 'opacity-50'}`}>
          <div className="min-w-0"><p className="truncate text-sm font-medium text-slate-900">{w.name}</p>
            <p className="text-xs text-slate-500">{w.skill || 'Tanpa keahlian'} · {rp(w.daily_wage)}/hari{owed[w.id] > 0 && ` · kasbon ${rp(owed[w.id])}`}</p></div>
          <Button size="sm" variant="ghost" onClick={() => toggle(w)}>{w.is_active ? 'Nonaktifkan' : 'Aktifkan'}</Button></div>))}
      </Card>
      <Card as="form" onSubmit={add} className="space-y-2"><p className="text-sm font-medium text-slate-900">Tukang baru</p>
        <input className={field} placeholder="Nama" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
        <div className="grid grid-cols-2 gap-2"><input className={field} placeholder="Keahlian" value={f.skill} onChange={(e) => setF({ ...f, skill: e.target.value })} />
          <input className={field} inputMode="numeric" placeholder="Upah harian (Rp)" value={f.wage} onChange={(e) => setF({ ...f, wage: e.target.value })} /></div>
        <Button className="w-full">Tambah tukang</Button></Card>
      {rows.length > 0 && (<Card as="form" onSubmit={kasbon} className="space-y-2"><p className="text-sm font-medium text-slate-900">Catat kasbon</p>
        <select className={field} value={adv.worker} onChange={(e) => setAdv({ ...adv, worker: e.target.value })}>{rows.filter((w) => w.is_active).map((w) => <option key={w.id} value={w.id}>{w.name}</option>)}</select>
        <input className={field} inputMode="numeric" placeholder="Jumlah kasbon (Rp)" value={adv.amount} onChange={(e) => setAdv({ ...adv, amount: e.target.value })} />
        <Button className="w-full">Simpan kasbon</Button><p className="text-xs text-slate-500">Dipotong otomatis dari upah mingguan (maks 50% per pekan).</p></Card>)}
    </div>
  );
}

// ---------------- Supplier ----------------
function SupplierTab() {
  const [m, say] = useMsg(); const [rows, setRows] = useState(null); const [f, setF] = useState({ name: '', phone: '' });
  const load = useCallback(async () => { const { data, error } = await supabase.from('suppliers').select('id, name, phone, is_active').order('name');
    if (error) { console.error('[supplier]', error); return say('Tidak bisa memuat supplier.'); } setRows(data); }, []); // eslint-disable-line
  useEffect(() => { load(); }, [load]);
  async function add(e) { e.preventDefault(); if (!f.name.trim()) return say('Isi nama supplier.');
    const { error } = await supabase.from('suppliers').insert({ name: f.name.trim(), phone: f.phone.trim() || null });
    if (error) { console.error('[supplier baru]', error); return say('Gagal menambah supplier.'); } setF({ name: '', phone: '' }); say(''); load(); }
  async function toggle(s) { const { error } = await supabase.from('suppliers').update({ is_active: !s.is_active }).eq('id', s.id); if (error) say('Gagal mengubah status.'); else load(); }
  if (!rows) return <Card><Skeleton className="h-16 w-full" /></Card>;
  return (<div className="space-y-3"><Msg m={m} />
    <Card className="divide-y divide-slate-100 p-0">{rows.length === 0 && <p className="p-4 text-sm text-slate-500">Belum ada supplier.</p>}
      {rows.map((s) => (<div key={s.id} className={`flex items-center justify-between gap-3 p-4 ${s.is_active ? '' : 'opacity-50'}`}><div className="min-w-0"><p className="truncate text-sm font-medium">{s.name}</p><p className="text-xs text-slate-500">{s.phone || 'Tanpa telepon'}</p></div>
        <Button size="sm" variant="ghost" onClick={() => toggle(s)}>{s.is_active ? 'Nonaktifkan' : 'Aktifkan'}</Button></div>))}</Card>
    <Card as="form" onSubmit={add} className="space-y-2"><p className="text-sm font-medium">Supplier baru</p>
      <input className={field} placeholder="Nama supplier" value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} />
      <input className={field} inputMode="tel" placeholder="Telepon (opsional)" value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} />
      <Button className="w-full">Tambah supplier</Button></Card></div>);
}

// ---------------- Jadwal rencana (kurva S) ----------------
const mondayISO = (d = new Date()) => { const x = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())); x.setUTCDate(x.getUTCDate() - ((x.getUTCDay() + 6) % 7)); return x.toISOString().slice(0, 10); };
function sCurve(n) { // kumulatif berbentuk S (smoothstep), 0 sampai 100
  return Array.from({ length: n }, (_, i) => { const t = (i + 1) / n; return Math.round((3 * t * t - 2 * t * t * t) * 1000) / 10; });
}
function JadwalTab({ projectId }) {
  const [m, say] = useMsg(); const [rows, setRows] = useState(null); const [start, setStart] = useState(mondayISO()); const [weeks, setWeeks] = useState('12'); const [draft, setDraft] = useState(null);
  const load = useCallback(async () => { const { data, error } = await supabase.from('project_schedule').select('week_start, planned_cum_pct').eq('project_id', projectId).order('week_start');
    if (error) { console.error('[jadwal]', error); return say('Tidak bisa memuat jadwal.'); } setRows(data); }, [projectId]); // eslint-disable-line
  useEffect(() => { load(); }, [load]);
  function gen() { const n = Number(weeks); if (!(n >= 2 && n <= 104)) return say('Jumlah pekan 2 sampai 104.');
    const base = new Date(start + 'T00:00:00Z'); const c = sCurve(n);
    setDraft(c.map((v, i) => { const d = new Date(base); d.setUTCDate(d.getUTCDate() + i * 7); return { week_start: d.toISOString().slice(0, 10), planned_cum_pct: v }; })); say(''); }
  async function save() {
    if (draft.some((r, i) => !(r.planned_cum_pct >= 0 && r.planned_cum_pct <= 100) || (i && r.planned_cum_pct < draft[i - 1].planned_cum_pct))) return say('Persentase harus 0 sampai 100 dan tidak boleh turun.');
    const { error } = await supabase.from('project_schedule').upsert(draft.map((r) => ({ project_id: projectId, ...r })), { onConflict: 'project_id,week_start' });
    if (error) { console.error('[jadwal simpan]', error); return say('Gagal menyimpan jadwal.'); } say(`${draft.length} pekan tersimpan.`, true); setDraft(null); load(); }
  if (!rows) return <Card><Skeleton className="h-16 w-full" /></Card>;
  return (<div className="space-y-3"><Msg m={m} />
    <Card className="space-y-2"><p className="text-sm font-medium">Buat kurva S rencana</p>
      <div className="grid grid-cols-2 gap-2"><label className="text-xs text-slate-500">Pekan pertama (Senin)<input className={field} type="date" value={start} onChange={(e) => setStart(e.target.value)} /></label>
        <label className="text-xs text-slate-500">Jumlah pekan<input className={field} inputMode="numeric" value={weeks} onChange={(e) => setWeeks(e.target.value)} /></label></div>
      <Button variant="secondary" className="w-full" onClick={gen}>Buat otomatis, lalu sesuaikan</Button></Card>
    {draft && (<Card className="space-y-2"><p className="text-sm font-medium">Draf ({draft.length} pekan)</p>
      <div className="max-h-64 space-y-1 overflow-y-auto">{draft.map((r, i) => (<div key={r.week_start} className="flex items-center justify-between gap-3 text-sm"><span className="text-slate-600">{r.week_start}</span>
        <input className={`${field} !w-24 !py-1.5 text-right`} inputMode="decimal" value={r.planned_cum_pct} onChange={(e) => setDraft(draft.map((x, j) => (j === i ? { ...x, planned_cum_pct: e.target.value === '' ? '' : Number(e.target.value) } : x)))} /></div>))}</div>
      <div className="flex gap-2"><Button onClick={save}>Simpan jadwal</Button><Button variant="ghost" onClick={() => setDraft(null)}>Batal</Button></div></Card>)}
    <Card><p className="mb-2 text-sm font-medium">Jadwal tersimpan ({rows.length} pekan)</p>
      {rows.length === 0 ? <p className="text-sm text-slate-500">Belum ada jadwal.</p> : <div className="max-h-56 divide-y divide-slate-100 overflow-y-auto text-sm">{rows.map((r) => <div key={r.week_start} className="flex justify-between py-1.5"><span className="text-slate-600">{r.week_start}</span><span>{String(r.planned_cum_pct).replace('.', ',')}%</span></div>)}</div>}</Card></div>);
}

// ---------------- RAB + impor CSV ----------------
function parseNum(s) {
  let t = String(s ?? '').trim().replace(/[^\d.,-]/g, ''); if (!t) return NaN;
  const lc = t.lastIndexOf(','), ld = t.lastIndexOf('.');
  if (lc > -1 && ld > -1) t = lc > ld ? t.replace(/\./g, '').replace(',', '.') : t.replace(/,/g, '');
  else if (lc > -1) t = /^-?\d{1,3}(,\d{3})+$/.test(t) ? t.replace(/,/g, '') : t.replace(',', '.');
  else if (ld > -1 && /^-?\d{1,3}(\.\d{3})+$/.test(t)) t = t.replace(/\./g, '');
  return Number(t);
}
export function parseRab(text) {
  const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/).filter((l) => l.trim());
  if (!lines.length) return { rows: [], errors: ['File kosong.'] };
  const delim = [';', '\t', ','].map((d) => [d, lines[0].split(d).length]).sort((a, b) => b[1] - a[1])[0][0];
  const split = (l) => { const out = []; let cur = '', q = false; for (const ch of l) { if (ch === '"') q = !q; else if (ch === delim && !q) { out.push(cur); cur = ''; } else cur += ch; } out.push(cur); return out.map((x) => x.trim()); };
  let start = 0; if (/kode|uraian|volume/i.test(lines[0])) start = 1;
  const rows = [], errors = [];
  lines.slice(start).forEach((l, i) => {
    const c = split(l), n = i + start + 1;
    if (c.length < 5) return errors.push(`Baris ${n}: kolom kurang dari 5 (kode, uraian, satuan, volume, harga).`);
    const vol = parseNum(c[3]), price = parseNum(c[4]);
    if (!c[0] || !c[1]) return errors.push(`Baris ${n}: kode atau uraian kosong.`);
    if (!(vol >= 0) || !(price >= 0)) return errors.push(`Baris ${n}: volume atau harga bukan angka valid.`);
    rows.push({ code: c[0], description: c[1], unit: c[2] || 'ls', volume: vol, unit_price: price });
  });
  return { rows, errors };
}
function RabTab({ projectId }) {
  const [m, say] = useMsg(); const [rows, setRows] = useState(null); const [text, setText] = useState(''); const [prev, setPrev] = useState(null); const [busy, setBusy] = useState(false);
  const [f, setF] = useState({ code: '', description: '', unit: '', volume: '', price: '' });
  const load = useCallback(async () => { const { data, error } = await supabase.from('rab_items').select('id, code, description, unit, volume, unit_price, total').eq('project_id', projectId).order('code').limit(500);
    if (error) { console.error('[rab]', error); return say('Tidak bisa memuat RAB.'); } setRows(data); }, [projectId]); // eslint-disable-line
  useEffect(() => { load(); }, [load]);
  const total = (rows || []).reduce((s, r) => s + Number(r.total), 0);

  function check(t) { setText(t); setPrev(t.trim() ? parseRab(t) : null); }
  async function run(list, okText) {
    setBusy(true); const { data, error } = await supabase.rpc('import_rab', { p_project: projectId, p_rows: list });
    setBusy(false); if (error) { console.error('[import_rab]', error); return say(error.message); }
    say(okText(data), true); setText(''); setPrev(null); load();
  }
  async function addOne(e) { e.preventDefault(); const v = parseNum(f.volume), p = parseNum(f.price);
    if (!f.code.trim() || !f.description.trim() || !(v >= 0) || !(p >= 0)) return say('Lengkapi kode, uraian, volume, dan harga.');
    await run([{ code: f.code, description: f.description, unit: f.unit, volume: v, unit_price: p }], () => 'Item disimpan.'); setF({ code: '', description: '', unit: '', volume: '', price: '' }); }
  async function del(id) { if (!(await askConfirm('Hapus item RAB ini?'))) return; const { error } = await supabase.from('rab_items').delete().eq('id', id); if (error) say('Gagal menghapus.'); else load(); }
  function template() { const csv = '\uFEFFkode;uraian;satuan;volume;harga satuan\r\nA.1;Galian tanah pondasi;m3;120;85000\r\nA.2;Pondasi batu kali;m3;64,5;980000\r\n';
saveFile(new Blob([csv], { type: 'text/csv;charset=utf-8' }), 'templat-rab.csv').catch((e) => { console.error('[templat]', e); say('Gagal menyimpan file.'); }); }
  async function file(e) { const f0 = e.target.files[0]; if (!f0) return; if (f0.size > 2 * 1024 * 1024) return say('File terlalu besar (maks 2 MB).'); check(await f0.text()); }

  if (!rows) return <Card><Skeleton className="h-16 w-full" /></Card>;
  return (<div className="space-y-3"><Msg m={m} />
    <Card interactive><p className="text-xs text-slate-500">Total RAB ({rows.length} item{rows.length === 500 ? ', 500 pertama' : ''})</p><p className="mt-1 text-xl font-semibold text-slate-900">{rp(total)}</p></Card>
    <Card className="space-y-2"><p className="text-sm font-medium">Impor dari CSV</p>
      <p className="text-xs text-slate-500">Kolom: kode, uraian, satuan, volume, harga satuan. Dari Excel: Simpan sebagai CSV, atau salin lalu tempel. Kode yang sudah ada akan diperbarui.</p>
      <div className="flex gap-2"><Button size="sm" variant="secondary" onClick={template}>Unduh templat</Button><label className="inline-flex cursor-pointer items-center rounded-lg border border-slate-200 px-3 text-sm">Pilih file<input type="file" accept=".csv,.txt,.tsv,text/csv,text/plain" className="hidden" onChange={file} /></label></div>
      <textarea className={field} rows={4} placeholder="…atau tempel isi tabel di sini" value={text} onChange={(e) => check(e.target.value)} />
      {prev && (<div className="space-y-1 text-sm"><p className="text-slate-700">{prev.rows.length} baris valid{prev.errors.length > 0 && <span className="text-red-700">, {prev.errors.length} bermasalah</span>}</p>
        {prev.errors.slice(0, 5).map((x) => <p key={x} className="text-xs text-red-700">{x}</p>)}
        {prev.rows.slice(0, 3).map((r) => <p key={r.code} className="truncate text-xs text-slate-500">{r.code} · {r.description} · {r.volume} {r.unit} × {rp(r.unit_price)}</p>)}
        <Button loading={busy} disabled={!prev.rows.length || prev.errors.length > 0} onClick={() => run(prev.rows, (n) => `${n} item diimpor.`)} className="w-full">Impor {prev.rows.length} item</Button>
        {prev.errors.length > 0 && <p className="text-xs text-slate-500">Perbaiki baris bermasalah dulu agar impor tidak setengah-setengah.</p>}</div>)}</Card>
    <Card as="form" onSubmit={addOne} className="space-y-2"><p className="text-sm font-medium">Tambah satu item</p>
      <div className="grid grid-cols-3 gap-2"><input className={field} placeholder="Kode" value={f.code} onChange={(e) => setF({ ...f, code: e.target.value })} />
        <input className={field} placeholder="Satuan" value={f.unit} onChange={(e) => setF({ ...f, unit: e.target.value })} />
        <input className={field} inputMode="decimal" placeholder="Volume" value={f.volume} onChange={(e) => setF({ ...f, volume: e.target.value })} /></div>
      <input className={field} placeholder="Uraian pekerjaan" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
      <input className={field} inputMode="decimal" placeholder="Harga satuan (Rp)" value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })} />
      <Button className="w-full">Simpan item</Button></Card>
    <Card className="divide-y divide-slate-100 p-0">{rows.map((r) => (<div key={r.id} className="flex items-start justify-between gap-3 p-3 text-sm"><div className="min-w-0"><p className="font-medium text-slate-900">{r.code} <span className="font-normal text-slate-600">{r.description}</span></p>
      <p className="text-xs text-slate-500">{Number(r.volume)} {r.unit} × {rp(r.unit_price)}</p></div><div className="text-right"><p className="whitespace-nowrap font-medium">{rp(r.total)}</p><button className="text-xs text-slate-400" onClick={() => del(r.id)}>Hapus</button></div></div>))}</Card></div>);
}

export default function MasterData({ projectId }) {
  const { profile } = useAuth(); const role = profile.role;
  const TABS = [['proyek', 'Proyek dan anggota', ['pm', 'owner'], 0], ['tukang', 'Tukang dan kasbon', ['pm', 'admin_proyek'], 1], ['supplier', 'Supplier', ['pm', 'admin_proyek', 'finance'], 0],
    ['jadwal', 'Jadwal kurva S', ['pm', 'estimator'], 1], ['rab', 'RAB', ['pm', 'estimator'], 1]].filter((t) => t[2].includes(role));
  const [tab, setTab] = useState(TABS[0]?.[0]);
  const t = TABS.find((x) => x[0] === tab) || TABS[0];
  if (!t) return <Card className="m-4"><p className="text-sm text-slate-700">Peran Anda tidak mengelola master data.</p></Card>;
  const need = t[3] && !projectId;
  return (
    <ErrorBoundary name="master-data"><div className="mx-auto max-w-md space-y-3 p-4">
      <div className="flex gap-2 overflow-x-auto pb-1">{TABS.map(([k, l]) => <Button key={k} size="sm" variant={t[0] === k ? 'primary' : 'secondary'} onClick={() => setTab(k)} className="whitespace-nowrap">{l}</Button>)}</div>
      {need ? <Card><p className="text-sm text-slate-700">Pilih proyek di bagian atas layar terlebih dulu.</p></Card>
        : t[0] === 'proyek' ? <ProyekTab projectId={projectId} /> : t[0] === 'tukang' ? <TukangTab projectId={projectId} /> : t[0] === 'supplier' ? <SupplierTab />
        : t[0] === 'jadwal' ? <JadwalTab projectId={projectId} /> : <RabTab projectId={projectId} />}
    </div></ErrorBoundary>
  );
}
