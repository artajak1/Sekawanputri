// ExportPanel.jsx — pilih laporan, periode, format; unduh. Hanya laporan yang sesuai peran yang tampil.
import React, { useState } from 'react';
import { useAuth } from './auth.jsx';
import { REPORTS, exportReport } from './exportExcel.js';
import { Button, Card, ErrorBoundary } from './ui.jsx';

const field = 'w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-slate-900 focus:ring-4 focus:ring-slate-900/10';
const iso = (d) => d.toISOString().slice(0, 10);
function mondayOf(d = new Date()) { const x = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate())); x.setUTCDate(x.getUTCDate() - ((x.getUTCDay() + 6) % 7)); return iso(x); }

function Panel({ projectId }) {
  const { profile } = useAuth();
  const allowed = Object.entries(REPORTS).filter(([, r]) => r.roles.includes(profile.role));
  const [key, setKey] = useState(allowed[0]?.[0]);
  const [from, setFrom] = useState(() => iso(new Date()).slice(0, 7) + '-01');
  const [to, setTo] = useState(() => iso(new Date()));
  const [week, setWeek] = useState(mondayOf);
  const [fmt, setFmt] = useState('xlsx');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState({ t: '', ok: false });

  if (!allowed.length) return <Card><p className="text-sm text-slate-700">Peran Anda tidak memiliki laporan untuk diunduh.</p></Card>;
  const def = REPORTS[key];

  async function run() {
    setMsg({ t: '', ok: false });
    if (!navigator.onLine) return setMsg({ t: 'Ekspor butuh sinyal. Coba lagi saat online.', ok: false });
    if (def.needs === 'range' && (!from || !to || from > to)) return setMsg({ t: 'Periode tidak valid: tanggal awal harus sebelum tanggal akhir.', ok: false });
    setBusy(true);
    try {
      const r = await exportReport(key, { projectId, from, to, weekStart: week }, fmt);
      setMsg(r.declined ? { t: 'Unduhan dibatalkan.', ok: false } : { t: `Berhasil mengunduh ${r.rows} baris (${r.name}).`, ok: true });
    } catch (e) {
      console.error('[ekspor]', key, e);
      setMsg({ t: e.message?.startsWith('Tidak ada') || e.message?.startsWith('Rekap') ? e.message : 'Gagal membuat file. Periksa sinyal lalu coba lagi.', ok: false });
    } finally { setBusy(false); }
  }

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 gap-2">{allowed.map(([k, r]) => (
        <Button key={k} variant={key === k ? 'primary' : 'secondary'} onClick={() => { setKey(k); setMsg({ t: '', ok: false }); }}>{r.label}</Button>))}</div>
      <Card className="space-y-3">
        {def.needs === 'range' && (<div className="grid grid-cols-2 gap-2">
          <label className="text-xs text-slate-500">Dari<input className={field} type="date" value={from} onChange={(e) => setFrom(e.target.value)} /></label>
          <label className="text-xs text-slate-500">Sampai<input className={field} type="date" value={to} onChange={(e) => setTo(e.target.value)} /></label></div>)}
        {def.needs === 'week' && <label className="block text-xs text-slate-500">Pekan mulai (Senin)<input className={field} type="date" value={week} onChange={(e) => setWeek(e.target.value)} /></label>}
        {def.needs === 'none' && <p className="text-sm text-slate-500">Seluruh item RAB proyek ini, dengan jumlah dihitung rumus Excel.</p>}
        <div className="grid grid-cols-2 gap-2" role="group" aria-label="Format">{[['xlsx', 'Excel (.xlsx)'], ['csv', 'CSV']].map(([k, l]) => (
          <Button key={k} size="sm" variant={fmt === k ? 'primary' : 'secondary'} onClick={() => setFmt(k)} aria-pressed={fmt === k}>{l}</Button>))}</div>
        {msg.t && <p role="alert" className={`text-sm ${msg.ok ? 'text-green-700' : 'text-red-700'}`}>{msg.t}</p>}
        <Button size="lg" className="w-full" loading={busy} onClick={run}>Unduh {def.label.toLowerCase()}</Button>
      </Card>
    </div>
  );
}

export default function ExportPanel({ projectId }) {
  return <ErrorBoundary name="ekspor"><div className="mx-auto max-w-md p-4"><Panel projectId={projectId} /></div></ErrorBoundary>;
}
// Pakai: <ExportPanel projectId={id}/>. Instal: npm i exceljs  (dimuat lazy, tidak menambah ukuran awal aplikasi)
