// ReportApprovals.jsx — PM menyetujui/menolak laporan harian (memanggil decide_report dari 07_dashboard.sql).
import React, { useCallback, useEffect, useState } from 'react';
import { supabase } from './auth.jsx';
import { askText } from './dialog.jsx';
import { Button, Card, Skeleton, ErrorBoundary } from './ui.jsx';

function Body({ projectId }) {
  const [rows, setRows] = useState(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState('');
  const [photos, setPhotos] = useState({});

  const load = useCallback(async () => {
    const { data, error } = await supabase.from('daily_reports')
      .select('id, report_date, weather, physical_pct, notes, profiles!daily_reports_created_by_fkey(full_name)')
      .eq('project_id', projectId).eq('status', 'submitted').order('report_date', { ascending: false }).limit(20);
    if (error) { console.error('[laporan]', error); return setErr('Tidak bisa memuat laporan.'); }
    setRows(data); setErr('');
  }, [projectId]);
  useEffect(() => { load(); }, [load]);

  // Foto dimuat hanya saat diminta (hemat egress), lewat signed URL berumur pendek
  async function showPhoto(id) {
    const { data: a } = await supabase.from('attachments').select('storage_path').eq('ref_table', 'daily_reports').eq('ref_id', id).limit(1).maybeSingle();
    if (!a) return setPhotos((p) => ({ ...p, [id]: 'none' }));
    const { data } = await supabase.storage.from('site-photos').createSignedUrl(a.storage_path, 120);
    setPhotos((p) => ({ ...p, [id]: data?.signedUrl || 'none' }));
  }
  async function decide(id, approve) {
    const note = approve ? null : (await askText('Alasan penolakan (opsional):')) || null;
    setBusy(id); setErr('');
    const { error } = await supabase.rpc('decide_report', { p_report: id, p_approve: approve, p_note: note });
    if (error) { console.error('[decide_report]', error); setErr(error.message); }
    await load(); setBusy('');
  }

  if (!rows) return <Card><Skeleton className="h-16 w-full" /></Card>;
  return (
    <div className="space-y-3">
      {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
      {rows.length === 0 && <Card><p className="text-sm text-slate-500">Tidak ada laporan yang menunggu persetujuan.</p></Card>}
      {rows.map((r) => (
        <Card key={r.id} interactive>
          <div className="flex justify-between gap-3">
            <div><p className="font-semibold text-slate-900">{r.report_date}</p>
              <p className="text-sm text-slate-500">{r.profiles?.full_name} · {r.weather}</p></div>
            <p className="text-lg font-semibold">{String(r.physical_pct).replace('.', ',')}%</p>
          </div>
          {r.notes && <p className="mt-2 whitespace-pre-wrap text-sm text-slate-700">{r.notes}</p>}
          {photos[r.id] && photos[r.id] !== 'none' && <img src={photos[r.id]} alt="Foto progres" className="mt-3 w-full rounded-lg border border-slate-200" />}
          {photos[r.id] === 'none' && <p className="mt-2 text-xs text-slate-500">Tidak ada foto.</p>}
          <div className="mt-3 flex flex-wrap gap-2">
            <Button size="sm" loading={busy === r.id} onClick={() => decide(r.id, true)}>Setujui</Button>
            <Button size="sm" variant="danger" onClick={() => decide(r.id, false)}>Tolak</Button>
            {!photos[r.id] && <Button size="sm" variant="ghost" onClick={() => showPhoto(r.id)}>Lihat foto</Button>}
          </div>
        </Card>))}
    </div>
  );
}

export default function ReportApprovals({ projectId }) {
  return <ErrorBoundary name="approval-laporan"><div className="mx-auto max-w-md p-4"><Body projectId={projectId} /></div></ErrorBoundary>;
}
// Pakai: <RoleGate allow={['pm']}><ReportApprovals projectId={id}/></RoleGate>
