// excel-loader.js — memuat ExcelJS hanya saat dibutuhkan (ekspor). Versi build artifact memuatnya dari CDN.
export async function loadExcelJS() { const m = await import('exceljs'); return m.default || m; }
