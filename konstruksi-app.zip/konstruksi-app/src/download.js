// download.js — menyimpan file ke perangkat. Di halaman Artifact memakai kapabilitas "downloads" (ada dialog konfirmasi);
// di tempat lain memakai tautan unduh biasa. Mengembalikan { status: 'saved' | 'declined' }.
export async function saveFile(blob, filename) {
  let d = null;
  try { d = window.claude?.use ? await window.claude.use('downloads') : null; } catch { d = null; }
  if (d) {
    try { await d.save({ filename, data: blob }); return { status: 'saved' }; }
    catch (e) { if (e?.code === 'declined') return { status: 'declined' }; throw e; }
  }
  const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = filename;
  document.body.appendChild(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 1000);
  return { status: 'saved' };
}
