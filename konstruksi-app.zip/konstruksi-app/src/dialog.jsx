// dialog.jsx — pengganti confirm()/prompt() bawaan browser (sering diblokir di PWA dan halaman tertanam).
import React, { useEffect, useRef, useState } from 'react';
import { Button, Card } from './ui.jsx';

let host = null;
export const askConfirm = (message) => (host ? host.open({ type: 'confirm', message }) : Promise.resolve(window.confirm(message)));
export const askText = (message) => (host ? host.open({ type: 'text', message }) : Promise.resolve(window.prompt(message)));

export function DialogHost() {
  const [d, setD] = useState(null); const [val, setVal] = useState(''); const inp = useRef(null);
  useEffect(() => { host = { open: (req) => new Promise((resolve) => { setVal(''); setD({ ...req, resolve }); }) }; return () => { host = null; }; }, []);
  useEffect(() => { if (d?.type === 'text') inp.current?.focus(); }, [d]);
  if (!d) return null;
  const close = (v) => { const r = d.resolve; setD(null); r(v); };
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-slate-900/40 p-4 sm:items-center" role="dialog" aria-modal="true">
      <Card className="w-full max-w-sm">
        <p className="text-sm text-slate-900">{d.message}</p>
        {d.type === 'text' && <input ref={inp} value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && close(val.trim() || null)}
          className="mt-3 w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-slate-900 focus:ring-4 focus:ring-slate-900/10" />}
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="secondary" onClick={() => close(d.type === 'confirm' ? false : null)}>Batal</Button>
          <Button onClick={() => close(d.type === 'confirm' ? true : val.trim() || null)}>{d.type === 'confirm' ? 'Ya' : 'OK'}</Button>
        </div>
      </Card>
    </div>
  );
}
