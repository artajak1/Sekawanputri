// Payroll.jsx — absensi HOK (tap sel), rekap upah mingguan, persetujuan PM, ekspor CSV.
import React, { useCallback, useEffect, useMemo, useState } from 'react';
import { supabase, useAuth, RoleGate } from './auth.jsx';
import { enqueue } from './offlineQueue.js';
import { saveFile } from './download.js';
import { Button, Card, Skeleton, ErrorBoundary } from './ui.jsx';

const rp = (n) => 'Rp ' + new Intl.NumberFormat('id-ID').format(n || 0);
const DAYS = ['Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab', 'Min'];
const CYCLE = [0, 1, 0.5]; // ketuk: 0 -> 1 -> 0,5 -> 0
const iso = (d) => d.toISOString().slice(0, 10);

function monday(d = new Date()) {
  const x = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  x.setUTCDate(x.getUTCDate() - ((x.getUTCDay() + 6) % 7));
  return x;
}
const addDays = (d, n) => { const x = new Date(d); x.setUTCDate(x.getUTCDate() + n); return x; };

// client_id deterministik (pekerja+tanggal): ubah sel berkali-kali offline tetap satu entri
async function cellId(workerId, date) {
  const h = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(`att:${workerId}:${date}`));
  const b = [...new Uint8Array(h)].slice(0, 16).map((x) => x.toString(16).padStart(2, '0')).join('');
  return `${b.slice(0, 8)}-${b.slice(8, 12)}-${b.slice(12, 16)}-${b.slice(16, 20)}-${b.slice(20)}`;
}

function Grid({ projectId, week, workers }) {
  const { user } = useAuth();
  const [hok, setHok] = useState({});   // "workerId|date" -> nilai
  const [err, setErr] = useState('');
  const dates = useMemo(() => DAYS.map((_, i) => iso(addDays(week, i))), [week]);

  useEffect(() => {
    (async () => {
      const { data, error } = await supabase.from('attendance').select('worker_id, work_date, hok')
        .gte('work_date', dates[0]).lte('work_date', dates[6])
        .in('worker_id', workers.map((w) => w.id));
      if (error) return console.warn('[absensi] pakai data lokal', error);
      const m = {}; data.forEach((r) => { m[`${r.worker_id}|${r.work_date}`] = Number(r.hok); });
      setHok((prev) => ({ ...m, ...prev }));
    })();
  }, [dates, workers]);

  async function tap(w, date) {
    const key = `${w.id}|${date}`;
    const next = CYCLE[(CYCLE.indexOf(hok[key] ?? 0) + 1) % CYCLE.length];
    setHok((p) => ({ ...p, [key]: next }));          // tampil instan
    try {
      await enqueue({ table: 'attendance', projectId, row: {
        client_id: await cellId(w.id, date), worker_id: w.id, work_date: date, hok: next, created_by: user.id } });
      setErr('');
    } catch (e) { console.error('[absensi]', e); setErr('Gagal menyimpan di perangkat.'); }
  }

  return (
    <Card className="overflow-x-auto p-0">
      <table className="w-full min-w-[420px] text-sm">
        <thead><tr className="text-left text-xs text-slate-500">
          <th className="p-3 font-medium">Tukang</th>
          {DAYS.map((d) => <th key={d} className="px-1 py-3 text-center font-medium">{d}</th>)}
          <th className="p-3 text-right font-medium">HOK</th></tr></thead>
        <tbody>
          {workers.map((w) => {
            const total = dates.reduce((s, d) => s + (hok[`${w.id}|${d}`] || 0), 0);
            return (
              <tr key={w.id} className="border-t border-slate-100">
                <td className="p-3 font-medium text-slate-900">{w.name}</td>
                {dates.map((d) => {
                  const v = hok[`${w.id}|${d}`] || 0;
                  return (
                    <td key={d} className="px-0.5 py-1.5 text-center">
                      <button type="button" onClick={() => tap(w, d)} aria-label={`${w.name} ${d}: ${v} HOK`}
                        className={`h-9 w-9 rounded-md border text-xs transition-transform active:scale-[0.93] ${v ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 bg-white text-slate-400'}`}>
                        {v === 0.5 ? '½' : v || '·'}
                      </button>
                    </td>
                  );
                })}
                <td className="p-3 text-right font-semibold">{String(total).replace('.', ',')}</td>
              </tr>
            );
          })}
        </tbody>
      </table>
      {err && <p role="alert" className="p-3 text-sm text-red-700">{err}</p>}
    </Card>
  );
}

function Recap({ projectId, week }) {
  const [run, setRun] = useState(undefined);
  const [lines, setLines] = useState([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');
  const ws = iso(week);

  const load = useCallback(async () => {
    const { data: r, error } = await supabase.from('payroll_runs')
      .select('id, status, total_gross, total_deduct, total_net').eq('project_id', projectId).eq('week_start', ws).maybeSingle();
    if (error) { console.error('[rekap]', error); return setErr('Tidak bisa memuat rekap.'); }
    setRun(r);
    if (r) {
      const { data } = await supabase.from('payroll_lines')
        .select('hok_total, gross, advance_deduct, net, workers(name)').eq('run_id', r.id);
      setLines(data || []);
    } else setLines([]);
  }, [projectId, ws]);
  useEffect(() => { setRun(undefined); load(); }, [load]);

  async function call(fn, args) {
    setBusy(true); setErr('');
    const { error } = await supabase.rpc(fn, args);
    if (error) { console.error('[payroll]', error); setErr(error.message); }
    await load(); setBusy(false);
  }

  function exportCsv() {
    const rows = [['Tukang', 'HOK', 'Upah kotor', 'Potongan kasbon', 'Upah bersih'],
      ...lines.map((l) => [l.workers.name, l.hok_total, l.gross, l.advance_deduct, l.net])];
    const csv = '\uFEFF' + rows.map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(';')).join('\n');
    saveFile(new Blob([csv], { type: 'text/csv;charset=utf-8' }), `rekap-upah-${ws}.csv`).catch((e) => { console.error('[csv]', e); setErr('Gagal menyimpan file.'); });
  }

  if (run === undefined) return <Card><Skeleton className="h-5 w-40" /><Skeleton className="mt-3 h-16 w-full" /></Card>;
  const stateTxt = { submitted: 'Menunggu persetujuan PM', approved: 'Disetujui', rejected: 'Ditolak, hitung ulang setelah koreksi' };
  return (
    <Card className="space-y-3">
      <div className="flex items-center justify-between">
        <p className="font-semibold text-slate-900">Rekap upah pekan ini</p>
        {run && <span className="text-xs text-slate-500">{stateTxt[run.status]}</span>}
      </div>
      {run && (<>
        <div className="divide-y divide-slate-100 text-sm">
          {lines.map((l, i) => (
            <div key={i} className="flex justify-between py-2">
              <div><p className="font-medium text-slate-900">{l.workers.name}</p>
                <p className="text-xs text-slate-500">{l.hok_total} HOK · kotor {rp(l.gross)}{l.advance_deduct > 0 && ` · kasbon −${rp(l.advance_deduct)}`}</p></div>
              <p className="font-semibold">{rp(l.net)}</p>
            </div>))}
        </div>
        <div className="flex justify-between border-t border-slate-200 pt-3 text-sm"><span>Total bersih</span><strong>{rp(run.total_net)}</strong></div>
      </>)}
      {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
      <div className="flex flex-wrap gap-2">
        <RoleGate allow={['pm', 'admin_proyek']}>
          {run?.status !== 'approved' && <Button variant="secondary" loading={busy} onClick={() => call('generate_payroll', { p_project: projectId, p_week_start: ws })}>{run ? 'Hitung ulang' : 'Hitung upah'}</Button>}
        </RoleGate>
        <RoleGate allow={['pm']}>
          {run?.status === 'submitted' && (<>
            <Button loading={busy} onClick={() => call('decide_payroll', { p_run: run.id, p_approve: true })}>Setujui</Button>
            <Button variant="danger" loading={busy} onClick={() => call('decide_payroll', { p_run: run.id, p_approve: false })}>Tolak</Button></>)}
        </RoleGate>
        {run && lines.length > 0 && <Button variant="ghost" onClick={exportCsv}>Ekspor CSV</Button>}
      </div>
    </Card>
  );
}

export default function Payroll({ projectId }) {
  const [week, setWeek] = useState(() => monday());
  const [workers, setWorkers] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const { data, error } = await supabase.from('workers').select('id, name').eq('project_id', projectId).eq('is_active', true).order('name');
        if (error) throw error;
        localStorage.setItem(`workers-${projectId}`, JSON.stringify(data)); setWorkers(data);
      } catch (e) { console.warn('[tukang] pakai cache', e); setWorkers(JSON.parse(localStorage.getItem(`workers-${projectId}`) || '[]')); }
    })();
  }, [projectId]);

  const label = `${week.getUTCDate()}/${week.getUTCMonth() + 1} – ${addDays(week, 6).getUTCDate()}/${addDays(week, 6).getUTCMonth() + 1}`;
  return (
    <ErrorBoundary name="payroll">
      <div className="mx-auto max-w-2xl space-y-3 p-4">
        <div className="flex items-center justify-between">
          <Button size="sm" variant="secondary" onClick={() => setWeek(addDays(week, -7))}>‹</Button>
          <p className="text-sm font-medium text-slate-900">Pekan {label}</p>
          <Button size="sm" variant="secondary" onClick={() => setWeek(addDays(week, 7))}>›</Button>
        </div>
        {!workers ? <Card><Skeleton className="h-32 w-full" /></Card>
          : workers.length === 0 ? <Card><p className="text-sm text-slate-700">Belum ada tukang di proyek ini.</p></Card>
          : <Grid projectId={projectId} week={week} workers={workers} />}
        <Recap projectId={projectId} week={week} />
      </div>
    </ErrorBoundary>
  );
}
// Pakai: <RoleGate allow={['mandor','admin_proyek','pm']}><Payroll projectId={id}/></RoleGate>
