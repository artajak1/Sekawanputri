// App.jsx — cangkang aplikasi: navigasi per peran, pilihan proyek, status sinkron. Modul dimuat malas (lazy)
// supaya unduhan awal kecil di HP entry-level.
import React, { Suspense, lazy, useCallback, useEffect, useState } from 'react';
import { supabase, useAuth, DEMO } from './auth.jsx';
import { pending } from './offlineQueue.js';
import { askConfirm } from './dialog.jsx';
import { Button, Card, Skeleton, ErrorBoundary } from './ui.jsx';

const L = (load, name) => lazy(() => load().then((m) => ({ default: name ? m[name] : m.default })));
const ALL = ['mandor', 'admin_proyek', 'pm', 'estimator', 'finance', 'owner'];

// project: true = butuh proyek terpilih. Urutan = urutan di bilah bawah (4 pertama) dan di menu.
const NAV = [
  { id: 'dashboard', label: 'Dasbor', roles: ['pm', 'owner', 'finance', 'estimator'], C: L(() => import('./Dashboard.jsx')) },
  { id: 'laporan', label: 'Laporan harian', roles: ['mandor', 'pm'], project: true, C: L(() => import('./DailyReportForm.jsx')) },
  { id: 'absensi', label: 'Absensi dan upah', roles: ['mandor', 'admin_proyek', 'pm'], project: true, C: L(() => import('./Payroll.jsx')) },
  { id: 'kas', label: 'Kas kecil', roles: ['admin_proyek', 'pm', 'finance', 'owner'], project: true, C: L(() => import('./PettyCash.jsx')) },
  { id: 'persetujuan', label: 'Persetujuan laporan', roles: ['pm'], project: true, C: L(() => import('./ReportApprovals.jsx')) },
  { id: 'po', label: 'Purchase order', roles: ['admin_proyek', 'pm', 'owner', 'finance'], project: true, C: L(() => import('./PurchaseOrders.jsx')) },
  { id: 'subkon', label: 'SPK dan adendum', roles: ['pm', 'owner', 'finance', 'estimator'], project: true, C: L(() => import('./SubconAddendum.jsx')) },
  { id: 'keuangan', label: 'Keuangan', roles: ['finance', 'owner', 'pm'], project: true, C: L(() => import('./Finance.jsx')) },
  { id: 'alat', label: 'Alat berat', roles: ['admin_proyek', 'pm', 'owner', 'finance'], project: true, C: L(() => import('./Equipment.jsx')) },
  { id: 'serahterima', label: 'Punch list dan retensi', roles: ALL.filter((r) => r !== 'estimator'), project: true, C: L(() => import('./Handover.jsx')) },
  { id: 'master', label: 'Master data', roles: ['pm', 'owner', 'admin_proyek', 'estimator', 'finance'], C: L(() => import('./MasterData.jsx')) },
  { id: 'gambar', label: 'Gambar kerja', roles: ALL, project: true, C: L(() => import('./DrawingsArchive.jsx'), 'DrawingsModule') },
  { id: 'ekspor', label: 'Ekspor laporan', roles: ALL, project: true, C: L(() => import('./ExportPanel.jsx')) },
  { id: 'arsip', label: 'Arsip', roles: ['owner', 'finance', 'pm'], C: L(() => import('./DrawingsArchive.jsx'), 'ArchiveModule'), wantsOpen: true },
];
const ROLE_LABEL = { mandor: 'Mandor', admin_proyek: 'Admin proyek', pm: 'Project manager', estimator: 'Estimator', finance: 'Keuangan', owner: 'Owner' };

function useSyncStatus() {
  const [n, setN] = useState(0);
  const [online, setOnline] = useState(navigator.onLine);
  useEffect(() => {
    let alive = true;
    const tick = async () => { try { const p = await pending(); if (alive) setN(p.length); } catch { /* IndexedDB tidak tersedia */ } };
    tick(); const t = setInterval(tick, 4000);
    const on = () => setOnline(true), off = () => setOnline(false);
    addEventListener('online', on); addEventListener('offline', off);
    return () => { alive = false; clearInterval(t); removeEventListener('online', on); removeEventListener('offline', off); };
  }, []);
  return { n, online };
}

function useProjects() {
  const [projects, setProjects] = useState(null);
  const [pid, setPid] = useState(() => localStorage.getItem('current-project') || '');
  useEffect(() => {
    (async () => {
      try {
        const { data, error } = await supabase.from('projects').select('id, name, status').neq('status', 'closed').order('name');
        if (error) throw error;
        localStorage.setItem('projects-nav', JSON.stringify(data)); setProjects(data);
      } catch (e) { console.warn('[proyek] pakai cache', e); try { setProjects(JSON.parse(localStorage.getItem('projects-nav')) || []); } catch { setProjects([]); } }
    })();
  }, []);
  useEffect(() => { if (projects && projects.length && !projects.some((p) => p.id === pid)) setPid(projects[0].id); }, [projects, pid]);
  const choose = useCallback((id) => { setPid(id); localStorage.setItem('current-project', id); }, []);
  return { projects, pid, choose };
}

export default function App() {
  const { profile } = useAuth();
  const items = NAV.filter((n) => n.roles.includes(profile.role));
  const { projects, pid, choose } = useProjects();
  const { n, online } = useSyncStatus();
  const [cur, setCur] = useState(() => (items.find((i) => i.id === location.hash.slice(1)) || items[0])?.id);
  const [sheet, setSheet] = useState(false);

  const go = useCallback((id) => { setCur(id); setSheet(false); history.replaceState(null, '', '#' + id); window.scrollTo(0, 0); }, []);
  useEffect(() => {
    const h = () => { const f = items.find((i) => i.id === location.hash.slice(1)); if (f) setCur(f.id); };
    addEventListener('hashchange', h); return () => removeEventListener('hashchange', h);
  }, [items]);

  const item = items.find((i) => i.id === cur) || items[0];
  const openProject = (id) => { choose(id); go((items.find((i) => i.project) || items[0]).id); };
  const extra = item?.wantsOpen ? { onOpen: openProject } : { projectId: pid };

  if (!item) return <Card className="m-4"><p className="text-sm text-slate-700">Peran Anda belum memiliki menu. Hubungi owner.</p></Card>;
  const bottom = items.slice(0, 4);

  return (
    <div className="min-h-screen pb-24">
      <header className="sticky top-0 z-20 border-b border-slate-200 bg-white/95 backdrop-blur" style={{ paddingTop: 'env(safe-area-inset-top)' }}>
        <div className="mx-auto flex max-w-md items-center gap-2 px-4 py-2.5">
          <select aria-label="Proyek" value={pid} onChange={(e) => choose(e.target.value)} disabled={!projects?.length}
            className="min-w-0 flex-1 truncate rounded-lg border border-slate-200 bg-white px-3 py-2 text-sm font-medium outline-none focus:border-slate-900 focus:ring-4 focus:ring-slate-900/10">
            {!projects ? <option>Memuat…</option> : projects.length === 0 ? <option>Belum ada proyek</option> : projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
          </select>
          <span role="status" className={`whitespace-nowrap rounded-full border px-2.5 py-1 text-xs ${!online ? 'border-amber-200 text-amber-700' : n > 0 ? 'border-amber-200 text-amber-700' : 'border-slate-200 text-slate-500'}`}>
            {!online ? (n ? `Offline · ${n} antre` : 'Offline') : n > 0 ? `${n} menunggu kirim` : 'Tersinkron'}
          </span>
        </div>
        {DEMO && <p className="bg-amber-50 px-4 py-1 text-center text-xs text-amber-800">Mode demo: data contoh hanya di HP ini</p>}
      </header>

      <main className="mx-auto max-w-2xl">
        {item.project && !pid ? <Card className="m-4"><p className="text-sm text-slate-700">Pilih atau minta PM menugaskan Anda ke sebuah proyek.</p></Card> : (
          <ErrorBoundary key={`${item.id}-${pid}`} name={item.id}>
            <Suspense fallback={<div className="space-y-3 p-4"><Skeleton className="h-6 w-40" /><Skeleton className="h-28 w-full" /><Skeleton className="h-28 w-full" /></div>}>
              <item.C {...extra} />
            </Suspense>
          </ErrorBoundary>)}
      </main>

      <nav aria-label="Navigasi utama" className="fixed inset-x-0 bottom-0 z-20 border-t border-slate-200 bg-white" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
        <div className="mx-auto grid max-w-md grid-cols-5">
          {bottom.map((b) => (
            <button key={b.id} onClick={() => go(b.id)} aria-current={cur === b.id ? 'page' : undefined}
              className={`truncate px-1 py-3 text-xs font-medium transition-transform active:scale-[0.96] ${cur === b.id ? 'text-slate-900' : 'text-slate-500'}`}>
              <span className={`mx-auto mb-1 block h-0.5 w-6 rounded-full ${cur === b.id ? 'bg-slate-900' : 'bg-transparent'}`} />{b.label.split(' ')[0]}
            </button>))}
          <button onClick={() => setSheet(true)} className="px-1 py-3 text-xs font-medium text-slate-500 transition-transform active:scale-[0.96]">
            <span className="mx-auto mb-1 block h-0.5 w-6 rounded-full bg-transparent" />Menu
          </button>
        </div>
      </nav>

      {sheet && (
        <div className="fixed inset-0 z-30" role="dialog" aria-modal="true" aria-label="Menu">
          <div className="absolute inset-0 bg-slate-900/40" onClick={() => setSheet(false)} />
          <div className="absolute inset-x-0 bottom-0 max-h-[85vh] overflow-y-auto rounded-t-2xl bg-white p-4" style={{ paddingBottom: 'calc(1rem + env(safe-area-inset-bottom))' }}>
            <div className="mx-auto max-w-md">
              <p className="font-semibold text-slate-900">{profile.full_name}</p>
              <p className="text-sm text-slate-500">{ROLE_LABEL[profile.role]}</p>
              <div className="mt-3 grid grid-cols-2 gap-2">
                {items.map((i) => (
                  <button key={i.id} onClick={() => go(i.id)}
                    className={`rounded-xl border px-3 py-3 text-left text-sm transition hover:-translate-y-0.5 hover:shadow-sm active:scale-[0.98] ${cur === i.id ? 'border-slate-900 bg-slate-900 text-white' : 'border-slate-200 bg-white text-slate-900'}`}>{i.label}</button>))}
              </div>
              {DEMO && (
                <div className="mt-4 rounded-xl border border-amber-200 bg-amber-50 p-3">
                  <p className="text-xs font-medium text-amber-800">Alat mode demo</p>
                  <div className="mt-2 flex flex-wrap gap-1.5">
                    {supabase.demo.users().map((u) => (
                      <button key={u.id} onClick={async () => { setSheet(false); await supabase.auth.signInWithPassword({ email: u.email }); }}
                        className={`rounded-full border px-2.5 py-1 text-xs ${u.role === profile.role ? 'border-slate-900 bg-slate-900 text-white' : 'border-amber-300 bg-white text-slate-800'}`}>{ROLE_LABEL[u.role]}</button>))}
                  </div>
                  <div className="mt-2 flex gap-2">
                    <Button size="sm" variant="secondary" onClick={() => { supabase.demo.expireRetention(); setSheet(false); location.reload(); }}>Percepat jatuh tempo retensi</Button>
                    <Button size="sm" variant="danger" onClick={async () => { if (await askConfirm('Kembalikan semua data demo ke awal?')) { supabase.demo.reset(); location.reload(); } }}>Reset data</Button>
                  </div>
                </div>)}
              <Button className="mt-4 w-full" variant="secondary" onClick={() => supabase.auth.signOut()}>Keluar</Button>
            </div>
          </div>
        </div>)}
    </div>
  );
}
