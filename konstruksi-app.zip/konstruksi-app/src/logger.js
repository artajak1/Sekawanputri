// logger.js — mencatat error ke tabel client_errors. Tidak pernah melempar error sendiri.
import { supabase } from './auth.jsx';

const VERSION = import.meta.env.VITE_APP_VERSION || 'dev';
let sent = 0;                         // batas per sesi agar tidak membanjiri database
const seen = new Set();

export async function logError(source, err) {
  try {
    const message = String(err?.message || err || 'error').slice(0, 1900);
    const key = source + '|' + message;
    if (sent >= 10 || seen.has(key)) return;
    seen.add(key); sent++;
    if (!navigator.onLine) return;                         // offline: cukup console
    const { data } = await supabase.auth.getSession();
    if (!data.session) return;
    await supabase.from('client_errors').insert({
      source: String(source).slice(0, 100), message, stack: String(err?.stack || '').slice(0, 5900),
      url: location.pathname + location.hash, user_agent: navigator.userAgent.slice(0, 300), app_version: VERSION,
    });
  } catch { /* pencatatan gagal tidak boleh mengganggu aplikasi */ }
}

export function installGlobalHandlers() {
  window.__logError = logError;
  window.addEventListener('error', (e) => logError('window.error', e.error || e.message));
  window.addEventListener('unhandledrejection', (e) => logError('unhandledrejection', e.reason));
}
