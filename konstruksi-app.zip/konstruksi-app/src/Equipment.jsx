// Equipment.jsx — alat berat: log HM/KM + BBM (offline), rekap bulanan, persetujuan sewa oleh owner.
import React, { useCallback, useEffect, useState } from 'react';
import { supabase, useAuth } from './auth.jsx';
import { enqueue } from './offlineQueue.js';
import { compressImage } from './imageCompress.js';
import { Button, Card, Skeleton, ErrorBoundary } from './ui.jsx';

const rp = (n) => 'Rp ' + new Intl.NumberFormat('id-ID').format(Math.round(n || 0));
const num = (n, d = 1) => new Intl.NumberFormat('id-ID', { maximumFractionDigits: d }).format(n || 0);
const field = 'w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-slate-900 focus:ring-4 focus:ring-slate-900/10';
const today = () => new Date().toISOString().slice(0, 10);
const monthStart = () => today().slice(0, 7) + '-01';
const OVER = 1.3; // konsumsi di atas 130% norma dianggap janggal

function LogForm({ items, last, onSaved }) {
  const { user } = useAuth();
  const [f, setF] = useState({ equipment_id: items[0]?.id || '', log_date: today(), meter_start: '', meter_end: '', fuel_liters: '', fuel_price: '' });
  const [photo, setPhoto] = useState(null);
  const [msg, setMsg] = useState({ t: '', ok: false });
  const eq = items.find((i) => i.id === f.equipment_id);
  const prev = last[f.equipment_id];

  useEffect(() => { setF((x) => ({ ...x, meter_start: prev != null ? String(prev) : '' })); }, [f.equipment_id, prev]);

  async function pick(e) {
    const file = e.target.files[0]; setPhoto(null); if (!file) return;
    try { const c = await compressImage(file); setPhoto(new File([c.blob], `meter.${c.ext}`, { type: c.mime })); }
    catch (err) { console.error('[foto meter]', err); setMsg({ t: 'Foto tidak bisa diproses.', ok: false }); }
  }
  async function submit(e) {
    e.preventDefault();
    const s = Number(f.meter_start), en = Number(f.meter_end);
    if (!f.equipment_id || f.meter_start === '' || f.meter_end === '') return setMsg({ t: `Isi ${eq?.meter_unit || 'meter'} awal dan akhir.`, ok: false });
    if (en < s) return setMsg({ t: `${eq.meter_unit} akhir tidak boleh lebih kecil dari ${eq.meter_unit} awal.`, ok: false });
    try {
      await enqueue({ table: 'equipment_logs', projectId: eq.project_id, photo, row: {
        equipment_id: f.equipment_id, log_date: f.log_date, meter_start: s, meter_end: en,
        fuel_liters: Number(f.fuel_liters) || 0, fuel_price: Number(f.fuel_price) || null, created_by: user.id } });
      setMsg({ t: 'Tersimpan. Terkirim otomatis saat ada sinyal.', ok: true });
      setF({ ...f, meter_end: '', fuel_liters: '' }); setPhoto(null); e.target.reset(); setTimeout(onSaved, 1500);
    } catch (err) { console.error('[log alat]', err); setMsg({ t: 'Gagal menyimpan di perangkat.', ok: false }); }
  }
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  return (
    <Card as="form" onSubmit={submit} className="space-y-2">
      <p className="text-sm font-medium text-slate-900">Catat pemakaian harian</p>
      <select className={field} value={f.equipment_id} onChange={set('equipment_id')}>{items.map((i) => <option key={i.id} value={i.id}>{i.name} ({i.code})</option>)}</select>
      <input className={field} type="date" value={f.log_date} onChange={set('log_date')} />
      <div className="grid grid-cols-2 gap-2">
        <input className={field} inputMode="decimal" placeholder={`${eq?.meter_unit} awal`} value={f.meter_start} onChange={set('meter_start')} />
        <input className={field} inputMode="decimal" placeholder={`${eq?.meter_unit} akhir`} value={f.meter_end} onChange={set('meter_end')} />
      </div>
      <div className="grid grid-cols-2 gap-2">
        <input className={field} inputMode="decimal" placeholder="BBM (liter)" value={f.fuel_liters} onChange={set('fuel_liters')} />
        <input className={field} inputMode="numeric" placeholder="Harga/liter (opsional)" value={f.fuel_price} onChange={set('fuel_price')} />
      </div>
      <input className="text-sm" type="file" accept="image/*" capture="environment" onChange={pick} />
      <p className="text-xs text-slate-500">Foto panel {eq?.meter_unit} membuat catatan lebih bisa dipercaya.</p>
      {msg.t && <p role="alert" className={`text-sm ${msg.ok ? 'text-green-700' : 'text-red-700'}`}>{msg.t}</p>}
      <Button size="lg" className="w-full">Simpan</Button>
    </Card>
  );
}

function NewEquipment({ projectId, onSaved }) {
  const { user } = useAuth();
  const [f, setF] = useState({ code: '', name: '', meter_unit: 'HM', ownership: 'milik', rental_rate: '', rental_basis: 'jam', fuel_norm: '' });
  const [msg, setMsg] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  async function submit(e) {
    e.preventDefault();
    if (!f.code.trim() || !f.name.trim()) return setMsg('Isi kode dan nama alat.');
    try {
      await enqueue({ table: 'equipment', projectId, row: { project_id: projectId, code: f.code.trim(), name: f.name.trim(), meter_unit: f.meter_unit,
        ownership: f.ownership, rental_rate: Number(f.rental_rate) || 0, rental_basis: f.rental_basis, fuel_norm: Number(f.fuel_norm) || 0, created_by: user.id } });
      setMsg(f.ownership === 'sewa' ? 'Diajukan. Sewa alat menunggu persetujuan owner.' : 'Alat ditambahkan.');
      setF({ ...f, code: '', name: '', rental_rate: '', fuel_norm: '' }); setTimeout(onSaved, 1500);
    } catch (err) { console.error('[alat baru]', err); setMsg('Gagal menyimpan di perangkat.'); }
  }
  return (
    <Card as="form" onSubmit={submit} className="space-y-2">
      <p className="text-sm font-medium text-slate-900">Tambah alat</p>
      <div className="grid grid-cols-2 gap-2"><input className={field} placeholder="Kode, mis. EX-01" value={f.code} onChange={set('code')} />
        <select className={field} value={f.meter_unit} onChange={set('meter_unit')}><option value="HM">Hour meter (HM)</option><option value="KM">Odometer (KM)</option></select></div>
      <input className={field} placeholder="Nama alat, mis. Excavator PC200" value={f.name} onChange={set('name')} />
      <div className="grid grid-cols-2 gap-2"><select className={field} value={f.ownership} onChange={set('ownership')}><option value="milik">Milik sendiri</option><option value="sewa">Sewa</option></select>
        <input className={field} inputMode="decimal" placeholder={`Norma BBM (liter/${f.meter_unit})`} value={f.fuel_norm} onChange={set('fuel_norm')} /></div>
      {f.ownership === 'sewa' && <div className="grid grid-cols-2 gap-2"><input className={field} inputMode="numeric" placeholder="Tarif sewa (Rp)" value={f.rental_rate} onChange={set('rental_rate')} />
        <select className={field} value={f.rental_basis} onChange={set('rental_basis')}><option value="jam">per jam ({f.meter_unit})</option><option value="hari">per hari kerja</option></select></div>}
      {msg && <p role="status" className="text-sm text-slate-600">{msg}</p>}
      <Button className="w-full">Simpan alat</Button>
    </Card>
  );
}

function Body({ projectId }) {
  const { profile } = useAuth();
  const role = profile.role;
  const [eq, setEq] = useState(null);
  const [usage, setUsage] = useState({});
  const [logs, setLogs] = useState([]);
  const [last, setLast] = useState({});
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    const [a, u, l] = await Promise.all([
      supabase.from('equipment').select('id, project_id, code, name, meter_unit, ownership, rental_rate, rental_basis, fuel_norm, status').eq('project_id', projectId).eq('is_active', true).order('code'),
      supabase.from('equipment_usage').select('equipment_id, days, usage, fuel_liters, per_unit, rental_cost, fuel_cost').eq('project_id', projectId).eq('month', monthStart()),
      supabase.from('equipment_log_check').select('id, equipment_id, log_date, meter_end, usage, fuel_liters, per_unit, gap_prev, fuel_norm')
        .order('log_date', { ascending: false }).limit(30)]);
    if (a.error) { console.error('[alat]', a.error); return setErr('Tidak bisa memuat alat.'); }
    setEq(a.data); setUsage(Object.fromEntries((u.data || []).map((x) => [x.equipment_id, x])));
    const ids = new Set(a.data.map((x) => x.id)); const mine = (l.data || []).filter((x) => ids.has(x.equipment_id));
    setLogs(mine);
    const lm = {}; mine.forEach((x) => { if (lm[x.equipment_id] == null) lm[x.equipment_id] = x.meter_end; }); setLast(lm);
  }, [projectId]);
  useEffect(() => { load(); }, [load]);

  async function decide(id, ok) {
    const { error } = await supabase.rpc('approve_equipment', { p_id: id, p_ok: ok });
    if (error) { console.error('[approve_equipment]', error); setErr(error.message); } else load();
  }

  if (!eq) return <Card><Skeleton className="h-16 w-full" /></Card>;
  const approved = eq.filter((x) => x.status === 'approved');
  const name = Object.fromEntries(eq.map((x) => [x.id, x]));
  return (
    <div className="space-y-3">
      {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
      {eq.length === 0 && <Card><p className="text-sm text-slate-500">Belum ada alat.</p></Card>}
      {eq.map((x) => {
        const u = usage[x.id]; const over = u?.per_unit && x.fuel_norm > 0 && u.per_unit > x.fuel_norm * OVER;
        return (
          <Card key={x.id} interactive className={over ? 'border-red-200' : ''}>
            <div className="flex justify-between gap-3"><div><p className="font-semibold text-slate-900">{x.name}</p><p className="text-xs text-slate-500">{x.code} · {x.ownership === 'sewa' ? 'Sewa' : 'Milik'}</p></div>
              {x.status !== 'approved' && <span className="text-xs text-amber-700">{x.status === 'pending' ? 'Menunggu owner' : 'Ditolak'}</span>}</div>
            {u ? (<div className="mt-3 grid grid-cols-3 gap-2 text-sm">
              <div><p className="text-xs text-slate-500">Pemakaian</p><p className="font-medium">{num(u.usage)} {x.meter_unit}</p></div>
              <div><p className="text-xs text-slate-500">BBM</p><p className="font-medium">{num(u.fuel_liters)} L</p></div>
              <div><p className="text-xs text-slate-500">Per {x.meter_unit}</p><p className={`font-medium ${over ? 'text-red-700' : ''}`}>{num(u.per_unit, 2)} L</p></div></div>)
              : x.status === 'approved' && <p className="mt-2 text-xs text-slate-500">Belum ada catatan bulan ini.</p>}
            {over && <p className="mt-2 text-xs font-medium text-red-700">Konsumsi BBM {num((u.per_unit / x.fuel_norm - 1) * 100, 0)}% di atas norma ({num(x.fuel_norm, 2)} L/{x.meter_unit}). Periksa.</p>}
            {u && (u.rental_cost > 0 || u.fuel_cost > 0) && <p className="mt-2 text-xs text-slate-500">Bulan ini: sewa {rp(u.rental_cost)} · BBM {rp(u.fuel_cost)}</p>}
            {role === 'owner' && x.status === 'pending' && <div className="mt-3 flex gap-2"><Button size="sm" onClick={() => decide(x.id, true)}>Setujui sewa</Button><Button size="sm" variant="danger" onClick={() => decide(x.id, false)}>Tolak</Button></div>}
          </Card>);
      })}
      {['admin_proyek', 'pm'].includes(role) && approved.length > 0 && <LogForm items={approved} last={last} onSaved={load} />}
      {logs.length > 0 && (
        <Card className="divide-y divide-slate-100 p-0">
          <p className="p-4 pb-2 text-sm font-medium text-slate-900">Catatan terakhir</p>
          {logs.slice(0, 10).map((l) => { const x = name[l.equipment_id]; const flagGap = l.gap_prev != null && Math.abs(l.gap_prev) > 0.5;
            const flagFuel = l.per_unit && l.fuel_norm > 0 && l.per_unit > l.fuel_norm * OVER;
            return (<div key={l.id} className="px-4 py-3 text-sm"><div className="flex justify-between"><span>{x?.name} · {l.log_date}</span><span className="text-slate-500">{num(l.usage)} {x?.meter_unit}</span></div>
              {flagGap && <p className="text-xs text-amber-700">{x.meter_unit} awal berbeda {num(l.gap_prev)} dari catatan sebelumnya</p>}
              {flagFuel && <p className="text-xs text-red-700">BBM melebihi norma pada hari ini</p>}</div>); })}
        </Card>)}
      {['admin_proyek', 'pm'].includes(role) && <NewEquipment projectId={projectId} onSaved={load} />}
    </div>
  );
}

export default function Equipment({ projectId }) {
  return <ErrorBoundary name="alat-berat"><div className="mx-auto max-w-md p-4"><Body projectId={projectId} /></div></ErrorBoundary>;
}
// Pakai: <RoleGate allow={['admin_proyek','pm','owner','finance']}><Equipment projectId={id}/></RoleGate>
