// DrawingsArchive.jsx — Gambar kerja (versi + simpan offline) dan Arsip (proyek selesai + rekap tahunan).
import React, { useCallback, useEffect, useState } from 'react';
import { supabase, useAuth } from './auth.jsx';
import { compressImage } from './imageCompress.js';
import { Button, Card, Skeleton, ErrorBoundary } from './ui.jsx';

const rp = (n) => 'Rp ' + new Intl.NumberFormat('id-ID').format(Math.round(n || 0));
const kb = (n) => (n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.round(n / 1024) + ' KB');
const field = 'w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-slate-900 focus:ring-4 focus:ring-slate-900/10';
const CAT = { shop: 'Shop drawing', as_built: 'As-built', struktur: 'Struktur', arsitektur: 'Arsitektur', mep: 'MEP' };
const CACHE = 'drawings-v1';
const MAX_BYTES = 15 * 1024 * 1024;

// ---------- Akses offline: simpan file di Cache Storage per path (path berbeda tiap versi) ----------
const savedKey = (pid) => `dwg-saved-${pid}`;
const getSaved = (pid) => { try { return new Set(JSON.parse(localStorage.getItem(savedKey(pid)) || '[]')); } catch { return new Set(); } };
async function signed(path) {
  const { data, error } = await supabase.storage.from('drawings').createSignedUrl(path, 300);
  if (error) throw error; return data.signedUrl;
}
async function openVersion(v) {
  // Buka jendela dulu (sinkron dengan ketukan) agar tidak diblokir pop-up blocker di HP, lalu isi alamatnya
  const w = window.open('', '_blank');
  try {
    let url = null;
    if ('caches' in window) {
      const hit = await (await caches.open(CACHE)).match(`/offline/${v.storage_path}`);
      if (hit) url = URL.createObjectURL(await hit.blob());
    }
    if (!url) url = await signed(v.storage_path);
    if (w) w.location.href = url; else window.location.href = url;
  } catch (e) { if (w) w.close(); throw e; }
}
async function saveOffline(pid, v) {
  const res = await fetch(await signed(v.storage_path)); if (!res.ok) throw new Error('Gagal mengunduh');
  const c = await caches.open(CACHE); await c.put(`/offline/${v.storage_path}`, new Response(await res.blob(), { headers: { 'Content-Type': v.mime_type } }));
  const s = getSaved(pid); s.add(v.storage_path); localStorage.setItem(savedKey(pid), JSON.stringify([...s]));
}

function Drawings({ projectId }) {
  const { profile, user } = useAuth();
  const canUpload = ['pm', 'estimator'].includes(profile.role);
  const [rows, setRows] = useState(null);
  const [saved, setSaved] = useState(() => getSaved(projectId));
  const [open, setOpen] = useState(null);
  const [busy, setBusy] = useState('');
  const [msg, setMsg] = useState({ t: '', ok: false });
  const [up, setUp] = useState({ drawing_id: '', code: '', title: '', category: 'shop', note: '', file: null });
  const [loadingUp, setLoadingUp] = useState(false);
  const [viewer, setViewer] = useState(null);

  const load = useCallback(async () => {
    const { data, error } = await supabase.from('drawings')
      .select('id, code, title, category, drawing_versions(id, version, storage_path, mime_type, size_bytes, note, is_current, created_at)')
      .eq('project_id', projectId).order('code');
    if (error) { console.error('[gambar]', error); try { setRows(JSON.parse(localStorage.getItem(`dwg-list-${projectId}`)) || []); } catch { setRows([]); } return setMsg({ t: 'Menampilkan daftar terakhir. Tidak ada sinyal.', ok: false }); }
    data.forEach((d) => d.drawing_versions.sort((a, b) => b.version - a.version));
    setRows(data); try { localStorage.setItem(`dwg-list-${projectId}`, JSON.stringify(data)); } catch { /* abaikan */ }
  }, [projectId]);
  useEffect(() => { load(); }, [load]);

  async function act(key, fn, okText) {
    setBusy(key); setMsg({ t: '', ok: false });
    try { await fn(); if (okText) setMsg({ t: okText, ok: true }); }
    catch (e) { console.error('[gambar aksi]', e); setMsg({ t: 'Gagal. Periksa sinyal, lalu coba lagi.', ok: false }); }
    finally { setBusy(''); }
  }

  // Gambar (PNG/JPG/SVG) dibuka di dalam halaman; PDF dibuka di tab baru
  async function view(v, title) {
    if (!String(v.mime_type).startsWith('image/')) return openVersion(v);
    let url = null;
    try { if ('caches' in window) { const hit = await (await caches.open(CACHE)).match(`/offline/${v.storage_path}`); if (hit) url = URL.createObjectURL(await hit.blob()); } } catch { /* cache tidak tersedia */ }
    if (!url) url = await signed(v.storage_path);
    setViewer({ url, title });
  }

  async function upload(e) {
    e.preventDefault(); setMsg({ t: '', ok: false });
    const f = up.file;
    if (!f) return setMsg({ t: 'Pilih file gambar (PDF, PNG, atau JPG).', ok: false });
    if (!up.drawing_id && (!up.code.trim() || !up.title.trim())) return setMsg({ t: 'Isi kode dan judul gambar baru, atau pilih gambar untuk direvisi.', ok: false });
    if (!navigator.onLine) return setMsg({ t: 'Unggah gambar butuh sinyal.', ok: false });
    setLoadingUp(true); let path = null;
    try {
      let blob = f, mime = f.type, ext = (f.name.split('.').pop() || 'pdf').toLowerCase();
      if (f.type.startsWith('image/')) { const c = await compressImage(f, { maxSide: 3000, maxBytes: 1500 * 1024, startQuality: 0.85 }); blob = c.blob; mime = c.mime; ext = c.ext; }
      else if (f.type !== 'application/pdf') throw new Error('FORMAT');
      if (blob.size > MAX_BYTES) throw new Error('UKURAN');
      let id = up.drawing_id;
      if (!id) { const r = await supabase.rpc('create_drawing', { p_project: projectId, p_code: up.code, p_title: up.title, p_category: up.category }); if (r.error) throw r.error; id = r.data; }
      path = `${projectId}/${id}/${crypto.randomUUID()}.${ext}`;
      const s = await supabase.storage.from('drawings').upload(path, blob, { contentType: mime, cacheControl: '31536000' }); if (s.error) throw s.error;
      const v = await supabase.rpc('register_drawing_version', { p_drawing: id, p_path: path, p_mime: mime, p_size: blob.size, p_note: up.note || null });
      if (v.error) throw v.error;
      setMsg({ t: `Tersimpan sebagai versi ${v.data} (${kb(blob.size)}).`, ok: true });
      setUp({ drawing_id: '', code: '', title: '', category: 'shop', note: '', file: null }); e.target.reset(); load();
    } catch (err) {
      console.error('[unggah gambar]', err);
      if (path) supabase.storage.from('drawings').remove([path]);   // bersihkan file yatim
      setMsg({ t: err.message === 'FORMAT' ? 'Format harus PDF, PNG, atau JPG.' : err.message === 'UKURAN' ? 'Ukuran file maksimal 15 MB.' : err.message || 'Gagal mengunggah.', ok: false });
    } finally { setLoadingUp(false); }
  }

  if (!rows) return <Card><Skeleton className="h-16 w-full" /></Card>;
  return (
    <div className="space-y-3">
      {msg.t && <p role="alert" className={`text-sm ${msg.ok ? 'text-green-700' : 'text-red-700'}`}>{msg.t}</p>}
      {rows.length === 0 && <Card><p className="text-sm text-slate-500">Belum ada gambar kerja.</p></Card>}
      {rows.map((d) => { const cur = d.drawing_versions.find((x) => x.is_current) || d.drawing_versions[0]; if (!cur) return null; const isSaved = saved.has(cur.storage_path);
        return (
          <Card key={d.id} interactive>
            <div className="flex justify-between gap-3"><div className="min-w-0"><p className="font-semibold text-slate-900">{d.code} <span className="font-normal text-slate-500">· {CAT[d.category]}</span></p>
              <p className="truncate text-sm text-slate-600">{d.title}</p></div><span className="whitespace-nowrap text-xs text-slate-500">v{cur.version}</span></div>
            <p className="mt-1 text-xs text-slate-500">{new Date(cur.created_at).toLocaleDateString('id-ID')} · {kb(cur.size_bytes)}{isSaved && <span className="ml-1 text-green-700">· tersimpan offline</span>}</p>
            {cur.note && <p className="mt-1 text-xs text-slate-600">Catatan revisi: {cur.note}</p>}
            <div className="mt-3 flex flex-wrap gap-2">
              <Button size="sm" loading={busy === `o${d.id}`} onClick={() => act(`o${d.id}`, () => view(cur, `${d.code} v${cur.version}`))}>Buka</Button>
              {!isSaved && 'caches' in window && <Button size="sm" variant="secondary" loading={busy === `s${d.id}`} onClick={() => act(`s${d.id}`, async () => { await saveOffline(projectId, cur); setSaved(getSaved(projectId)); }, 'Tersimpan untuk dibuka tanpa sinyal.')}>Simpan offline</Button>}
              {d.drawing_versions.length > 1 && <Button size="sm" variant="ghost" onClick={() => setOpen(open === d.id ? null : d.id)}>Riwayat ({d.drawing_versions.length})</Button>}
            </div>
            {open === d.id && <div className="mt-3 divide-y divide-slate-100 border-t border-slate-100 text-sm">{d.drawing_versions.map((v) => (
              <div key={v.id} className="flex items-center justify-between py-2"><span>v{v.version} · {new Date(v.created_at).toLocaleDateString('id-ID')}{v.is_current && <span className="ml-1 text-xs text-green-700">terbaru</span>}</span>
                <Button size="sm" variant="ghost" onClick={() => act(`v${v.id}`, () => view(v, `${d.code} v${v.version}`))}>Buka</Button></div>))}</div>}
          </Card>); })}
      {viewer && (
        <div className="fixed inset-0 z-40 flex flex-col bg-slate-900/80" role="dialog" aria-modal="true" aria-label={viewer.title}>
          <div className="flex items-center justify-between px-4 py-3 text-white"><p className="text-sm font-medium">{viewer.title}</p><Button size="sm" variant="secondary" onClick={() => setViewer(null)}>Tutup</Button></div>
          <div className="flex-1 overflow-auto p-2"><img src={viewer.url} alt={viewer.title} className="mx-auto max-w-none rounded bg-white" style={{ width: 'min(1100px, 200%)' }} /></div>
        </div>)}
      {canUpload && (
        <Card as="form" onSubmit={upload} className="space-y-2">
          <p className="text-sm font-medium text-slate-900">Unggah gambar atau revisi</p>
          <select className={field} value={up.drawing_id} onChange={(e) => setUp({ ...up, drawing_id: e.target.value })}>
            <option value="">Gambar baru</option>{rows.map((d) => <option key={d.id} value={d.id}>Revisi {d.code} · {d.title}</option>)}</select>
          {!up.drawing_id && (<><div className="grid grid-cols-2 gap-2"><input className={field} placeholder="Kode, mis. ARS-03" value={up.code} onChange={(e) => setUp({ ...up, code: e.target.value })} />
            <select className={field} value={up.category} onChange={(e) => setUp({ ...up, category: e.target.value })}>{Object.entries(CAT).map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></div>
            <input className={field} placeholder="Judul gambar" value={up.title} onChange={(e) => setUp({ ...up, title: e.target.value })} /></>)}
          <input className={field} placeholder="Catatan revisi (opsional)" value={up.note} onChange={(e) => setUp({ ...up, note: e.target.value })} />
          <input className="text-sm" type="file" accept="application/pdf,image/png,image/jpeg" onChange={(e) => setUp({ ...up, file: e.target.files[0] || null })} />
          <Button className="w-full" loading={loadingUp}>Unggah</Button>
        </Card>)}
    </div>
  );
}

function Archive({ onOpen }) {
  const [tab, setTab] = useState('done');
  const [q, setQ] = useState('');
  const [rows, setRows] = useState(null);
  const [year, setYear] = useState(new Date().getFullYear());
  const [sum, setSum] = useState(null);
  const [err, setErr] = useState('');
  const years = Array.from({ length: 6 }, (_, i) => new Date().getFullYear() - i);

  useEffect(() => {
    if (tab !== 'done') return; setRows(null);
    const t = setTimeout(async () => {
      let qq = supabase.from('projects').select('id, name, client_name, status, contract_value, contract_original, end_date').in('status', ['retention', 'closed']).order('end_date', { ascending: false, nullsFirst: false }).limit(30);
      if (q.trim()) qq = qq.or(`name.ilike.%${q.trim().replace(/[%,()]/g, '')}%,client_name.ilike.%${q.trim().replace(/[%,()]/g, '')}%`);
      const { data, error } = await qq; if (error) { console.error('[arsip]', error); setErr('Tidak bisa memuat arsip.'); return setRows([]); }
      setErr(''); setRows(data);
    }, 300);
    return () => clearTimeout(t);
  }, [tab, q]);

  useEffect(() => {
    if (tab !== 'year') return; setSum(null);
    supabase.rpc('yearly_summary', { p_year: year }).then(({ data, error }) => { if (error) { console.error('[rekap tahunan]', error); setErr('Tidak bisa memuat rekap.'); setSum({ projects: [] }); } else { setErr(''); setSum(data); } });
  }, [tab, year]);

  const tot = sum?.projects?.reduce((a, p) => ({ r: a.r + Number(p.revenue), c: a.c + Number(p.cost) }), { r: 0, c: 0 }) || { r: 0, c: 0 };
  return (
    <div className="space-y-3">
      <div className="flex gap-2">{[['done', 'Proyek selesai'], ['year', 'Rekap tahunan']].map(([k, l]) => <Button key={k} size="sm" variant={tab === k ? 'primary' : 'secondary'} onClick={() => setTab(k)}>{l}</Button>)}</div>
      {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
      {tab === 'done' && (<>
        <input className={field} placeholder="Cari nama proyek atau klien" value={q} onChange={(e) => setQ(e.target.value)} />
        {!rows ? <Card><Skeleton className="h-16 w-full" /></Card> : rows.length === 0 ? <Card><p className="text-sm text-slate-500">Tidak ada proyek yang cocok.</p></Card>
          : rows.map((p) => (<Card key={p.id} interactive>
            <div className="flex justify-between gap-3"><div className="min-w-0"><p className="font-semibold text-slate-900">{p.name}</p><p className="truncate text-sm text-slate-500">{p.client_name}</p></div>
              <span className="whitespace-nowrap text-xs text-slate-500">{p.status === 'closed' ? 'Ditutup' : 'Masa retensi'}</span></div>
            <p className="mt-2 text-sm">{rp(p.contract_value)}{p.contract_original && p.contract_original !== p.contract_value && <span className="text-xs text-slate-500"> (semula {rp(p.contract_original)})</span>}</p>
            {p.end_date && <p className="text-xs text-slate-500">Selesai {p.end_date}</p>}
            {onOpen && <Button className="mt-3" size="sm" variant="secondary" onClick={() => onOpen(p.id)}>Buka data proyek</Button>}
          </Card>))}</>)}
      {tab === 'year' && (<>
        <select className={field} value={year} onChange={(e) => setYear(Number(e.target.value))}>{years.map((y) => <option key={y} value={y}>{y}</option>)}</select>
        {!sum ? <Card><Skeleton className="h-16 w-full" /></Card> : (<>
          <div className="grid grid-cols-3 gap-2">{[['Pendapatan', tot.r], ['Biaya', tot.c], ['Selisih', tot.r - tot.c]].map(([l, v]) => (
            <Card key={l} interactive className="p-3"><p className="text-xs text-slate-500">{l}</p><p className={`mt-1 text-sm font-semibold ${v < 0 ? 'text-red-700' : 'text-slate-900'}`}>{rp(v)}</p></Card>))}</div>
          {sum.projects.map((p) => (<Card key={p.id}><div className="flex justify-between gap-2"><p className="font-medium text-slate-900">{p.name}</p><p className={`text-sm font-semibold ${p.revenue - p.cost < 0 ? 'text-red-700' : ''}`}>{rp(p.revenue - p.cost)}</p></div>
            <p className="mt-1 text-xs text-slate-500">Pendapatan {rp(p.revenue)} · Biaya {rp(p.cost)}</p></Card>))}
          {sum.projects.length === 0 && <Card><p className="text-sm text-slate-500">Tidak ada aktivitas keuangan pada {year}.</p></Card>}
          <p className="text-xs text-slate-500">Dasar kas, perkiraan manajemen: pendapatan = DPP invoice klien; biaya = tagihan supplier dibayar, upah disetujui, SPK dibayar, kas keluar disetujui, sewa alat dan BBM. Bukan laporan akuntansi.</p></>)}
      </>)}
    </div>
  );
}

export function DrawingsModule({ projectId }) { return <ErrorBoundary name="gambar-kerja"><div className="mx-auto max-w-md p-4"><Drawings projectId={projectId} /></div></ErrorBoundary>; }
export function ArchiveModule({ onOpen }) { return <ErrorBoundary name="arsip"><div className="mx-auto max-w-md p-4"><Archive onOpen={onOpen} /></div></ErrorBoundary>; }
// Pakai: <RoleGate allow={[...semua]}><DrawingsModule projectId={id}/></RoleGate>
//        <RoleGate allow={['owner','finance','pm']}><ArchiveModule onOpen={setProjectId}/></RoleGate>
