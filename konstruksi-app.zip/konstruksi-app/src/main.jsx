import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import { AuthProvider, AuthGate } from './auth.jsx';
import { installGlobalHandlers } from './logger.js';
import App from './App.jsx';
import { DialogHost } from './dialog.jsx';

installGlobalHandlers();
try {
  import('virtual:pwa-register').then(({ registerSW }) => registerSW({ immediate: true })).catch(() => {});
} catch { /* PWA hanya aktif pada build produksi */ }

createRoot(document.getElementById('root')).render(
  <AuthProvider>
    <AuthGate>
      <App />
      <DialogHost />
    </AuthGate>
  </AuthProvider>
);
