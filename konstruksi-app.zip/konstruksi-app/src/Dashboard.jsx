// Dashboard.jsx — ringkasan eksekutif satu proyek. Satu panggilan RPC, cache lokal untuk offline.
import React, { useCallback, useEffect, useState } from 'react';
import { supabase } from './auth.jsx';
import { Button, Card, Skeleton, ErrorBoundary } from './ui.jsx';

const rp = (n) => 'Rp ' + new Intl.NumberFormat('id-ID').format(Math.round(n || 0));
const pct = (n) => String(Math.round((n || 0) * 10) / 10).replace('.', ',') + '%';

function SCurve({ data }) {
  if (!data.length) return <p className="text-sm text-slate-500">Jadwal rencana belum diisi PM.</p>;
  const W = 320, H = 160, L = 28, B = 22, T = 8, R = 8;
  const x = (i) => L + (data.length === 1 ? 0 : (i / (data.length - 1)) * (W - L - R));
  const y = (v) => T + (1 - v / 100) * (H - T - B);
  const line = (k) => data.map((d, i) => (d[k] == null ? null : `${x(i).toFixed(1)},${y(d[k]).toFixed(1)}`)).filter(Boolean).join(' ');
  const label = (w) => { const d = new Date(w); return `${d.getUTCDate()}/${d.getUTCMonth() + 1}`; };
  const step = Math.ceil(data.length / 5);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="Kurva S rencana dan realisasi">
      {[0, 25, 50, 75, 100].map((v) => (
        <g key={v}><line x1={L} x2={W - R} y1={y(v)} y2={y(v)} stroke="#e2e8f0" strokeWidth="1" />
          <text x={L - 4} y={y(v) + 3} textAnchor="end" fontSize="9" fill="#64748b">{v}</text></g>))}
      {data.map((d, i) => i % step === 0 && (
        <text key={i} x={x(i)} y={H - 6} textAnchor="middle" fontSize="9" fill="#64748b">{label(d.w)}</text>))}
      <polyline points={line('plan')} fill="none" stroke="#94a3b8" strokeWidth="2" strokeDasharray="4 3" />
      <polyline points={line('act')} fill="none" stroke="#0f172a" strokeWidth="2.5" strokeLinejoin="round" />
    </svg>
  );
}

function Body({ projectId }) {
  const [d, setD] = useState(() => { try { return JSON.parse(localStorage.getItem(`dash-${projectId}`)); } catch { return null; } });
  const [stale, setStale] = useState(false);
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    setBusy(true);
    try {
      const { data, error } = await supabase.rpc('dashboard_summary', { p_project: projectId });
      if (error) throw error;
      setD(data); setStale(false);
      try { localStorage.setItem(`dash-${projectId}`, JSON.stringify(data)); } catch { /* penyimpanan penuh, abaikan */ }
    } catch (e) { console.warn('[dashboard]', e); setStale(true); }
    finally { setBusy(false); }
  }, [projectId]);

  useEffect(() => {
    load();
    const vis = () => !document.hidden && load();
    document.addEventListener('visibilitychange', vis);
    return () => document.removeEventListener('visibilitychange', vis);
  }, [load]);

  if (!d) return <div className="space-y-3">{[0, 1, 2].map((i) => <Card key={i}><Skeleton className="h-3 w-24" /><Skeleton className="mt-3 h-7 w-40" /></Card>)}</div>;

  const gap = d.actual_pct - d.planned_pct;
  const gapTxt = gap >= 0 ? `Lebih cepat ${pct(gap)} dari rencana` : `Terlambat ${pct(-gap)} dari rencana`;
  const open = d.po.invoiced - d.po.paid;
  return (
    <div className="space-y-3">
      {stale && <p role="status" className="text-xs text-amber-700">Menampilkan data terakhir. Tidak ada sinyal.</p>}
      <Card interactive>
        <p className="text-sm text-slate-500">Progres fisik</p>
        <div className="mt-1 flex items-baseline gap-2">
          <p className="text-3xl font-semibold tracking-tight text-slate-900">{pct(d.actual_pct)}</p>
          <p className="text-sm text-slate-500">rencana {pct(d.planned_pct)}</p>
        </div>
        <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-slate-100"><div className="h-full bg-slate-900 transition-all duration-500" style={{ width: `${Math.min(100, d.actual_pct)}%` }} /></div>
        <p className={`mt-2 text-xs ${gap < 0 ? 'text-red-700' : 'text-green-700'}`}>{gapTxt}</p>
      </Card>
      <Card><p className="mb-2 text-sm font-medium text-slate-900">Kurva S</p><SCurve data={d.curve} />
        <p className="mt-1 text-xs text-slate-500">Garis putus: rencana. Garis tebal: realisasi (laporan harian yang disetujui).</p></Card>
      <div className="grid grid-cols-2 gap-3">
        <Card interactive><p className="text-xs text-slate-500">Nilai kontrak</p><p className="mt-1 text-base font-semibold text-slate-900">{rp(d.contract_value)}</p></Card>
        <Card interactive><p className="text-xs text-slate-500">Saldo kas kecil</p><p className="mt-1 text-base font-semibold text-slate-900">{rp(d.cash_balance)}</p></Card>
      </div>
      <Card>
        <p className="mb-2 text-sm font-medium text-slate-900">Pengadaan material</p>
        {[['Dipesan', d.po.ordered], ['Diterima', d.po.received], ['Ditagih', d.po.invoiced], ['Dibayar', d.po.paid]].map(([l, v]) => (
          <div key={l} className="flex justify-between border-t border-slate-100 py-2 text-sm first:border-0"><span className="text-slate-500">{l}</span><span className="font-medium">{rp(v)}</span></div>))}
        {open > 0 && <p className="mt-1 text-xs text-slate-500">Tagihan belum dibayar {rp(open)}</p>}
      </Card>
      <Card interactive className={d.pending > 0 ? 'border-amber-200' : ''}>
        <p className="text-sm text-slate-500">Menunggu persetujuan</p>
        <p className="mt-1 text-2xl font-semibold text-slate-900">{d.pending}</p>
      </Card>
      <Button variant="secondary" className="w-full" loading={busy} onClick={load}>Perbarui</Button>
    </div>
  );
}

export default function Dashboard() {
  const [projects, setProjects] = useState(null);
  const [pid, setPid] = useState('');
  useEffect(() => {
    (async () => {
      try {
        const { data, error } = await supabase.from('projects').select('id, name').neq('status', 'closed').order('name');
        if (error) throw error;
        localStorage.setItem('dash-projects', JSON.stringify(data)); setProjects(data); setPid(data[0]?.id || '');
      } catch (e) {
        console.warn('[proyek] cache', e);
        const c = JSON.parse(localStorage.getItem('dash-projects') || '[]'); setProjects(c); setPid(c[0]?.id || '');
      }
    })();
  }, []);
  if (!projects) return <div className="p-4"><Skeleton className="h-10 w-full" /></div>;
  if (!projects.length) return <Card className="m-4"><p className="text-sm text-slate-700">Belum ada proyek.</p></Card>;
  return (
    <ErrorBoundary name="dasbor">
      <div className="mx-auto max-w-md space-y-3 p-4">
        <select value={pid} onChange={(e) => setPid(e.target.value)}
          className="w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 font-medium outline-none focus:border-slate-900 focus:ring-4 focus:ring-slate-900/10">
          {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
        {pid && <Body key={pid} projectId={pid} />}
      </div>
    </ErrorBoundary>
  );
}
// Pakai: <RoleGate allow={['pm','owner','finance','estimator']}><Dashboard/></RoleGate>
