// DailyReportForm.jsx — form nyata: simpan ke antrean lokal dulu, sync otomatis ke Supabase.
import React, { useEffect, useState } from 'react';
import { supabase, useAuth } from './auth.jsx';
import { enqueue } from './offlineQueue.js';
import { compressImage } from './imageCompress.js';
import { Button, Card, Skeleton, ErrorBoundary } from './ui.jsx';

const today = () => new Date().toISOString().slice(0, 10);
const kb = (n) => (n >= 1048576 ? (n / 1048576).toFixed(1) + ' MB' : Math.round(n / 1024) + ' KB');
const field = 'w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-slate-900 focus:ring-4 focus:ring-slate-900/10';

function Form() {
  const { user } = useAuth();
  const [projects, setProjects] = useState(null);
  const [f, setF] = useState({ project_id: '', report_date: today(), weather: 'Cerah', physical_pct: '', notes: '' });
  const [photo, setPhoto] = useState(null);      // { file, info }
  const [msg, setMsg] = useState({ type: '', text: '' });
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  // Daftar proyek: cache lokal agar tetap muncul saat offline
  useEffect(() => {
    (async () => {
      try {
        const { data, error } = await supabase.from('projects').select('id, name').in('status', ['active']);
        if (error) throw error;
        localStorage.setItem('projects-cache', JSON.stringify(data));
        setProjects(data);
        if (data[0]) setF((p) => ({ ...p, project_id: data[0].id }));
      } catch (e) {
        console.warn('[projects] pakai cache', e);
        const c = JSON.parse(localStorage.getItem('projects-cache') || '[]');
        setProjects(c);
        if (c[0]) setF((p) => ({ ...p, project_id: c[0].id }));
      }
    })();
  }, []);

  async function pick(e) {
    const file = e.target.files[0];
    setPhoto(null);
    if (!file) return;
    try {
      const c = await compressImage(file);
      // Simpan hasil kompresi (bukan aslinya) di antrean -> IndexedDB hemat ruang
      setPhoto({ file: new File([c.blob], `foto.${c.ext}`, { type: c.mime }), info: `${kb(c.originalBytes)} menjadi ${kb(c.bytes)}` });
    } catch (err) {
      console.error('[foto]', err);
      setMsg({ type: 'err', text: 'Foto tidak bisa diproses. Coba foto lain.' });
    }
  }

  async function submit(e) {
    e.preventDefault();
    const pct = parseFloat(f.physical_pct);
    if (!f.project_id) return setMsg({ type: 'err', text: 'Pilih proyek.' });
    if (isNaN(pct) || pct < 0 || pct > 100) return setMsg({ type: 'err', text: 'Progres harus 0 sampai 100.' });
    setBusy(true);
    try {
      await enqueue({
        table: 'daily_reports',
        projectId: f.project_id,
        photo: photo?.file,
        row: { project_id: f.project_id, report_date: f.report_date, weather: f.weather,
               physical_pct: pct, notes: f.notes, status: 'submitted', created_by: user.id },
      });
      setMsg({ type: 'ok', text: 'Tersimpan. Akan terkirim otomatis begitu ada sinyal.' });
      setF({ ...f, physical_pct: '', notes: '' });
      setPhoto(null);
      e.target.reset?.();
    } catch (err) {
      console.error('[enqueue]', err);
      setMsg({ type: 'err', text: 'Gagal menyimpan di perangkat. Kosongkan ruang penyimpanan lalu coba lagi.' });
    } finally { setBusy(false); }
  }

  if (!projects) return <Card><Skeleton className="h-5 w-32" /><Skeleton className="mt-4 h-10 w-full" /><Skeleton className="mt-3 h-10 w-full" /></Card>;
  if (!projects.length) return <Card><p className="text-sm text-slate-700">Anda belum ditugaskan ke proyek aktif. Minta PM menambahkan Anda.</p></Card>;

  return (
    <Card as="form" onSubmit={submit} className="space-y-3">
      <select className={field} value={f.project_id} onChange={set('project_id')}>
        {projects.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
      </select>
      <div className="grid grid-cols-2 gap-3">
        <input className={field} type="date" value={f.report_date} onChange={set('report_date')} />
        <select className={field} value={f.weather} onChange={set('weather')}>
          {['Cerah', 'Berawan', 'Hujan ringan', 'Hujan deras'].map((w) => <option key={w}>{w}</option>)}
        </select>
      </div>
      <input className={field} type="number" inputMode="decimal" min="0" max="100" step="0.1" placeholder="Progres fisik (%)" value={f.physical_pct} onChange={set('physical_pct')} />
      <textarea className={field} rows={3} placeholder="Catatan pekerjaan hari ini" value={f.notes} onChange={set('notes')} />
      <input className="text-sm" type="file" accept="image/*" capture="environment" onChange={pick} />
      {photo && <p className="text-sm text-slate-500">Foto {photo.info}</p>}
      {msg.text && <p role="alert" className={`text-sm ${msg.type === 'ok' ? 'text-green-700' : 'text-red-700'}`}>{msg.text}</p>}
      <Button size="lg" className="w-full" loading={busy}>Simpan laporan</Button>
    </Card>
  );
}

export default function DailyReportForm() {
  return <ErrorBoundary name="laporan-harian"><Form /></ErrorBoundary>;
}

// Pemakaian di App.jsx:
// <AuthProvider><AuthGate><RoleGate allow={['mandor','pm']}><DailyReportForm/></RoleGate></AuthGate></AuthProvider>
