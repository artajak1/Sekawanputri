// Handover.jsx — punch list (offline), validasi PM, serah terima, retensi.
import React, { useCallback, useEffect, useState } from 'react';
import { supabase, useAuth } from './auth.jsx';
import { enqueue } from './offlineQueue.js';
import { askText } from './dialog.jsx';
import { compressImage } from './imageCompress.js';
import { Button, Card, Skeleton, ErrorBoundary } from './ui.jsx';

const rp = (n) => 'Rp ' + new Intl.NumberFormat('id-ID').format(Math.round(n || 0));
const field = 'w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-slate-900 focus:ring-4 focus:ring-slate-900/10';
const SL = { open: ['Open', 'text-amber-700'], fixed: ['Fixed, menunggu validasi', 'text-sky-700'], verified: ['Terverifikasi', 'text-green-700'] };

async function toFile(e, name, onErr) {
  const f = e.target.files[0]; if (!f) return null;
  try { const c = await compressImage(f); return new File([c.blob], `${name}.${c.ext}`, { type: c.mime }); }
  catch (err) { console.error('[foto]', err); onErr('Foto tidak bisa diproses.'); return null; }
}

function Punch({ projectId, role, rows, reload }) {
  const { user } = useAuth();
  const [f, setF] = useState({ title: '', location: '' });
  const [photo, setPhoto] = useState(null);
  const [fixing, setFixing] = useState(null);       // { id, note, photo }
  const [msg, setMsg] = useState({ t: '', ok: false });
  const [filter, setFilter] = useState('open');
  const can = ['mandor', 'admin_proyek', 'pm'].includes(role);

  async function add(e) {
    e.preventDefault();
    if (!f.title.trim()) return setMsg({ t: 'Isi uraian cacat.', ok: false });
    try {
      await enqueue({ table: 'punch_items', projectId, photo, row: { project_id: projectId, title: f.title.trim(), location: f.location.trim() || null, created_by: user.id } });
      setMsg({ t: 'Tersimpan. Terkirim otomatis saat ada sinyal.', ok: true }); setF({ title: '', location: '' }); setPhoto(null); e.target.reset(); setTimeout(reload, 1500);
    } catch (err) { console.error('[punch]', err); setMsg({ t: 'Gagal menyimpan di perangkat.', ok: false }); }
  }
  async function submitFix() {
    try {
      await enqueue({ table: 'punch_fixes', projectId, photo: fixing.photo, row: { punch_id: fixing.id, note: fixing.note || null, created_by: user.id } });
      setFixing(null); setMsg({ t: 'Perbaikan dicatat. Terkirim otomatis saat ada sinyal.', ok: true }); setTimeout(reload, 1500);
    } catch (err) { console.error('[fix]', err); setMsg({ t: 'Gagal menyimpan di perangkat.', ok: false }); }
  }
  async function verify(id, ok) {
    const note = ok ? null : (await askText('Apa yang masih kurang?')) || null;
    const { error } = await supabase.rpc('verify_punch', { p_id: id, p_ok: ok, p_note: note });
    if (error) { console.error('[verify]', error); setMsg({ t: error.message, ok: false }); } else reload();
  }

  const shown = rows.filter((r) => r.status === filter);
  const cnt = (s) => rows.filter((r) => r.status === s).length;
  return (
    <div className="space-y-3">
      <div className="flex gap-2 overflow-x-auto">{['open', 'fixed', 'verified'].map((s) => (
        <Button key={s} size="sm" variant={filter === s ? 'primary' : 'secondary'} onClick={() => setFilter(s)}>{SL[s][0].split(',')[0]} ({cnt(s)})</Button>))}</div>
      {msg.t && <p role="alert" className={`text-sm ${msg.ok ? 'text-green-700' : 'text-red-700'}`}>{msg.t}</p>}
      {shown.length === 0 && <Card><p className="text-sm text-slate-500">Tidak ada item.</p></Card>}
      {shown.map((r) => (
        <Card key={r.id} interactive>
          <p className="font-medium text-slate-900">{r.title}</p>
          <p className="text-xs text-slate-500">{r.location || 'Lokasi belum diisi'}</p>
          <p className={`mt-1 text-xs ${SL[r.status][1]}`}>{SL[r.status][0]}</p>
          {r.verify_note && r.status === 'open' && <p className="mt-1 text-xs text-red-700">PM: {r.verify_note}</p>}
          {r.status === 'open' && can && fixing?.id !== r.id && <Button className="mt-3" size="sm" variant="secondary" onClick={() => setFixing({ id: r.id, note: '', photo: null })}>Tandai selesai</Button>}
          {fixing?.id === r.id && (
            <div className="mt-3 space-y-2">
              <input className={field} placeholder="Catatan perbaikan (opsional)" value={fixing.note} onChange={(e) => setFixing({ ...fixing, note: e.target.value })} />
              <input className="text-sm" type="file" accept="image/*" capture="environment" onChange={async (e) => setFixing({ ...fixing, photo: await toFile(e, 'perbaikan', (t) => setMsg({ t, ok: false })) })} />
              <div className="flex gap-2"><Button size="sm" onClick={submitFix}>Kirim</Button><Button size="sm" variant="ghost" onClick={() => setFixing(null)}>Batal</Button></div>
            </div>)}
          {r.status === 'fixed' && role === 'pm' && (
            <div className="mt-3 flex gap-2"><Button size="sm" onClick={() => verify(r.id, true)}>Validasi</Button><Button size="sm" variant="danger" onClick={() => verify(r.id, false)}>Kembalikan</Button></div>)}
        </Card>))}
      {can && (
        <Card as="form" onSubmit={add} className="space-y-2">
          <input className={field} placeholder="Uraian cacat, mis. Retak dinding kamar mandi" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
          <input className={field} placeholder="Lokasi, mis. Lantai 2 ruang B" value={f.location} onChange={(e) => setF({ ...f, location: e.target.value })} />
          <input className="text-sm" type="file" accept="image/*" capture="environment" onChange={async (e) => setPhoto(await toFile(e, 'punch', (t) => setMsg({ t, ok: false })))} />
          <Button className="w-full">Catat cacat</Button>
        </Card>)}
    </div>
  );
}

function Handover({ projectId, role, rows }) {
  const [ho, setHo] = useState(undefined);
  const [rc, setRc] = useState(null);
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState(false);

  const load = useCallback(async () => {
    const [h, r] = await Promise.all([
      supabase.from('handovers').select('handover_date').eq('project_id', projectId).maybeSingle(),
      supabase.from('retention_claims').select('amount, due_date, status').eq('project_id', projectId).maybeSingle()]);
    setHo(h.data); setRc(r.data);
  }, [projectId]);
  useEffect(() => { load(); }, [load]);

  async function call(fn, args) {
    setBusy(true); setErr('');
    const { error } = await supabase.rpc(fn, args);
    if (error) { console.error(`[${fn}]`, error); setErr(error.message); }
    await load(); setBusy(false);
  }
  if (ho === undefined) return <Card><Skeleton className="h-16 w-full" /></Card>;

  const pending = rows.filter((r) => r.status !== 'verified').length;
  const days = rc ? Math.ceil((new Date(rc.due_date) - new Date(new Date().toDateString())) / 86400000) : null;
  return (
    <div className="space-y-3">
      <Card>
        <p className="text-sm text-slate-500">Syarat serah terima</p>
        <p className="mt-1 font-semibold text-slate-900">{pending === 0 ? 'Semua punch list terverifikasi' : `${pending} punch list belum terverifikasi`}</p>
        {ho ? <p className="mt-2 text-sm text-green-700">Diserahterimakan {ho.handover_date}</p>
          : role === 'pm' && <Button className="mt-3" disabled={pending > 0} loading={busy} onClick={() => call('complete_handover', { p_project: projectId })}>Selesaikan serah terima</Button>}
      </Card>
      {rc && (
        <Card interactive>
          <p className="text-sm text-slate-500">Retensi tertahan</p>
          <p className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">{rp(rc.amount)}</p>
          <p className="mt-1 text-sm text-slate-500">Jatuh tempo {rc.due_date}</p>
          <p className={`mt-1 text-xs ${rc.status === 'released' ? 'text-green-700' : days <= 14 ? 'text-amber-700' : 'text-slate-500'}`}>
            {rc.status === 'released' ? 'Sudah dicairkan' : days > 0 ? `${days} hari lagi` : 'Sudah jatuh tempo'}</p>
          {role === 'finance' && rc.status === 'held' && <Button className="mt-3" size="sm" variant="secondary" loading={busy} onClick={() => call('release_retention', { p_project: projectId })}>Tandai retensi diterima</Button>}
        </Card>)}
      {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
    </div>
  );
}

export default function HandoverModule({ projectId }) {
  const { profile } = useAuth();
  const [rows, setRows] = useState(null);
  const [tab, setTab] = useState('punch');
  const reload = useCallback(async () => {
    const { data, error } = await supabase.from('punch_items').select('id, title, location, status, verify_note').eq('project_id', projectId).order('created_at', { ascending: false }).limit(200);
    if (error) return console.error('[punch load]', error);
    setRows(data); try { localStorage.setItem(`punch-${projectId}`, JSON.stringify(data)); } catch { /* abaikan */ }
  }, [projectId]);
  useEffect(() => { try { setRows(JSON.parse(localStorage.getItem(`punch-${projectId}`))); } catch { /* abaikan */ } reload(); }, [projectId, reload]);

  return (
    <ErrorBoundary name="serah-terima">
      <div className="mx-auto max-w-md space-y-3 p-4">
        <div className="flex gap-2">{[['punch', 'Punch list'], ['ho', 'Serah terima dan retensi']].map(([k, l]) => (
          <Button key={k} size="sm" variant={tab === k ? 'primary' : 'secondary'} onClick={() => setTab(k)}>{l}</Button>))}</div>
        {!rows ? <Card><Skeleton className="h-16 w-full" /></Card>
          : tab === 'punch' ? <Punch projectId={projectId} role={profile.role} rows={rows} reload={reload} />
          : <Handover projectId={projectId} role={profile.role} rows={rows} />}
      </div>
    </ErrorBoundary>
  );
}
// Pakai: <RoleGate allow={['mandor','admin_proyek','pm','finance','owner']}><HandoverModule projectId={id}/></RoleGate>
