// Finance.jsx — ringkasan keuangan, termin klien + invoice (PPN/PPh Final/retensi), tagihan supplier + bayar.
import React, { useCallback, useEffect, useState } from 'react';
import { supabase, useAuth } from './auth.jsx';
import { enqueue } from './offlineQueue.js';
import { compressImage } from './imageCompress.js';
import { Button, Card, Skeleton, ErrorBoundary } from './ui.jsx';

const rp = (n) => 'Rp ' + new Intl.NumberFormat('id-ID').format(Math.round(n || 0));
const field = 'w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-slate-900 focus:ring-4 focus:ring-slate-900/10';
const TS = { planned: ['Belum ditagih', 'text-slate-500'], invoiced: ['Sudah ditagih', 'text-amber-700'], paid: ['Lunas', 'text-green-700'] };

function Summary({ projectId }) {
  const [s, setS] = useState(null);
  useEffect(() => { supabase.rpc('finance_summary', { p_project: projectId }).then(({ data, error }) => {
    if (error) console.error('[finance_summary]', error); else setS(data); }); }, [projectId]);
  if (!s) return <Card><Skeleton className="h-4 w-24" /><Skeleton className="mt-3 h-7 w-40" /></Card>;
  const cells = [['Piutang klien (bersih)', s.receivable], ['Retensi tertahan', s.retention_held], ['Hutang supplier', s.payable],
    ['Termin belum ditagih (DPP)', s.terms_planned], ['PPN keluaran', s.ppn_out], ['PPh Final dipotong klien', s.pph_final]];
  return <div className="grid grid-cols-2 gap-3">{cells.map(([l, v]) => (
    <Card key={l} interactive><p className="text-xs text-slate-500">{l}</p><p className="mt-1 text-base font-semibold text-slate-900">{rp(v)}</p></Card>))}</div>;
}

function Terms({ projectId, role }) {
  const { user } = useAuth();
  const [terms, setTerms] = useState(null);
  const [inv, setInv] = useState({});
  const [contract, setContract] = useState(0);
  const [f, setF] = useState({ description: '', pct: '' });
  const [err, setErr] = useState('');
  const [busy, setBusy] = useState('');

  const load = useCallback(async () => {
    const [t, i, p] = await Promise.all([
      supabase.from('client_terms').select('id, term_no, description, pct, amount, status').eq('project_id', projectId).order('term_no'),
      supabase.from('client_invoices').select('id, term_id, invoice_no, dpp, ppn_amount, pph_amount, retention_amount, net_receivable, status').eq('project_id', projectId),
      supabase.from('projects').select('contract_value').eq('id', projectId).single(),
    ]);
    if (t.error) { console.error('[termin]', t.error); return setErr('Tidak bisa memuat termin.'); }
    setTerms(t.data); setInv(Object.fromEntries((i.data || []).map((x) => [x.term_id, x]))); setContract(p.data?.contract_value || 0);
  }, [projectId]);
  useEffect(() => { load(); }, [load]);

  async function run(key, fn, args) {
    setBusy(key); setErr('');
    const { error } = await supabase.rpc(fn, args);
    if (error) { console.error(`[${fn}]`, error); setErr(error.message); }
    await load(); setBusy('');
  }
  async function add(e) {
    e.preventDefault(); setErr('');
    const pct = Number(f.pct);
    if (!f.description.trim() || !(pct > 0 && pct <= 100)) return setErr('Isi uraian dan persentase 1 sampai 100.');
    const { error } = await supabase.from('client_terms').insert({
      client_id: crypto.randomUUID(), project_id: projectId, term_no: (terms.at(-1)?.term_no || 0) + 1,
      description: f.description.trim(), pct, amount: Math.round((contract * pct) / 100), created_by: user.id });
    if (error) { console.error('[termin baru]', error); return setErr('Gagal menambah termin. Pastikan total persentase tidak melebihi 100.'); }
    setF({ description: '', pct: '' }); load();
  }

  if (!terms) return <Card><Skeleton className="h-16 w-full" /></Card>;
  const canEdit = ['pm', 'finance'].includes(role);
  return (
    <div className="space-y-3">
      {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
      {terms.map((t) => { const i = inv[t.id]; return (
        <Card key={t.id} interactive>
          <div className="flex justify-between gap-3"><div><p className="font-semibold text-slate-900">Termin {t.term_no} · {t.pct}%</p>
            <p className="text-sm text-slate-500">{t.description}</p></div><p className="font-semibold">{rp(t.amount)}</p></div>
          <p className={`mt-1 text-xs ${TS[t.status][1]}`}>{TS[t.status][0]}{i && ` · ${i.invoice_no}`}</p>
          {i && (<div className="mt-3 space-y-1 border-t border-slate-100 pt-3 text-sm">
            {[['DPP', i.dpp], ['PPN', i.ppn_amount], ['PPh Final dipotong', -i.pph_amount], ['Retensi ditahan', -i.retention_amount]].map(([l, v]) => (
              <div key={l} className="flex justify-between"><span className="text-slate-500">{l}</span><span>{v < 0 ? '−' : ''}{rp(Math.abs(v))}</span></div>))}
            <div className="flex justify-between font-semibold"><span>Diterima bersih</span><span>{rp(i.net_receivable)}</span></div></div>)}
          {role === 'finance' && t.status === 'planned' && <Button className="mt-3" size="sm" loading={busy === t.id} onClick={() => run(t.id, 'issue_client_invoice', { p_term: t.id })}>Terbitkan invoice</Button>}
          {role === 'finance' && i?.status === 'issued' && <Button className="mt-3" size="sm" variant="secondary" loading={busy === i.id} onClick={() => run(i.id, 'mark_client_invoice_paid', { p_invoice: i.id })}>Tandai lunas</Button>}
        </Card>); })}
      {canEdit && (
        <Card as="form" onSubmit={add} className="space-y-2">
          <input className={field} placeholder="Uraian, mis. Uang muka" value={f.description} onChange={(e) => setF({ ...f, description: e.target.value })} />
          <input className={field} inputMode="decimal" placeholder="Persentase dari nilai kontrak" value={f.pct} onChange={(e) => setF({ ...f, pct: e.target.value })} />
          {Number(f.pct) > 0 && <p className="text-xs text-slate-500">DPP termin: {rp((contract * Number(f.pct)) / 100)}</p>}
          <Button className="w-full">Tambah termin</Button>
        </Card>)}
    </div>
  );
}

function Payables({ projectId, role }) {
  const { user } = useAuth();
  const [rows, setRows] = useState(null);
  const [pos, setPos] = useState([]);
  const [lim, setLim] = useState(25000000);
  const [f, setF] = useState({ po_id: '', invoice_no: '', amount: '' });
  const [photo, setPhoto] = useState(null);
  const [msg, setMsg] = useState({ t: '', ok: false });
  const [busy, setBusy] = useState('');

  const load = useCallback(async () => {
    const [a, b, c] = await Promise.all([
      supabase.from('supplier_invoices').select('id, invoice_no, amount, status, owner_approved, purchase_orders!inner(po_number, project_id)')
        .eq('purchase_orders.project_id', projectId).order('invoice_date', { ascending: false }).limit(20),
      supabase.from('purchase_orders').select('id, po_number').eq('project_id', projectId).in('status', ['approved', 'partial', 'received']),
      supabase.from('app_settings').select('value').eq('key', 'pay_owner_min').maybeSingle(),
    ]);
    if (a.error) { console.error('[tagihan]', a.error); return setMsg({ t: 'Tidak bisa memuat tagihan.', ok: false }); }
    setRows(a.data); setPos(b.data || []); if (c.data) setLim(Number(c.data.value));
    setF((x) => ({ ...x, po_id: x.po_id || b.data?.[0]?.id || '' }));
  }, [projectId]);
  useEffect(() => { load(); }, [load]);

  async function rpc(id, fn) {
    setBusy(id); setMsg({ t: '', ok: false });
    const { error } = await supabase.rpc(fn, { p_invoice: id });
    if (error) { console.error(`[${fn}]`, error); setMsg({ t: error.message, ok: false }); }
    await load(); setBusy('');
  }
  async function pick(e) {
    const file = e.target.files[0]; setPhoto(null); if (!file) return;
    try { const c = await compressImage(file); setPhoto(new File([c.blob], `tagihan.${c.ext}`, { type: c.mime })); }
    catch (err) { console.error('[foto tagihan]', err); setMsg({ t: 'Foto tidak bisa diproses.', ok: false }); }
  }
  async function add(e) {
    e.preventDefault();
    const amount = Number(String(f.amount).replace(/\D/g, ''));
    if (!f.po_id || !f.invoice_no.trim() || !amount) return setMsg({ t: 'Lengkapi PO, nomor tagihan, dan jumlah.', ok: false });
    try {
      await enqueue({ table: 'supplier_invoices', projectId, photo, row: { po_id: f.po_id, invoice_no: f.invoice_no.trim(), amount, created_by: user.id } });
      setMsg({ t: 'Tagihan tersimpan. Terkirim otomatis saat ada sinyal.', ok: true });
      setF({ ...f, invoice_no: '', amount: '' }); setPhoto(null); e.target.reset(); setTimeout(load, 1500);
    } catch (err) { console.error('[tagihan baru]', err); setMsg({ t: 'Gagal menyimpan di perangkat.', ok: false }); }
  }

  if (!rows) return <Card><Skeleton className="h-16 w-full" /></Card>;
  return (
    <div className="space-y-3">
      {msg.t && <p role="alert" className={`text-sm ${msg.ok ? 'text-green-700' : 'text-red-700'}`}>{msg.t}</p>}
      {rows.length === 0 && <Card><p className="text-sm text-slate-500">Belum ada tagihan supplier.</p></Card>}
      {rows.map((r) => { const big = r.amount >= lim; return (
        <Card key={r.id} interactive>
          <div className="flex justify-between gap-3"><div><p className="font-semibold text-slate-900">{r.invoice_no}</p>
            <p className="text-sm text-slate-500">{r.purchase_orders.po_number}</p></div><p className="font-semibold">{rp(r.amount)}</p></div>
          <p className={`mt-1 text-xs ${r.status === 'paid' ? 'text-green-700' : 'text-amber-700'}`}>
            {r.status === 'paid' ? 'Dibayar' : big && !r.owner_approved ? 'Menunggu persetujuan owner' : 'Siap dibayar'}</p>
          {r.status === 'unpaid' && role === 'owner' && big && !r.owner_approved && <Button className="mt-3" size="sm" loading={busy === r.id} onClick={() => rpc(r.id, 'approve_invoice_payment')}>Setujui pembayaran</Button>}
          {r.status === 'unpaid' && role === 'finance' && <Button className="mt-3" size="sm" loading={busy === r.id} onClick={() => rpc(r.id, 'pay_invoice')}>Bayar</Button>}
        </Card>); })}
      {['admin_proyek', 'finance'].includes(role) && pos.length > 0 && (
        <Card as="form" onSubmit={add} className="space-y-2">
          <select className={field} value={f.po_id} onChange={(e) => setF({ ...f, po_id: e.target.value })}>{pos.map((p) => <option key={p.id} value={p.id}>{p.po_number}</option>)}</select>
          <input className={field} placeholder="Nomor tagihan supplier" value={f.invoice_no} onChange={(e) => setF({ ...f, invoice_no: e.target.value })} />
          <input className={field} inputMode="numeric" placeholder="Jumlah tagihan (Rp)" value={f.amount} onChange={(e) => setF({ ...f, amount: e.target.value })} />
          <input className="text-sm" type="file" accept="image/*" capture="environment" onChange={pick} />
          <Button className="w-full">Catat tagihan</Button>
        </Card>)}
    </div>
  );
}

export default function Finance({ projectId }) {
  const { profile } = useAuth();
  const [tab, setTab] = useState('sum');
  const tabs = [['sum', 'Ringkasan'], ['terms', 'Termin klien'], ['pay', 'Tagihan supplier']];
  return (
    <ErrorBoundary name="keuangan">
      <div className="mx-auto max-w-md space-y-3 p-4">
        <div className="flex gap-2 overflow-x-auto">{tabs.map(([k, l]) => (
          <Button key={k} size="sm" variant={tab === k ? 'primary' : 'secondary'} onClick={() => setTab(k)}>{l}</Button>))}</div>
        {tab === 'sum' && <Summary projectId={projectId} />}
        {tab === 'terms' && <Terms projectId={projectId} role={profile.role} />}
        {tab === 'pay' && <Payables projectId={projectId} role={profile.role} />}
      </div>
    </ErrorBoundary>
  );
}
// Pakai: <RoleGate allow={['finance','owner','pm']}><Finance projectId={id}/></RoleGate>
// Catatan: tab Tagihan supplier tidak untuk PM (policy tagihan hanya admin_proyek/pm/finance/owner baca; PM hanya membaca).
