// SubconAddendum.jsx — SPK subkontraktor (progres + pembayaran terkontrol) dan Adendum tambah/kurang.
import React, { useCallback, useEffect, useState } from 'react';
import { supabase, useAuth } from './auth.jsx';
import { enqueue } from './offlineQueue.js';
import { Button, Card, Skeleton, ErrorBoundary } from './ui.jsx';

const rp = (n) => 'Rp ' + new Intl.NumberFormat('id-ID').format(Math.round(n || 0));
const field = 'w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-slate-900 focus:ring-4 focus:ring-slate-900/10';
const ST = { submitted: ['Menunggu persetujuan', 'text-amber-700'], approved: ['Disetujui', 'text-green-700'], rejected: ['Ditolak', 'text-red-700'] };

// Ambil status approval per dokumen agar tombol hanya muncul untuk level yang tepat
async function loadApprovals(projectId, table) {
  const { data } = await supabase.from('approvals').select('ref_id, level, status').eq('project_id', projectId).eq('ref_table', table);
  const m = {}; (data || []).forEach((x) => { (m[x.ref_id] ||= {})[x.level] = x.status; }); return m;
}
function DecideButtons({ table, id, appr, role, status, onDone, setErr }) {
  const level = role === 'pm' ? 1 : role === 'owner' ? 2 : 0;
  if (!level || status !== 'submitted' || appr?.[level] !== 'submitted' || (level === 2 && appr[1] !== 'approved')) return null;
  const go = async (ok) => {
    const { error } = await supabase.rpc('decide_doc', { p_table: table, p_id: id, p_level: level, p_approve: ok });
    if (error) { console.error('[decide_doc]', error); setErr(error.message); } else onDone();
  };
  return <div className="mt-3 flex gap-2"><Button size="sm" onClick={() => go(true)}>Setujui</Button><Button size="sm" variant="danger" onClick={() => go(false)}>Tolak</Button></div>;
}

function Spk({ projectId, role }) {
  const { user } = useAuth();
  const [rows, setRows] = useState(null);
  const [appr, setAppr] = useState({});
  const [subs, setSubs] = useState([]);
  const [f, setF] = useState({ subcon_id: '', title: '', contract_value: '', newSub: '' });
  const [inp, setInp] = useState({});
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    const [a, s, ap] = await Promise.all([
      supabase.from('spk_summary').select('*').eq('project_id', projectId).order('spk_number', { ascending: false }),
      supabase.from('subcontractors').select('id, name').eq('is_active', true).order('name'),
      loadApprovals(projectId, 'spk')]);
    if (a.error) { console.error('[spk]', a.error); return setErr('Tidak bisa memuat SPK.'); }
    setRows(a.data); setSubs(s.data || []); setAppr(ap);
    setF((x) => ({ ...x, subcon_id: x.subcon_id || s.data?.[0]?.id || '' }));
  }, [projectId]);
  useEffect(() => { load(); }, [load]);

  async function rpc(fn, args) {
    setErr(''); const { error } = await supabase.rpc(fn, args);
    if (error) { console.error(`[${fn}]`, error); setErr(error.message); } else { setInp({}); load(); }
  }
  async function addSub() {
    if (!f.newSub.trim()) return;
    const { error } = await supabase.from('subcontractors').insert({ name: f.newSub.trim() });
    if (error) { console.error('[subkon]', error); return setErr('Gagal menambah subkon.'); }
    setF({ ...f, newSub: '' }); load();
  }
  async function create(e) {
    e.preventDefault(); setErr('');
    const v = Number(String(f.contract_value).replace(/\D/g, ''));
    if (!f.subcon_id || !f.title.trim() || !v) return setErr('Lengkapi subkon, pekerjaan, dan nilai borongan.');
    try {
      await enqueue({ table: 'spk', projectId, row: { project_id: projectId, subcon_id: f.subcon_id, title: f.title.trim(), contract_value: v, created_by: user.id } });
      setF({ ...f, title: '', contract_value: '' }); setTimeout(load, 1500);
    } catch (e2) { console.error('[spk baru]', e2); setErr('Gagal menyimpan di perangkat.'); }
  }

  if (!rows) return <Card><Skeleton className="h-16 w-full" /></Card>;
  return (
    <div className="space-y-3">
      {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
      {rows.length === 0 && <Card><p className="text-sm text-slate-500">Belum ada SPK.</p></Card>}
      {rows.map((r) => {
        const earned = (r.contract_value * r.progress_pct) / 100, allowed = Math.max(0, earned - r.paid);
        return (
          <Card key={r.id} interactive>
            <div className="flex justify-between gap-3"><div><p className="font-semibold text-slate-900">{r.spk_number}</p>
              <p className="text-sm text-slate-500">{r.subcon} · {r.title}</p></div><p className="font-semibold">{rp(r.contract_value)}</p></div>
            <p className={`mt-1 text-xs ${ST[r.status][1]}`}>{ST[r.status][0]}</p>
            {r.status === 'approved' && (<>
              <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-slate-100"><div className="h-full bg-slate-900 transition-all duration-500" style={{ width: `${r.progress_pct}%` }} /></div>
              <p className="mt-2 text-xs text-slate-500">Progres {String(r.progress_pct).replace('.', ',')}% · dibayar {rp(r.paid)} · bisa dibayar {rp(allowed)}</p>
              {role === 'pm' && <div className="mt-2 flex gap-2"><input className={`${field} !w-28`} inputMode="decimal" placeholder="Progres %" value={inp[`p${r.id}`] || ''} onChange={(e) => setInp({ ...inp, [`p${r.id}`]: e.target.value })} />
                <Button size="sm" variant="secondary" onClick={() => rpc('set_spk_progress', { p_spk: r.id, p_pct: Number(inp[`p${r.id}`]) })}>Catat progres</Button></div>}
              {role === 'finance' && <div className="mt-2 flex gap-2"><input className={`${field} !w-40`} inputMode="numeric" placeholder="Jumlah bayar (Rp)" value={inp[`b${r.id}`] || ''} onChange={(e) => setInp({ ...inp, [`b${r.id}`]: e.target.value })} />
                <Button size="sm" onClick={() => rpc('pay_spk', { p_spk: r.id, p_amount: Number(String(inp[`b${r.id}`] || '').replace(/\D/g, '')) })}>Bayar termin</Button></div>}
            </>)}
            <DecideButtons table="spk" id={r.id} appr={appr[r.id]} role={role} status={r.status} onDone={load} setErr={setErr} />
          </Card>); })}
      {role === 'pm' && (
        <Card as="form" onSubmit={create} className="space-y-2">
          <select className={field} value={f.subcon_id} onChange={(e) => setF({ ...f, subcon_id: e.target.value })}>
            {subs.length === 0 && <option value="">Belum ada subkon</option>}{subs.map((s) => <option key={s.id} value={s.id}>{s.name}</option>)}</select>
          <div className="flex gap-2"><input className={field} placeholder="Subkon baru" value={f.newSub} onChange={(e) => setF({ ...f, newSub: e.target.value })} />
            <Button type="button" variant="secondary" onClick={addSub}>Tambah</Button></div>
          <input className={field} placeholder="Pekerjaan, mis. Pasang keramik lantai 1" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
          <input className={field} inputMode="numeric" placeholder="Nilai borongan (Rp)" value={f.contract_value} onChange={(e) => setF({ ...f, contract_value: e.target.value })} />
          <Button className="w-full">Ajukan SPK</Button>
        </Card>)}
    </div>
  );
}

function Addenda({ projectId, role }) {
  const { user } = useAuth();
  const [rows, setRows] = useState(null);
  const [appr, setAppr] = useState({});
  const [f, setF] = useState({ title: '', reason: '' });
  const blank = { type: 'tambah', description: '', unit: 'm2', qty: '', unit_price: '' };
  const [items, setItems] = useState([blank]);
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    const [a, ap] = await Promise.all([
      supabase.from('addenda').select('id, number, title, delta, status').eq('project_id', projectId).order('created_at', { ascending: false }).limit(20),
      loadApprovals(projectId, 'addenda')]);
    if (a.error) { console.error('[adendum]', a.error); return setErr('Tidak bisa memuat adendum.'); }
    setRows(a.data); setAppr(ap);
  }, [projectId]);
  useEffect(() => { load(); }, [load]);

  const upd = (i, k) => (e) => setItems(items.map((x, j) => (j === i ? { ...x, [k]: e.target.value } : x)));
  const delta = items.reduce((s, x) => s + (x.type === 'tambah' ? 1 : -1) * (Number(x.qty) || 0) * (Number(x.unit_price) || 0), 0);

  async function create(e) {
    e.preventDefault(); setErr('');
    const clean = items.filter((x) => x.description.trim() || x.qty).map((x) => ({ type: x.type, description: x.description.trim(), unit: x.unit || 'unit', qty: Number(x.qty), unit_price: Number(x.unit_price) || 0 }));
    if (!f.title.trim() || !clean.length || clean.some((x) => !x.description || !(x.qty > 0))) return setErr('Lengkapi judul dan setiap item.');
    try {
      await enqueue({ table: 'addenda', projectId, row: { project_id: projectId, title: f.title.trim(), reason: f.reason.trim() || null, items: clean, created_by: user.id } });
      setF({ title: '', reason: '' }); setItems([blank]); setTimeout(load, 1500);
    } catch (e2) { console.error('[adendum baru]', e2); setErr('Gagal menyimpan di perangkat.'); }
  }

  if (!rows) return <Card><Skeleton className="h-16 w-full" /></Card>;
  return (
    <div className="space-y-3">
      {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
      {rows.map((r) => (
        <Card key={r.id} interactive>
          <div className="flex justify-between gap-3"><div><p className="font-semibold text-slate-900">{r.number}</p><p className="text-sm text-slate-500">{r.title}</p></div>
            <p className={`font-semibold ${r.delta < 0 ? 'text-red-700' : 'text-slate-900'}`}>{r.delta < 0 ? '−' : '+'}{rp(Math.abs(r.delta))}</p></div>
          <p className={`mt-1 text-xs ${ST[r.status][1]}`}>{ST[r.status][0]}</p>
          <DecideButtons table="addenda" id={r.id} appr={appr[r.id]} role={role} status={r.status} onDone={load} setErr={setErr} />
        </Card>))}
      {['estimator', 'pm'].includes(role) && (
        <Card as="form" onSubmit={create} className="space-y-2">
          <input className={field} placeholder="Judul adendum" value={f.title} onChange={(e) => setF({ ...f, title: e.target.value })} />
          <input className={field} placeholder="Alasan perubahan" value={f.reason} onChange={(e) => setF({ ...f, reason: e.target.value })} />
          {items.map((x, i) => (
            <div key={i} className="space-y-2 rounded-lg border border-slate-100 p-3">
              <div className="grid grid-cols-2 gap-2">{['tambah', 'kurang'].map((t) => (
                <Button key={t} type="button" size="sm" variant={x.type === t ? 'primary' : 'secondary'} onClick={() => setItems(items.map((y, j) => (j === i ? { ...y, type: t } : y)))}>{t === 'tambah' ? 'Tambah' : 'Kurang'}</Button>))}</div>
              <input className={field} placeholder="Uraian pekerjaan" value={x.description} onChange={upd(i, 'description')} />
              <div className="grid grid-cols-3 gap-2"><input className={field} inputMode="decimal" placeholder="Volume" value={x.qty} onChange={upd(i, 'qty')} />
                <input className={field} placeholder="Satuan" value={x.unit} onChange={upd(i, 'unit')} /><input className={field} inputMode="numeric" placeholder="Harga satuan" value={x.unit_price} onChange={upd(i, 'unit_price')} /></div>
            </div>))}
          <Button type="button" size="sm" variant="secondary" onClick={() => setItems([...items, blank])}>Tambah baris</Button>
          <div className="flex justify-between border-t border-slate-100 pt-3 text-sm"><span>Dampak ke nilai kontrak</span><strong>{delta < 0 ? '−' : '+'}{rp(Math.abs(delta))}</strong></div>
          <Button className="w-full">Ajukan adendum</Button>
        </Card>)}
    </div>
  );
}

export default function SubconAddendum({ projectId }) {
  const { profile } = useAuth();
  const [tab, setTab] = useState('spk');
  return (
    <ErrorBoundary name="subkon-adendum">
      <div className="mx-auto max-w-md space-y-3 p-4">
        <div className="flex gap-2">{[['spk', 'SPK subkon'], ['add', 'Adendum']].map(([k, l]) => (
          <Button key={k} size="sm" variant={tab === k ? 'primary' : 'secondary'} onClick={() => setTab(k)}>{l}</Button>))}</div>
        {tab === 'spk' ? <Spk projectId={projectId} role={profile.role} /> : <Addenda projectId={projectId} role={profile.role} />}
      </div>
    </ErrorBoundary>
  );
}
// Pakai: <RoleGate allow={['pm','owner','finance','estimator']}><SubconAddendum projectId={id}/></RoleGate>
