// auth.jsx — klien Supabase (atau klien demo), login, dan gerbang peran.
// Env (Vite): VITE_SUPABASE_URL, VITE_SUPABASE_ANON_KEY (kosongkan semuanya untuk mode demo)
import React, { createContext, useContext, useEffect, useState } from 'react';
import { createClient } from '@supabase/supabase-js';
import { createMockClient } from './demo/engine.js';
import { Button, Card, Skeleton } from './ui.jsx';
import { startAutoSync } from './offlineQueue.js';

// Mode demo: aktif bila VITE_DEMO=true atau alamat Supabase belum diisi. Data hanya di HP ini (lihat src/demo).
export const DEMO = import.meta.env.VITE_DEMO === 'true' || !import.meta.env.VITE_SUPABASE_URL;
export const supabase = DEMO
  ? createMockClient()
  : createClient(import.meta.env.VITE_SUPABASE_URL, import.meta.env.VITE_SUPABASE_ANON_KEY, { auth: { persistSession: true, autoRefreshToken: true } });

// Menu per peran (id modul -> peran yang boleh membuka)
export const MENU = [
  { id: 'dashboard', label: 'Dasbor', roles: ['pm', 'owner', 'finance', 'estimator'] },
  { id: 'laporan', label: 'Laporan harian', roles: ['mandor', 'pm'] },
  { id: 'absensi', label: 'Absensi tukang', roles: ['mandor', 'admin_proyek', 'pm'] },
  { id: 'kas', label: 'Kas kecil', roles: ['admin_proyek', 'pm', 'finance'] },
  { id: 'rab', label: 'RAB dan RAP', roles: ['estimator', 'pm'] },
  { id: 'approval', label: 'Persetujuan', roles: ['pm', 'owner'] },
  { id: 'keuangan', label: 'Keuangan', roles: ['finance', 'owner'] },
];
export const menuFor = (role) => MENU.filter((m) => m.roles.includes(role));

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }) {
  const [state, setState] = useState({ loading: true, user: null, profile: null, error: null });

  useEffect(() => {
    let stop = () => {};
    const load = async (session) => {
      if (!session) return setState({ loading: false, user: null, profile: null, error: null });
      // Ambil kolom seperlunya saja (hemat egress)
      const { data, error } = await supabase
        .from('profiles').select('id, full_name, role, is_active').eq('id', session.user.id).single();
      if (error || !data?.is_active) {
        console.error('[auth] profil gagal dimuat', error);
        return setState({ loading: false, user: session.user, profile: null,
          error: 'Akun belum aktif. Hubungi owner.' });
      }
      setState({ loading: false, user: session.user, profile: data, error: null });
      stop();
      stop = startAutoSync(supabase); // sinkronisasi antrean offline berjalan setelah login
    };
    supabase.auth.getSession().then(({ data }) => load(data.session));
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => load(s));
    return () => { sub.subscription.unsubscribe(); stop(); };
  }, []);

  return <Ctx.Provider value={state}>{children}</Ctx.Provider>;
}

function DemoLogin() {
  const [busy, setBusy] = useState('');
  const users = supabase.demo.users();
  const ROLE = { owner: 'Owner', pm: 'Project manager', admin_proyek: 'Admin proyek', mandor: 'Mandor', estimator: 'Estimator', finance: 'Keuangan' };
  return (
    <div className="mx-auto flex min-h-screen max-w-sm items-center p-4">
      <Card className="w-full p-6">
        <p className="text-xs font-medium uppercase tracking-wide text-amber-700">Mode demo</p>
        <h1 className="mt-1 text-xl font-semibold tracking-tight text-slate-900">Pilih peran</h1>
        <p className="mt-1 text-sm text-slate-500">Data contoh, tersimpan hanya di HP ini dan tidak dikirim ke mana pun. Peran bisa diganti kapan saja dari Menu.</p>
        <div className="mt-4 grid grid-cols-1 gap-2">
          {users.map((u) => (
            <Button key={u.id} variant="secondary" size="lg" loading={busy === u.id} className="justify-between"
              onClick={async () => { setBusy(u.id); await supabase.auth.signInWithPassword({ email: u.email }); }}>
              <span>{ROLE[u.role]}</span><span className="text-xs font-normal text-slate-500">{u.full_name}</span>
            </Button>))}
        </div>
      </Card>
    </div>
  );
}

export function LoginForm() {
  if (DEMO) return <DemoLogin />;
  const [email, setEmail] = useState('');
  const [pw, setPw] = useState('');
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState('');

  async function submit(e) {
    e.preventDefault();
    setBusy(true); setErr('');
    const { error } = await supabase.auth.signInWithPassword({ email, password: pw });
    if (error) {
      console.error('[login]', error);
      setErr(error.message.includes('Invalid') ? 'Email atau kata sandi salah.' : 'Tidak bisa masuk. Periksa sinyal Anda.');
    }
    setBusy(false);
  }

  const input = 'h-11 w-full rounded-lg border border-slate-200 bg-white px-3 text-base outline-none focus:border-slate-900 focus:ring-4 focus:ring-slate-900/10';
  return (
    <div className="mx-auto flex min-h-screen max-w-sm items-center p-4">
      <Card className="w-full p-6">
        <h1 className="text-xl font-semibold tracking-tight text-slate-900">Masuk</h1>
        <p className="mt-1 text-sm text-slate-500">Gunakan akun yang diberikan owner.</p>
        <form onSubmit={submit} className="mt-5 space-y-3">
          <input className={input} type="email" autoComplete="username" placeholder="Email" value={email} onChange={(e) => setEmail(e.target.value)} required />
          <input className={input} type="password" autoComplete="current-password" placeholder="Kata sandi" value={pw} onChange={(e) => setPw(e.target.value)} required />
          {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
          <Button size="lg" className="w-full" loading={busy}>Masuk</Button>
        </form>
      </Card>
    </div>
  );
}

/** Bungkus seluruh app: tampil login jika belum masuk. */
export function AuthGate({ children }) {
  const a = useAuth();
  if (a.loading) return <div className="mx-auto max-w-sm space-y-3 p-4"><Skeleton className="h-8 w-40" /><Skeleton className="h-32 w-full" /></div>;
  if (!a.user) return <LoginForm />;
  if (!a.profile) return <div className="p-6 text-sm text-slate-700">{a.error}
    <Button className="mt-3" variant="secondary" onClick={() => supabase.auth.signOut()}>Keluar</Button></div>;
  return children;
}

/** Pembatas UI. Keamanan sebenarnya tetap di RLS; ini hanya merapikan tampilan. */
export function RoleGate({ allow, children, fallback = null }) {
  const { profile } = useAuth();
  return allow.includes(profile?.role) ? children : fallback;
}
