// imageCompress.js
// Kompresi gambar di browser HP sebelum upload ke Supabase Storage.
// Target: <= 300 KB, sisi terpanjang <= 1600 px, WebP (fallback JPEG).

const DEFAULTS = {
  maxSide: 1600,          // px, sisi terpanjang
  maxBytes: 300 * 1024,   // 300 KB
  startQuality: 0.8,
  minQuality: 0.5,
  step: 0.07,
};

function supportsWebP() {
  try {
    const c = document.createElement('canvas');
    c.width = c.height = 1;
    return c.toDataURL('image/webp').startsWith('data:image/webp');
  } catch {
    return false;
  }
}

// createImageBitmap hemat memori di HP entry-level & menghormati orientasi EXIF
async function decode(file) {
  if ('createImageBitmap' in window) {
    try {
      return await createImageBitmap(file, { imageOrientation: 'from-image' });
    } catch { /* lanjut ke fallback */ }
  }
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.decoding = 'async';
    img.src = url;
    await img.decode();
    return img;
  } finally {
    URL.revokeObjectURL(url);
  }
}

function toBlob(canvas, type, quality) {
  return new Promise((resolve, reject) => {
    canvas.toBlob(
      (b) => (b ? resolve(b) : reject(new Error('Canvas gagal membuat blob'))),
      type,
      quality
    );
  });
}

function drawScaled(source, maxSide) {
  const w = source.width;
  const h = source.height;
  const scale = Math.min(1, maxSide / Math.max(w, h));
  const canvas = document.createElement('canvas');
  canvas.width = Math.round(w * scale);
  canvas.height = Math.round(h * scale);
  const ctx = canvas.getContext('2d', { alpha: false });
  ctx.imageSmoothingQuality = 'high';
  ctx.fillStyle = '#fff'; // PNG transparan -> latar putih (aman untuk JPEG)
  ctx.fillRect(0, 0, canvas.width, canvas.height);
  ctx.drawImage(source, 0, 0, canvas.width, canvas.height);
  return canvas;
}

/**
 * Kompres satu gambar.
 * @param {File|Blob} file
 * @param {Partial<typeof DEFAULTS>} opts
 * @returns {Promise<{blob: Blob, width: number, height: number, mime: string,
 *                    ext: string, originalBytes: number, bytes: number}>}
 */
export async function compressImage(file, opts = {}) {
  if (!file || !file.type?.startsWith('image/')) {
    throw new Error('File bukan gambar');
  }
  const o = { ...DEFAULTS, ...opts };
  const mime = supportsWebP() ? 'image/webp' : 'image/jpeg';
  const ext = mime === 'image/webp' ? 'webp' : 'jpg';

  const source = await decode(file);
  let side = o.maxSide;
  let quality = o.startQuality;
  let canvas = drawScaled(source, side);
  let blob = await toBlob(canvas, mime, quality);

  // Turunkan kualitas dulu; kalau masih besar, kecilkan dimensi 15%
  let guard = 0;
  while (blob.size > o.maxBytes && guard++ < 12) {
    if (quality - o.step >= o.minQuality) {
      quality = +(quality - o.step).toFixed(2);
    } else {
      side = Math.round(side * 0.85);
      canvas = drawScaled(source, side);
      quality = o.startQuality - 0.1;
    }
    blob = await toBlob(canvas, mime, quality);
  }

  if (source.close) source.close(); // bebaskan memori ImageBitmap

  return {
    blob,
    width: canvas.width,
    height: canvas.height,
    mime,
    ext,
    originalBytes: file.size,
    bytes: blob.size,
  };
}

/** Thumbnail kecil (~10-20 KB) untuk daftar, supaya egress ringan. */
export function makeThumbnail(file) {
  return compressImage(file, { maxSide: 320, maxBytes: 25 * 1024, startQuality: 0.7 });
}

/**
 * Compress lalu upload ke Supabase Storage (bucket privat 'site-photos').
 * Dipanggil oleh antrean sync (lihat tahap offline queue), bukan langsung dari UI.
 */
export async function uploadPhoto(supabase, { projectId, clientId, file }) {
  const c = await compressImage(file);
  const path = `${projectId}/${new Date().toISOString().slice(0, 7)}/${clientId}.${c.ext}`;
  const { error } = await supabase.storage
    .from('site-photos')
    .upload(path, c.blob, { contentType: c.mime, upsert: true, cacheControl: '31536000' });
  if (error) throw error;
  return { path, mime: c.mime, size_bytes: c.bytes, width: c.width, height: c.height };
}
