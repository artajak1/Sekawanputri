// PettyCash.jsx — kas kecil + foto nota terkompresi + approval. Input lewat antrean offline.
import React, { useCallback, useEffect, useState } from 'react';
import { supabase, useAuth, RoleGate } from './auth.jsx';
import { enqueue } from './offlineQueue.js';
import { compressImage } from './imageCompress.js';
import { Button, Card, Skeleton, ErrorBoundary } from './ui.jsx';

const rp = (n) => 'Rp ' + new Intl.NumberFormat('id-ID').format(n || 0);
const kb = (n) => Math.round(n / 1024) + ' KB';
const field = 'w-full rounded-lg border border-slate-200 bg-white px-3 py-2.5 outline-none focus:border-slate-900 focus:ring-4 focus:ring-slate-900/10';
const STATUS = {
  submitted: ['Menunggu', 'text-amber-700'], approved: ['Disetujui', 'text-green-700'],
  rejected: ['Ditolak', 'text-red-700'], draft: ['Draf', 'text-slate-500'],
};

function Entry({ projectId }) {
  const { user } = useAuth();
  const [dir, setDir] = useState('out');
  const [amount, setAmount] = useState('');
  const [desc, setDesc] = useState('');
  const [photo, setPhoto] = useState(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState({ t: '', ok: false });

  async function pick(e) {
    const f = e.target.files[0]; setPhoto(null);
    if (!f) return;
    try {
      const c = await compressImage(f);
      setPhoto({ file: new File([c.blob], `nota.${c.ext}`, { type: c.mime }), info: `${kb(c.originalBytes)} menjadi ${kb(c.bytes)}` });
    } catch (err) { console.error('[nota]', err); setMsg({ t: 'Foto nota tidak bisa diproses.', ok: false }); }
  }

  async function submit(e) {
    e.preventDefault();
    const n = Number(String(amount).replace(/\D/g, ''));
    if (!n) return setMsg({ t: 'Isi jumlah dengan angka.', ok: false });
    if (!desc.trim()) return setMsg({ t: 'Isi keterangan.', ok: false });
    if (dir === 'out' && !photo) return setMsg({ t: 'Kas keluar wajib melampirkan foto nota.', ok: false });
    setBusy(true);
    try {
      await enqueue({
        table: 'petty_cash', projectId,
        photo: photo?.file,
        row: { project_id: projectId, direction: dir, amount: n, description: desc.trim(),
               tx_date: new Date().toISOString().slice(0, 10), status: 'submitted', created_by: user.id },
      });
      setMsg({ t: 'Tersimpan. Terkirim otomatis saat ada sinyal.', ok: true });
      setAmount(''); setDesc(''); setPhoto(null); e.target.reset();
      window.dispatchEvent(new Event('pc-changed'));
    } catch (err) {
      console.error('[kas]', err);
      setMsg({ t: 'Gagal menyimpan di perangkat. Coba lagi.', ok: false });
    } finally { setBusy(false); }
  }

  return (
    <Card as="form" onSubmit={submit} className="space-y-3">
      <div className="grid grid-cols-2 gap-2" role="group" aria-label="Jenis transaksi">
        {[['out', 'Kas keluar'], ['in', 'Kas masuk']].map(([k, l]) => (
          <Button key={k} type="button" variant={dir === k ? 'primary' : 'secondary'} onClick={() => setDir(k)} aria-pressed={dir === k}>{l}</Button>
        ))}
      </div>
      <input className={field} inputMode="numeric" placeholder="Jumlah (Rp)"
        value={amount ? new Intl.NumberFormat('id-ID').format(Number(String(amount).replace(/\D/g, ''))) : ''}
        onChange={(e) => setAmount(e.target.value)} />
      <input className={field} placeholder="Keterangan, mis. Semen 10 sak" value={desc} onChange={(e) => setDesc(e.target.value)} />
      <input className="text-sm" type="file" accept="image/*" capture="environment" onChange={pick} />
      {photo && <p className="text-sm text-slate-500">Nota {photo.info}</p>}
      {msg.t && <p role="alert" className={`text-sm ${msg.ok ? 'text-green-700' : 'text-red-700'}`}>{msg.t}</p>}
      <Button size="lg" className="w-full" loading={busy}>Simpan transaksi</Button>
    </Card>
  );
}

function List({ projectId }) {
  const { profile } = useAuth();
  const [rows, setRows] = useState(null);
  const [bal, setBal] = useState(null);
  const [err, setErr] = useState('');

  const load = useCallback(async () => {
    try {
      const [a, b] = await Promise.all([
        supabase.from('petty_cash').select('id, tx_date, direction, amount, description, status')
          .eq('project_id', projectId).order('created_at', { ascending: false }).limit(20),
        supabase.from('petty_cash_balance').select('balance').eq('project_id', projectId).maybeSingle(),
      ]);
      if (a.error) throw a.error;
      setRows(a.data); setBal(b.data?.balance ?? 0); setErr('');
    } catch (e) { console.error('[kas load]', e); setErr('Tidak bisa memuat data. Periksa sinyal.'); }
  }, [projectId]);

  useEffect(() => { load(); window.addEventListener('pc-changed', load); return () => window.removeEventListener('pc-changed', load); }, [load]);

  async function decide(id, approve) {
    const { error } = await supabase.rpc('decide_approval', {
      p_ref_table: 'petty_cash', p_ref_id: id, p_level: profile.role === 'owner' ? 2 : 1, p_approve: approve,
    });
    if (error) { console.error('[approval]', error); setErr(error.message); } else load();
  }

  if (!rows) return <Card><Skeleton className="h-4 w-24" /><Skeleton className="mt-3 h-8 w-40" /></Card>;
  return (
    <>
      <Card interactive>
        <p className="text-sm text-slate-500">Saldo kas kecil (disetujui)</p>
        <p className="mt-1 text-2xl font-semibold tracking-tight text-slate-900">{rp(bal)}</p>
      </Card>
      {err && <p role="alert" className="text-sm text-red-700">{err}</p>}
      <Card className="divide-y divide-slate-100 p-0">
        {rows.length === 0 && <p className="p-4 text-sm text-slate-500">Belum ada transaksi.</p>}
        {rows.map((r) => (
          <div key={r.id} className="flex items-start justify-between gap-3 p-4">
            <div className="min-w-0">
              <p className="truncate text-sm font-medium text-slate-900">{r.description}</p>
              <p className="text-xs text-slate-500">{r.tx_date} · <span className={STATUS[r.status][1]}>{STATUS[r.status][0]}</span></p>
              {r.status === 'submitted' && (
                <RoleGate allow={['pm', 'owner']}>
                  <div className="mt-2 flex gap-2">
                    <Button size="sm" onClick={() => decide(r.id, true)}>Setujui</Button>
                    <Button size="sm" variant="danger" onClick={() => decide(r.id, false)}>Tolak</Button>
                  </div>
                </RoleGate>
              )}
            </div>
            <p className={`whitespace-nowrap text-sm font-semibold ${r.direction === 'in' ? 'text-green-700' : 'text-slate-900'}`}>
              {r.direction === 'in' ? '+' : '−'}{rp(r.amount)}
            </p>
          </div>
        ))}
      </Card>
    </>
  );
}

export default function PettyCash({ projectId }) {
  return (
    <ErrorBoundary name="kas-kecil">
      <div className="mx-auto max-w-md space-y-3 p-4">
        <List projectId={projectId} />
        <RoleGate allow={['admin_proyek', 'pm']}><Entry projectId={projectId} /></RoleGate>
      </div>
    </ErrorBoundary>
  );
}
// Pakai: <RoleGate allow={['admin_proyek','pm','finance']}><PettyCash projectId={id}/></RoleGate>
