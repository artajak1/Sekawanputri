// supabase/functions/send-wa/index.ts   (salin file ini ke path tersebut)
// Deploy: supabase functions deploy send-wa --no-verify-jwt
// Secrets: supabase secrets set FONNTE_TOKEN=xxx CRON_SECRET=xxx
import { createClient } from 'npm:@supabase/supabase-js@2';

const sb = createClient(Deno.env.get('SUPABASE_URL')!, Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!);

// 0812... atau +62812... -> 62812...
const normalize = (p: string) => {
  const d = p.replace(/\D/g, '');
  return d.startsWith('0') ? '62' + d.slice(1) : d.startsWith('62') ? d : '62' + d;
};

Deno.serve(async (req) => {
  if (req.headers.get('x-cron-secret') !== Deno.env.get('CRON_SECRET')) {
    return new Response('Unauthorized', { status: 401 });
  }

  const { data: jobs, error } = await sb.rpc('claim_wa_batch', { p_limit: 10 });
  if (error) {
    console.error('[send-wa] claim gagal', error);
    return new Response('claim error', { status: 500 });
  }

  let sent = 0, failed = 0;
  for (const j of jobs ?? []) {
    try {
      // Fonnte: POST https://api.fonnte.com/send, header Authorization berisi token.
      // Untuk Wablas, ganti URL dan format body sesuai dokumentasinya.
      const res = await fetch('https://api.fonnte.com/send', {
        method: 'POST',
        headers: { Authorization: Deno.env.get('FONNTE_TOKEN')! },
        body: new URLSearchParams({ target: normalize(j.to_phone), message: j.message }),
      });
      const body = await res.json().catch(() => ({}));
      if (!res.ok || body.status === false) throw new Error(body.reason || `HTTP ${res.status}`);

      await sb.from('wa_outbox').update({ sent_at: new Date().toISOString(), last_error: null, locked_at: null }).eq('id', j.id);
      sent++;
    } catch (e) {
      console.error('[send-wa] gagal kirim', j.id, e);
      // locked_at dibiarkan: percobaan ulang baru boleh setelah 2 menit
      await sb.from('wa_outbox').update({ last_error: String((e as Error).message ?? e) }).eq('id', j.id);
      failed++;
    }
  }
  return Response.json({ sent, failed });
});
