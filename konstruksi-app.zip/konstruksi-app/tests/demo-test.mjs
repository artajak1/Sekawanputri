const store={};globalThis.localStorage={getItem:k=>k in store?store[k]:null,setItem:(k,v)=>{store[k]=String(v)},removeItem:k=>{delete store[k]}};
globalThis.URL.createObjectURL=()=>'blob:x';
const { createMockClient } = await import('../src/demo/engine.js');
const sb=createMockClient();
let pass=0,failn=0;
const ok=(c,m)=>{if(c){pass++}else{failn++;console.log('GAGAL:',m)}};
const login=async(r)=>{const {error}=await sb.auth.signInWithPassword({email:r+'@demo.id'});if(error)throw new Error('login '+r)};
const rpc=async(n,a)=>sb.rpc(n,a);
const q=(t)=>sb.from(t);
const T=new Date().toISOString().slice(0,10);
const mon=(()=>{const x=new Date(Date.UTC(...(d=>[d.getFullYear(),d.getMonth(),d.getDate()])(new Date())));x.setUTCDate(x.getUTCDate()-((x.getUTCDay()+6)%7));return x.toISOString().slice(0,10)})();

// 1 login + visibilitas
await login('owner'); let {data:ps}=await q('projects').select('id,name,status').neq('status','closed').order('name'); ok(ps.length===2,'owner lihat 2 proyek non-tutup (A,B)');
let all=(await q('projects').select('id,name,status')).data; ok(all.length===3,'owner lihat 3 proyek');
const pA=all.find(p=>p.name.startsWith('Gedung')).id, pB=all.find(p=>p.name.startsWith('Ruko')).id;
await login('mandor'); ok((await q('projects').select('id')).data.length===1,'mandor hanya proyek A');
await login('pm'); ok((await q('projects').select('id')).data.length===2,'pm lihat A dan B');
const bad=await sb.auth.signInWithPassword({email:'x@y.z'}); ok(!!bad.error,'login salah ditolak');

// 2 dashboard
let d=(await rpc('dashboard_summary',{p_project:pA})).data; ok(d.actual_pct>0&&d.planned_pct>0&&d.curve.length===16,'dashboard terisi'); ok(d.curve.some(c=>c.act===null)&&d.curve.some(c=>c.act>0),'kurva: masa depan null, lalu ada realisasi');
ok(d.pending>=5,'pending dihitung ('+d.pending+')'); ok(d.po.ordered>0&&d.po.received<d.po.ordered,'ringkasan PO');

// 3 kas kecil
await login('admin');
let r=await q('petty_cash').upsert({client_id:crypto.randomUUID(),project_id:pA,direction:'out',amount:6000000,description:'Uji kas besar',status:'approved',created_by:'x'},{onConflict:'client_id'}).select('id').single();
ok(!r.error&&r.data.id,'kas upsert'); const pcId=r.data.id;
let row=(await q('petty_cash').select('status').eq('id',pcId).single()).data; ok(row.status==='submitted','status dipaksa submitted (celah ditutup)');
let aps=(await q('approvals').select('level,status').eq('ref_id',pcId)).data; ok(aps.length===2,'kas >=5jt punya 2 level');
await login('owner'); r=await rpc('decide_approval',{p_ref_table:'petty_cash',p_ref_id:pcId,p_level:2,p_approve:true}); ok(r.error&&/Level 1/.test(r.error.message),'owner tak bisa lompati PM');
await login('admin'); r=await rpc('decide_approval',{p_ref_table:'petty_cash',p_ref_id:pcId,p_level:1,p_approve:true}); ok(r.error,'admin tak bisa menyetujui');
await login('pm'); r=await rpc('decide_approval',{p_ref_table:'petty_cash',p_ref_id:pcId,p_level:1,p_approve:true}); ok(!r.error,'pm L1 ok');
await login('owner'); r=await rpc('decide_approval',{p_ref_table:'petty_cash',p_ref_id:pcId,p_level:2,p_approve:true}); ok(!r.error,'owner L2 ok');
row=(await q('petty_cash').select('status').eq('id',pcId).single()).data; ok(row.status==='approved','kas menjadi approved');
const bal=(await q('petty_cash_balance').select('balance').eq('project_id',pA).maybeSingle()).data.balance; ok(bal===5000000-350000-6000000,'saldo benar '+bal);

// 4 PO
await login('admin');
r=await q('purchase_orders').upsert({client_id:crypto.randomUUID(),project_id:pA,supplier_id:(await q('suppliers').select('id').limit(1)).data[0].id,items:[{description:'Batu split',unit:'rit',qty:10,unit_price:1200000}],created_by:'x'},{onConflict:'client_id'}).select('id').single();
ok(!r.error,'PO dibuat '+(r.error&&r.error.message)); const poId=r.data.id;
let po=(await q('purchase_orders').select('po_number,total,status').eq('id',poId).single()).data; ok(po.total===12000000&&/^PO-/.test(po.po_number)&&po.status==='submitted','PO total/nomor/status');
ok((await q('po_items').select('id').eq('po_id',poId)).data.length===1,'item PO dipecah');
r=await q('purchase_orders').upsert({client_id:crypto.randomUUID(),project_id:pA,supplier_id:po.id,items:[],created_by:'x'},{onConflict:'client_id'}).select('id').single(); ok(r.error,'PO kosong ditolak');
await login('pm'); await rpc('decide_po',{p_po:poId,p_level:1,p_approve:true});
await login('owner'); r=await rpc('decide_po',{p_po:poId,p_level:2,p_approve:true}); ok(!r.error,'PO disetujui owner');
po=(await q('purchase_orders').select('status').eq('id',poId).single()).data; ok(po.status==='approved','PO approved');
await login('admin'); const item=(await q('po_items').select('id,qty').eq('po_id',poId)).data[0];
r=await q('delivery_notes').upsert({client_id:crypto.randomUUID(),po_id:poId,sj_number:'SJ-1',items:[{po_item_id:item.id,qty:11}],created_by:'x'},{onConflict:'client_id'}).select('id').single(); ok(r.error&&/melebihi/.test(r.error.message),'penerimaan berlebih ditolak');
r=await q('delivery_notes').upsert({client_id:crypto.randomUUID(),po_id:poId,sj_number:'SJ-2',items:[{po_item_id:item.id,qty:4}],created_by:'x'},{onConflict:'client_id'}).select('id').single(); ok(!r.error,'terima sebagian');
ok((await q('purchase_orders').select('status').eq('id',poId).single()).data.status==='partial','status partial');
await q('delivery_notes').upsert({client_id:crypto.randomUUID(),po_id:poId,sj_number:'SJ-3',items:[{po_item_id:item.id,qty:6}],created_by:'x'},{onConflict:'client_id'}).select('id').single();
ok((await q('purchase_orders').select('status').eq('id',poId).single()).data.status==='received','status received');

// 5 tagihan supplier
await login('finance');
let inv=(await q('supplier_invoices').select('id,invoice_no,amount,purchase_orders!inner(po_number,project_id)').eq('purchase_orders.project_id',pA).order('invoice_date',{ascending:false})).data; ok(inv.length===2&&inv[0].purchase_orders.po_number,'embed inner + filter tertanam');
const i1=inv.find(x=>x.invoice_no==='INV-8812'), i2=inv.find(x=>x.invoice_no==='KW-2290');
r=await rpc('pay_invoice',{p_invoice:i1.id}); ok(r.error&&/melebihi nilai barang/.test(r.error.message),'tagihan > barang diterima ditolak');
r=await rpc('pay_invoice',{p_invoice:i2.id}); ok(r.error&&/owner/.test(r.error.message),'tagihan besar butuh owner');
await login('owner'); await rpc('approve_invoice_payment',{p_invoice:i2.id}); await login('finance'); r=await rpc('pay_invoice',{p_invoice:i2.id}); ok(!r.error,'bayar setelah owner setuju');

// 6 payroll
await login('pm'); r=await rpc('generate_payroll',{p_project:pA,p_week_start:mon}); ok(!r.error,'payroll dihitung '+(r.error&&r.error.message)); const runId=r.data;
let lines=(await q('payroll_lines').select('hok_total,gross,advance_deduct,net,workers(name)').eq('run_id',runId)).data; const sl=lines.find(l=>l.workers.name==='Pak Slamet');
ok(sl&&sl.advance_deduct===Math.min(600000,Math.floor(sl.gross*0.5)),'potongan kasbon dibatasi 50%: '+JSON.stringify(sl));
r=await rpc('decide_payroll',{p_run:runId,p_approve:true}); ok(!r.error,'payroll disetujui');
const adv=(await q('worker_advances').select('repaid,amount').eq('settled',false)).data; ok(adv.some(a=>a.repaid>0),'kasbon terpotong saat disetujui');
await login('mandor'); const wk=(await q('workers').select('id').eq('project_id',pA)).data[0].id;
r=await q('attendance').upsert({client_id:crypto.randomUUID(),worker_id:wk,work_date:mon,hok:1,created_by:'x'},{onConflict:'client_id'}).select('id').single(); ok(r.error&&/terkunci/.test(r.error.message),'absensi pekan disetujui terkunci');

// 7 SPK
await login('finance'); const spk=(await q('spk_summary').select('*').eq('project_id',pA).order('spk_number')).data.find(s=>s.status==='approved'); ok(spk.progress_pct===40&&spk.paid===20000000,'spk_summary');
r=await rpc('pay_spk',{p_spk:spk.id,p_amount:20000000}); ok(r.error&&/Maksimal saat ini Rp 14\.000\.000/.test(r.error.message),'bayar SPK melebihi progres ditolak: '+(r.error&&r.error.message));
r=await rpc('pay_spk',{p_spk:spk.id,p_amount:14000000}); ok(!r.error,'bayar sesuai progres');
await login('pm'); r=await rpc('set_spk_progress',{p_spk:spk.id,p_pct:30}); ok(r.error,'progres tak boleh turun');

// 8 adendum
const ad=(await q('addenda').select('id,delta,status')).data[0]; await rpc('decide_doc',{p_table:'addenda',p_id:ad.id,p_level:1,p_approve:true});
await login('owner'); r=await rpc('decide_doc',{p_table:'addenda',p_id:ad.id,p_level:2,p_approve:true}); ok(!r.error,'adendum disetujui');
const pr=(await q('projects').select('contract_value,contract_original').eq('id',pA).single()).data; ok(pr.contract_value===1896500000&&pr.contract_original===1850000000,'nilai kontrak berubah: '+JSON.stringify(pr));
// adendum buat via estimator
await login('estimator'); r=await q('addenda').upsert({client_id:crypto.randomUUID(),project_id:pA,title:'Kurang',reason:null,items:[{type:'kurang',description:'x',unit:'ls',qty:1,unit_price:5000000},{type:'tambah',description:'y',unit:'ls',qty:2,unit_price:1000000}],created_by:'x'},{onConflict:'client_id'}).select('id').single(); ok(!r.error,'adendum baru'); ok((await q('addenda').select('delta').eq('id',r.data.id).single()).data.delta===-3000000,'delta tambah-kurang');

// 9 punch + serah terima + retensi
await login('pm'); r=await rpc('complete_handover',{p_project:pA}); ok(r.error&&/belum diverifikasi/.test(r.error.message),'serah terima ditolak: '+(r.error&&r.error.message));
const punch=(await q('punch_items').select('id,status').eq('project_id',pA)).data;
await login('mandor'); const op=punch.find(p=>p.status==='open'); r=await q('punch_fixes').upsert({client_id:crypto.randomUUID(),punch_id:op.id,note:'ok',created_by:'x'},{onConflict:'client_id'}).select('id').single(); ok(!r.error,'perbaikan dicatat'); ok((await q('punch_items').select('status').eq('id',op.id).single()).data.status==='fixed','punch jadi fixed');
await login('pm'); for(const p of (await q('punch_items').select('id,status').eq('project_id',pA)).data.filter(p=>p.status==='fixed')) await rpc('verify_punch',{p_id:p.id,p_ok:true});
r=await rpc('complete_handover',{p_project:pA}); ok(!r.error,'serah terima selesai '+(r.error&&r.error.message));
const claim=(await q('retention_claims').select('amount,due_date,status').eq('project_id',pA).single()).data; ok(claim.amount===18500000,'retensi = 5% DPP termin 1: '+claim.amount);
await login('finance'); r=await rpc('release_retention',{p_project:pA}); ok(r.error&&/Belum jatuh tempo/.test(r.error.message),'retensi belum jatuh tempo ditolak');
sb.demo.expireRetention(); r=await rpc('release_retention',{p_project:pA}); ok(!r.error,'retensi cair setelah jatuh tempo');

// 10 alat
await login('admin'); const eqs=(await q('equipment_usage').select('equipment_id,name,usage,fuel_liters,per_unit,fuel_norm,rental_cost').eq('project_id',pA)).data; const ex=eqs.find(e=>e.name.startsWith('Excavator'));
ok(ex&&ex.per_unit/ex.fuel_norm>1.3&&ex.rental_cost>0,'alat: BBM melebihi norma terdeteksi ('+(ex&&(ex.per_unit/ex.fuel_norm).toFixed(2))+')');
const exId=ex.equipment_id; r=await q('equipment_logs').upsert({client_id:crypto.randomUUID(),equipment_id:exId,log_date:'2020-01-01',meter_start:5,meter_end:4,fuel_liters:1,created_by:'x'},{onConflict:'client_id'}).select('id').single(); ok(r.error,'meter akhir < awal ditolak');
const vr=(await q('equipment').select('id,status').eq('project_id',pA)).data.find(e=>e.status==='pending'); r=await q('equipment_logs').upsert({client_id:crypto.randomUUID(),equipment_id:vr.id,log_date:T,meter_start:1,meter_end:2,fuel_liters:1,created_by:'x'},{onConflict:'client_id'}).select('id').single(); ok(r.error&&/belum disetujui/.test(r.error.message),'log alat belum disetujui ditolak');
await login('owner'); r=await rpc('approve_equipment',{p_id:vr.id,p_ok:true}); ok(!r.error,'owner setujui sewa');

// 11 RAB
await login('estimator'); r=await rpc('import_rab',{p_project:pA,p_rows:[{code:'Z1',description:'a',unit:'m',volume:1,unit_price:10},{code:'Z1',description:'b',unit:'m',volume:1,unit_price:10}]}); ok(r.error&&/ganda/.test(r.error.message),'kode ganda ditolak');
r=await rpc('import_rab',{p_project:pA,p_rows:[{code:'A.1',description:'Galian (revisi)',unit:'m3',volume:100,unit_price:90000},{code:'Z9',description:'Baru',unit:'',volume:2,unit_price:500}]}); ok(r.data===2,'impor 2 baris');
const rab=(await q('rab_items').select('code,description,unit,volume,unit_price,total').eq('project_id',pA).order('code')).data; ok(rab.find(x=>x.code==='A.1').total===9000000&&rab.find(x=>x.code==='Z9').unit==='ls','RAB diperbarui/ditambah');
await login('mandor'); r=await rpc('import_rab',{p_project:pA,p_rows:[{code:'Q',description:'x',unit:'m',volume:1,unit_price:1}]}); ok(r.error,'mandor tak boleh impor RAB');

// 12 master + gambar
await login('pm'); r=await rpc('create_project',{p_code:'GSG-01',p_name:'x',p_client:'y',p_contract:1}); ok(r.error&&/sudah dipakai/.test(r.error.message),'kode proyek ganda ditolak');
r=await rpc('create_project',{p_code:'NEW-1',p_name:'Proyek Baru',p_client:'Klien',p_contract:100}); ok(!r.error,'proyek dibuat'); ok((await q('projects').select('id').eq('id',r.data)).data.length===1,'pembuat langsung bisa melihat proyeknya');
await login('estimator'); const dr=(await q('drawings').select('id,code,drawing_versions(id,version,is_current)').eq('project_id',pA).order('code')).data; ok(dr.length===2&&dr[0].drawing_versions.length===3,'embed to-many gambar');
r=await rpc('register_drawing_version',{p_drawing:dr[0].id,p_path:`${pA}/${dr[0].id}/v4.pdf`,p_mime:'application/pdf',p_size:1000,p_note:'rev'}); ok(r.data===4,'versi naik ke 4');
r=await rpc('register_drawing_version',{p_drawing:dr[0].id,p_path:`lain/x.pdf`,p_mime:'application/pdf',p_size:1}); ok(r.error,'path proyek lain ditolak');
ok((await q('drawing_versions').select('id').eq('drawing_id',dr[0].id).eq('is_current',true)).data.length===1,'hanya satu versi terbaru');

// 13 arsip + rekap tahunan
await login('owner'); const yr=new Date().getFullYear(); let ysr=await rpc('yearly_summary',{p_year:yr}); if(ysr.error)console.log('ERR',ysr.error.message); let ys=ysr.data; ok(ys.projects.some(p=>p.name.startsWith('Ruko')&&p.revenue===301000000),'rekap tahun ini memuat proyek B');
ys=(await rpc('yearly_summary',{p_year:yr-1})).data; ok(ys.projects.length===1&&ys.projects[0].revenue===410000000&&ys.projects[0].cost===120000000,'rekap tahun lalu proyek C: '+JSON.stringify(ys.projects));
let ar=(await q('projects').select('id,name,client_name,status').in('status',['retention','closed']).or('name.ilike.%mastrip%,client_name.ilike.%mastrip%').limit(30)).data; ok(ar.length===1,'pencarian ilike/or');
// laporan harian embed + approval
await login('pm'); const dr2=(await q('daily_reports').select('id,report_date,physical_pct,status,profiles!daily_reports_created_by_fkey(full_name)').eq('project_id',pA).eq('status','submitted').order('report_date',{ascending:false}).limit(20)).data; ok(dr2.length===2&&dr2[0].profiles.full_name==='Budi Santoso','laporan menunggu + embed profil');
r=await rpc('decide_report',{p_report:dr2[0].id,p_approve:true}); ok(!r.error,'laporan disetujui PM'); await login('mandor'); r=await rpc('decide_report',{p_report:dr2[1].id,p_approve:true}); ok(r.error,'mandor tak boleh menyetujui laporan');
// keuangan termin
await login('finance'); const terms=(await q('client_terms').select('id,term_no,status').eq('project_id',pA).order('term_no')).data; r=await rpc('issue_client_invoice',{p_term:terms[1].id}); ok(!r.error,'invoice terbit');
const iv=(await q('client_invoices').select('dpp,ppn_amount,pph_amount,retention_amount,net_receivable').eq('term_id',terms[1].id).single()).data; ok(iv.dpp===555000000&&iv.ppn_amount===61050000&&iv.pph_amount===14707500&&iv.retention_amount===27750000&&iv.net_receivable===555000000+61050000-14707500-27750000,'hitung PPN/PPh/retensi: '+JSON.stringify(iv));
r=await rpc('issue_client_invoice',{p_term:terms[1].id}); ok(r.error,'termin tak bisa ditagih dua kali');
// persistensi + reset
await new Promise(r=>setTimeout(r,300)); ok(!!store['demo-db-v1']&&JSON.parse(store['demo-db-v1']).projects.length===4,'data tersimpan ke localStorage'); sb.demo.reset(); await login('owner'); ok((await q('projects').select('id')).data.length===3,'reset mengembalikan data awal');
console.log(`\n${pass} lulus, ${failn} gagal`);process.exit(failn?1:0);
